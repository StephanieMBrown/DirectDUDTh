function [FinalDUTh,ff, maxFn, fn,ignoreliquids,decayCorrEx] = solveDUDTh_finalPooledMelt(desired230ThExcess, desired226RaExcess, InitialDUTh,FRetained,Fmax,DRa_given,meltInc,time4decay)
%% testing continual increase, not a phase change, and ingrowth 
% calls "solveFgivenK2Opool" and
% "Shaw_incremental_continuousIncrease"

%knowns:
% InitialDUTh = [0.0067 0.0035];
% FRetained = 0.01; 
% K2Oerupted = .02;
% desired226RaExcess = 4.022; 
% desired230ThExcess = 1.054; 
% K2Osource = 0.002; 
% DRa_given = 1e-5; 
% PercentFC=.5; 



if time4decay < 9000
desired226RaExcess = (desired226RaExcess - 1).*exp(log(2)/1600*time4decay)+1; 
end

desired230ThExcess = (desired230ThExcess - 1).*exp(log(2)/75000*time4decay)+1; 

decayCorrEx = [desired230ThExcess desired226RaExcess];

%%
% solving for:  Newton Raphson 
% problem set up:

fp = FRetained;

meltfraction = meltInc;
Wo =1;% initial mass, grams
l = meltfraction; % constant melt mass, grams
F1 = l./Wo; % initial melt fraction, percent
ff = log(1-Fmax)/log(1-F1);
ff = round(ff); 
n_end = ff;
n=1:n_end;  %# of steps

Fn = ones(1,size(n,2)).*F1;%array of melt fractions as melting proceeds 
fn = 1 - (1-F1).^n; 

ignoreliquids = find(fn<fp); 
ignoreliquids = max(ignoreliquids);

if ignoreliquids==size(fn,2)
    ignoreliquids = 1; 
end

%Newton Raphson parameters
XACC = 1e-6;
X1 = .5;
X2 = 0.000001;
JMAX=1000;


%initial guess
minnn = DRa_given;
maxx = DRa_given;
DRa=[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];

minnn = InitialDUTh(2);
maxx = X1;
DTh=[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];


[CnLrelative_Ra, Cn_accumulated_relative_Ra, Cnr_Ra,fn,Dn_Ra,Lnexp_U] = Shaw_incremental_continuousIncrease(DRa,FRetained,n_end,meltInc);
[CnLrelative_Th, Cn_accumulated_relative_Th, Cnr_Th,fn,Dn_Th,Lnexp_Th] = Shaw_incremental_continuousIncrease(DTh,FRetained,n_end,meltInc);


Cnr_Th = [1 Cnr_Th(1:end-1)]; 
Cnr_Ra = [1 Cnr_Ra(1:end-1)]; 


clear meltsSoFar CompleteIngrowthPooledMelts
for z = 1:size(Lnexp_U,2)
    meltsSoFar = Lnexp_U(1:z)./sum(Lnexp_U(1:z)); 

    AvgTh_z(z) = CnLrelative_Th(1:z)*meltsSoFar';
    AvgRa_z(z) = CnLrelative_Ra(1:z)*meltsSoFar';
    
    AvgTh_R_z(z) = Cnr_Th(1:z)*meltsSoFar';
    AvgRa_R_z(z) = Cnr_Ra(1:z)*meltsSoFar';  
end
RaTh_Source = 1; 
ZeroIngrowth_Pool_Ra226 = (AvgRa_z./AvgTh_z)./RaTh_Source;
CompleteIngrowth_Pool_Ra226= (AvgRa_z./AvgTh_z)./(AvgRa_R_z./AvgTh_R_z); 
CompleteIngrowthIncrementalMelts = (CnLrelative_Ra./CnLrelative_Th)./(Cnr_Ra./Cnr_Th);


F = CompleteIngrowth_Pool_Ra226(ff) - desired226RaExcess; 

if F < 0
    RT4BIS=X1;
    DX=X2-X1;
else
    RT4BIS=X2;
    DX=X1-X2;
end



for J = 1:JMAX
    DX=DX*.5;
    XMID=RT4BIS+DX;
    


minnn = InitialDUTh(2);
maxx = XMID;
DTh=[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];


[CnLrelative_Th, Cn_accumulated_relative_Th, Cnr_Th,fn,Dn_Th,Lnexp_Th] = Shaw_incremental_continuousIncrease(DTh,FRetained,n_end,meltInc);
Cnr_Th = [1 Cnr_Th(1:end-1)]; 


clear meltsSoFar CompleteIngrowthPooledMelts
for z = 1:size(Lnexp_U,2)
    meltsSoFar = Lnexp_U(1:z)./sum(Lnexp_U(1:z)); 

    AvgTh_z(z) = CnLrelative_Th(1:z)*meltsSoFar'; 
    AvgTh_R_z(z) = Cnr_Th(1:z)*meltsSoFar'; 
end
RaTh_Source = 1; 
ZeroIngrowth_Pool_Ra226 = (AvgRa_z./AvgTh_z)./RaTh_Source;
CompleteIngrowth_Pool_Ra226= (AvgRa_z./AvgTh_z)./(AvgRa_R_z./AvgTh_R_z); 
CompleteIngrowthIncrementalMelts = (CnLrelative_Ra./CnLrelative_Th)./(Cnr_Ra./Cnr_Th);

FMID = CompleteIngrowth_Pool_Ra226(ff) - desired226RaExcess; 

    if FMID < 0; 
        RT4BIS=XMID; 
    end
    
    if abs(FMID) < XACC ||  FMID == 0;
        RT4BIS=XMID; %SB: put this here to prevent errors occuring when the F is initially < 0.  
        break; 
    end
   
end

FinalDTh = RT4BIS;


%%


%Newton Raphson parameters
XACC = 1e-6;
X1 = .5;
X2 = 0.000001;
JMAX=1000;



minnn = InitialDUTh(2);
maxx = FinalDTh;
DTh=[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];

%initial guess
minnn = InitialDUTh(1);
maxx = X1;
DU=[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];



[CnLrelative_U, Cn_accumulated_relative_U, Cnr_U,fn,Dn_U,Lnexp_U] = Shaw_incremental_continuousIncrease(DU,FRetained,n_end,meltInc);
[CnLrelative_Th, Cn_accumulated_relative_Th, Cnr_Th,fn,Dn_Th,Lnexp_Th] = Shaw_incremental_continuousIncrease(DTh,FRetained,n_end,meltInc);
Cnr_U = [1 Cnr_U(1:end-1)]; 
Cnr_Th = [1 Cnr_Th(1:end-1)]; 


clear meltsSoFar CompleteIngrowthPooledMelts
for z = 1:size(Lnexp_U,2)
    meltsSoFar = Lnexp_U(1:z)./sum(Lnexp_U(1:z)); 

    AvgTh_z(z) = CnLrelative_Th(1:z)*meltsSoFar';
    AvgU_z(z) = CnLrelative_U(1:z)*meltsSoFar';
    
    AvgTh_R_z(z) = Cnr_Th(1:z)*meltsSoFar';
    AvgU_R_z(z) = Cnr_U(1:z)*meltsSoFar';  
end
ThU_Source = 1; 
ZeroIngrowth_Pool= (AvgTh_z./AvgU_z)./ThU_Source;
CompleteIngrowth_Pool= (AvgTh_z./AvgU_z)./(AvgTh_R_z./AvgU_R_z); 
CompleteIngrowthIncrementalMelts = (CnLrelative_Th./CnLrelative_U)./(Cnr_Th./Cnr_U); 

F = CompleteIngrowth_Pool(ff) - desired230ThExcess; 

if F < 0
    RT4BIS=X1;
    DX=X2-X1;
else
    RT4BIS=X2;
    DX=X1-X2;
end



for J = 1:JMAX
    DX=DX*.5;
    XMID=RT4BIS+DX;
    
    minnn = InitialDUTh(1);
    maxx = XMID;
    DU=[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];

    [CnLrelative_U, Cn_accumulated_relative_U, Cnr_U,fn,Dn_U,Lnexp_U] = Shaw_incremental_continuousIncrease(DU,FRetained,n_end,meltInc);
    Cnr_U = [1 Cnr_U(1:end-1)]; 
    
clear meltsSoFar CompleteIngrowthPooledMelts
for z = 1:size(Lnexp_U,2)
    meltsSoFar = Lnexp_U(1:z)./sum(Lnexp_U(1:z)); 

    AvgU_z(z) = CnLrelative_U(1:z)*meltsSoFar';
   
    AvgU_R_z(z) = Cnr_U(1:z)*meltsSoFar';  
end
ThU_Source = 1; 
ZeroIngrowth_Pool= (AvgTh_z./AvgU_z)./ThU_Source;
CompleteIngrowth_Pool= (AvgTh_z./AvgU_z)./(AvgTh_R_z./AvgU_R_z); 
CompleteIngrowthIncrementalMelts = (CnLrelative_Th./CnLrelative_U)./(Cnr_Th./Cnr_U); 

FMID = CompleteIngrowth_Pool(ff) - desired230ThExcess; 

    if FMID < 0; 
        RT4BIS=XMID; 
    end
    
    if abs(FMID) < XACC ||  FMID == 0;
        RT4BIS=XMID; %SB: put this here to prevent errors occuring when the F is initially < 0.  
        break; 
    end
   
end




%
FinalDUTh = [RT4BIS FinalDTh];
maxFn = fn(ff);
% ff



end

