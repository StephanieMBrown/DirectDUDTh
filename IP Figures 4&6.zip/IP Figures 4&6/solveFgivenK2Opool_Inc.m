function [RT4BIS] = solveFgivenK2Opool_Inc(D1,D2,Cl,Co,FRetained,meltInc)

% givens:
%     D = 0.001; 
%     Cl = 0.01; 
%     Co = 0.002; 
    
    %known:
    ClCo_desired = Cl./Co; 

% solving for: F via Newton Raphson  
     
XACC = 1e-6;
X1 = .9;
X2 = meltInc;
JMAX=1000;
%initial guess
%ClCo = (1-(1-X1).^(1./D))./X1;


    
    Fmax = X1; 
    meltfraction = meltInc;
    Wo =1;% initial mass, grams
    l = meltfraction; % constant melt mass, grams
    F1 = l./Wo; % initial melt fraction, percent
    ff = log(1-Fmax)/log(1-F1);
    ff = round(ff); 
    n_end = ff;
    
    n=1:n_end;  %# of steps
    fn = 1 - (1-F1).^n; 
    ignoreliquids = find(fn<FRetained); 
    ignoreliquids = max(ignoreliquids);
    if ignoreliquids==size(fn,2)
    ignoreliquids = 1; 
    end
    minnn = D1; 
    maxx = D2; 
    D_array=[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];
    %D_array=D.*ones(1,n_end); %[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];


    [CnLrelative_K, Cn_accumulated_relative_K] = Shaw_incremental_continuousIncrease(D_array, FRetained,n_end,meltInc);
    ClCo = Cn_accumulated_relative_K(end); 
    F = ClCo- ClCo_desired ;

if F < 0
    RT4BIS=X1;
    DX=X2-X1;
else
    RT4BIS=X2;
    DX=X1-X2;
end


for J = 1:JMAX
    DX=DX*.5;
    XMID=RT4BIS+DX;
      

    
     %ClCo = (1-(1-XMID).^(1./D))./XMID; 
    
    Fmax = XMID; 
    meltfraction = meltInc;
    Wo =1;% initial mass, grams
    l = meltfraction; % constant melt mass, grams
    F1 = l./Wo; % initial melt fraction, percent
    ff = log(1-Fmax)/log(1-F1);
    ff = round(ff); 
    n_end = ff;
    n=1:n_end;  %# of steps
    fn = 1 - (1-F1).^n; 
    ignoreliquids = find(fn<FRetained); 
    ignoreliquids = max(ignoreliquids);
    if ignoreliquids==size(fn,2)
    ignoreliquids = 1; 
    end
    minnn = D1; 
    maxx = D2; 
    D_array=[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];
    %D_array=D.*ones(1,n_end); %[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];

    
%     minnn = D; 
%     maxx = D; 
%     D_array=D.*ones(1,n_end); %[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];


    [CnLrelative_K, Cn_accumulated_relative_K] = Shaw_incremental_continuousIncrease(D_array, FRetained,n_end,meltInc);
    ClCo = Cn_accumulated_relative_K(end); 
    
     FMID = ClCo- ClCo_desired ;
    
    
    if FMID < 0; 
        RT4BIS=XMID; 
    end
    
    if abs(FMID) < XACC ||  FMID == 0;
        RT4BIS=XMID; %SB: put this here to prevent errors occuring when the F is initially < 0.  
        break; 
    end
   
end



end

