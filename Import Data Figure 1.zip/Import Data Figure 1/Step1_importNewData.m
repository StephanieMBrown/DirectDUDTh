
close all
clear all


% THINGS TO CHANGE:

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

SpreadsheetName = 'earthchem_download_22873_ALL_UTHDIseq';  
TabNames  = {'AllUTh'}; 
MAT_FileName2save = 'AllUTh';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% END OF THINGS TO CHANGE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


load('targetStrings_Trace.mat')
ElementRatios= {'Th' 'U'; 'Lu' 'Hf'; 'Sm' 'Nd'; 'Lu' 'Sc'; 'Hf' 'Nd'; 'La' 'Sm'; 'Rb' 'Sr'; 'Eu' 'Sm'; 'Eu' 'Gd'; 'Nd' 'Zr'; 'Sm' 'Yb'; 'Zr' 'Y'; 'Nb' 'Y'; 'Gd' 'Yb';  'Zr' 'Yb'; 'Zr' 'Hf'; 'Nb' 'Ta'; 'Ba' 'La'; 'Ba' 'Pb'; 'U' 'Pb'; 'K' 'U'}; 

targetStrings_Majors = {'Temp','Pressure','SiO2','TiO2','Al2O3', 'Cr2O3','FeO','MnO','MgO','CaO','Na2O','K2O','P2O5','NiO','H2O'}; 
%targetStrings_Isotopes = {'87Sr/86Sr'	'143Nd/144Nd'	'206Pb/204Pb'	'207Pb/204Pb'	'208Pb/204Pb'	'176Hf/177Hf' 'TH230_U238_ACTIVITY'};
targetStrings_Isotopes = {'SR87_SR86'	'ND143_ND144'	'PB206_PB204'	'PB207_PB204'	'PB208_PB204'	'HF176_HF177' 'TH230_U238_ACTIVITY' 'TH230_TH232_ACTIVITY' 'U238_TH232_ACTIVITY' 'RA226_TH230_ACTIVITY'};

clear DataRatios
for gg = 1:size(ElementRatios,1)
    for ggg = 1:size(ElementRatios,2)
%         %for major and trace element matricies:
%         ElementRatiosIndex(gg,ggg) =  find(strcmp(targetStrings_Trace_all,ElementRatios(gg,ggg)));
        %for trace element only matricies:
        ElementRatiosIndex(gg,ggg) =  find(strcmp(targetStrings_Trace,ElementRatios(gg,ggg)));
    end
end


for kk = 1:size(ElementRatios,1)
    RatioLabels{kk}=sprintf('%s/%s',ElementRatios{kk,1}, ElementRatios{kk,2});
end


%KEY
% 10= MORB in petdb
% 9= MORB in georock
% 8= MORB? in georock (e.g., Iceland)
% 8.5= MORB? in georock (e.g., Azores)

% 7 = Backarc in petdb
% 6 = ARC in petdb



for i=1:size(TabNames,2)   
    %reads the names off sheets in a tab and stores them as variables
    column2unnormalize=[]; 
    [MajorElements, Major_Labels, Major_Colors,Dummy,Major_Series,Major_Markers,VolcanismType] = reorderElements_Rows(SpreadsheetName, TabNames{i}, 'PlotOn', targetStrings_Majors,'FirstMajor','LastMajor',column2unnormalize ); 

    
    [TraceElements, Trace_Labels] = reorderElements_Rows(SpreadsheetName, TabNames{i}, 'PlotOn', targetStrings_Trace,'FirstTraceIsotope','LastTraceIsotope',column2unnormalize ); 
    [CorrectedMajorElements] = reorderElements_Rows(SpreadsheetName, TabNames{i}, 'PlotOn', targetStrings_Majors,'FirstMajorCorrected','LastMajorCorrected',column2unnormalize ); 

     %assignin('base', (TabNames{i}),sumMgNumNorm(xlsread('master_data',char(TabNames(i)))));  
     assignin('base', [TabNames{i},'_Colors'],Major_Colors);    
     
      assignin('base', (TabNames{i}),sumMgNumNorm_PT(MajorElements));    
      assignin('base', (TabNames{i}),sumMgNumNorm_PT(CorrectedMajorElements));   
    
      

    assignin('base', [TabNames{i},'_Trace'],TraceElements);    
    
    % if you don't want to normalize use this instead:
     %   assignin('base', (TabNames{i}),data);      
    
    assignin('base', [TabNames{i},'_samples'],Major_Labels);    
    
    %calculates the Tormey components of all the data 
    assignin('base', [TabNames{i},'_Tormey'],TormeyProjection(eval([TabNames{i},'(:,3:14)'])));
    
    
% %     
   [Isotopes, Isotope_Labels] = reorderElements_Rows(SpreadsheetName, TabNames{i}, 'PlotOn', targetStrings_Isotopes,'FirstTraceIsotope','LastTraceIsotope',column2unnormalize ); 
    assignin('base', [TabNames{i},'_Isotopes'],Isotopes);   

    
clear DataRatios
for gg = 1:size(ElementRatios,1)
    DataRatios(:,gg) = TraceElements(:,ElementRatiosIndex(gg,1)) ./TraceElements(:,ElementRatiosIndex(gg,2)); 
    assignin('base',sprintf('%s_DataRatios',TabNames{i}), DataRatios); 
end



end

AllUTh = sumMgNumNorm_PT(MajorElements); 
AllUTh_Primary = sumMgNumNorm_PT(CorrectedMajorElements); 
AllUTh_Colors = Major_Colors; 
AllUTh_Series = Major_Series; 
%AllUTh_Series = cellfun(@str2num, AllUTh_Series);
AllUTh_Markers = Major_Markers;
AllUTh_Isotopes = Isotopes; 
AllUTh_DataRatios = DataRatios; 
AllUTh_VolcanismType = VolcanismType; 
AllUTh_Trace = TraceElements; 

targetStrings_Majors = {'Temp','Pressure','SiO2','TiO2','Al2O3', 'Cr2O3','FeO','MnO','MgO','CaO','Na2O','K2O','P2O5','NiO','H2O','SUM','Mg#','NaK#','CaO/Al2O3','Ca/Al','K2O/TiO2'}; 


[xlsNumbers, xlsText,xlsRAW] = xlsread(SpreadsheetName, 'TraceElementOrder');
[ElementRow,ElementColumn]= find(strcmp(xlsRAW,'Elements')==1); 
[LastElementRow,LastElementColumn]= find(strcmp(xlsRAW,'LastElement')==1); 
% Matrix with element labels
targetStrings_Trace = xlsRAW(ElementRow+1:LastElementRow-1, ElementColumn)'; 
%gets PUM composition to normalize by

xlsRAW_strings=cellfun(@num2str,xlsRAW,'un',0); 
[DRow,DColumn]= find(strcmp(xlsRAW_strings,'PUM')==1); 
%[DRow,DColumn]= find(~cellfun(@isempty,regexp(xlsRAW_strings,'Norm_PUM')) ==1); 
Norm_PUM_Labels = (xlsRAW(unique(DRow+1),DColumn)); 
Norm_PUM = (xlsRAW(ElementRow+1:LastElementRow-1,DColumn)); 
%%
%fixes the NaN issue
i1 = cellfun(@ischar,Norm_PUM);
sz = cellfun('size',Norm_PUM(~i1),2);
Norm_PUM(i1) = {nan(1,sz(1))};
Norm_PUM = cell2mat(Norm_PUM)'; 

clear DataRatios
for gg = 1:size(ElementRatios,1)
    DataRatios(:,gg) = Norm_PUM(:,ElementRatiosIndex(gg,1)) ./Norm_PUM(:,ElementRatiosIndex(gg,2)); 
end
assignin('base',sprintf('%s_DataRatios','Norm_PUM'), DataRatios); 


save(sprintf('%s',MAT_FileName2save)
