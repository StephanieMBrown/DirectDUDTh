close all
clear all
addpath('Helpful Scripts')
addpath('Preloaded Data')
load('AllUTh')
load('Gale_8_10N_EPR')
load('AllGalewithK2O')

ColorsHERE
load('TraceElements')
fontsizelines=15;
%%

EarthChem_MarkerSizes=str2double(AllUTh_Colors);
unique(EarthChem_MarkerSizes, 'stable')

    
AllUTh_Series=str2double(AllUTh_Series);



%KEY
% 10= MORB in petdb
% 9= MORB in georock
% 8= MORB? in georock (e.g., Iceland and Azores)
% 7 = Backarc in petdb
% 6 = ARC in petdb
Colors2plot = repmat([cadmiumgreen],size(EarthChem_MarkerSizes,1),1);

Factor=100; 
Sizes=[1 2 .5 .5 1 1];

Colors2plot = repmat([cadmiumgreen],size(EarthChem_MarkerSizes,1),1);



tempIndices_MORB = find(EarthChem_MarkerSizes==10);

tempIndices = find(EarthChem_MarkerSizes==9);
Colors2plot(tempIndices,:)=repmat([fuschia],size(tempIndices,1),1); 
tempIndices_MORB_GeoRock = tempIndices; 


tempIndices = find(EarthChem_MarkerSizes==8);
Colors2plot(tempIndices,:)=repmat([grey3],size(tempIndices,1),1); 
tempIndices_SeamountsinGeoRock = tempIndices; 


tempIndices = find(EarthChem_MarkerSizes==8.5);
Colors2plot(tempIndices,:)=repmat([grey3],size(tempIndices,1),1); 
tempIndices_SeamountsinGeoRock2 = tempIndices; 

tempIndices_BackArcs = find(EarthChem_MarkerSizes==7);
% Colors2plot(tempIndices,:)=repmat([cadmiumgreen],size(tempIndices,1),1); 

tempIndices = find(EarthChem_MarkerSizes==6);
Colors2plot(tempIndices,:)=repmat([grey3],size(tempIndices,1),1); 
tempIndices_Arc = tempIndices; 

tempIndices = find(EarthChem_MarkerSizes==5);
Colors2plot(tempIndices,:)=repmat([grey3],size(tempIndices,1),1); 
tempIndices_GeoRock = tempIndices; 

tempIndices_OIBS = find(EarthChem_MarkerSizes==4);

BackArcs = tempIndices_BackArcs; %7 
MORBs = [ tempIndices_MORB; tempIndices_MORB_GeoRock];% 10, 9 
PlumeRidge = [ tempIndices_SeamountsinGeoRock; tempIndices_SeamountsinGeoRock2]; %8, 8.5
Arcs = [tempIndices_Arc; tempIndices_GeoRock]; % 6, 5
OIBS = tempIndices_OIBS; 



EarthChem_MarkerSizes(EarthChem_MarkerSizes==5)=5; 
EarthChem_MarkerSizes(EarthChem_MarkerSizes==10)=100;

EarthChem_MarkerSizes(EarthChem_MarkerSizes==9)=100; 
EarthChem_MarkerSizes(EarthChem_MarkerSizes==8)=5;
EarthChem_MarkerSizes(EarthChem_MarkerSizes==8.5)=5;
EarthChem_MarkerSizes(EarthChem_MarkerSizes==7)=100;
EarthChem_MarkerSizes(EarthChem_MarkerSizes==6)=5;



%     {'ARC'        }
%     {'BACKARC'    }
%     {'CONTINENTAL'}
%     {'MIX'        }
%     {'MORB'       }
%     {'OIB'        }
%     {'ICELAND' }
%     {'AZORES' }
%     {'RIFT'       }
    
ARC_indicies = strcmp(AllUTh_VolcanismType,'ARC');
BACKARC_indicies = strcmp(AllUTh_VolcanismType,'BACKARC');
CONTINENTAL_indicies = strcmp(AllUTh_VolcanismType,'CONTINENTAL');
MIX_indicies = strcmp(AllUTh_VolcanismType,'MIX');
MORB_indicies = strcmp(AllUTh_VolcanismType,'MORB');
MORB_indicies_test = find(strcmp(AllUTh_VolcanismType,'MORB'));
OIB_indicies = strcmp(AllUTh_VolcanismType,'OIB');
ICELAND_indicies = strcmp(AllUTh_VolcanismType,'ICELAND');
AZORES_indicies = strcmp(AllUTh_VolcanismType,'AZORES');
RIFT_indicies = strcmp(AllUTh_VolcanismType,'RIFT');

%%


%highlight series

%for Newman1982
% EarthChem_MarkerSizes(AllUTh_Series==1)=300;
% tempIndices = find(AllUTh_Series==1);
% Colors2plot(tempIndices,:)=repmat([fuschia],size(tempIndices,1),1); 
%blurb = 'Newman et al 1983';

%for Sims2002
EarthChem_MarkerSizes(AllUTh_Series==2)=30;
tempIndices = find(AllUTh_Series==2);
Colors2plot(tempIndices,:)=repmat([CadmiumRed],size(tempIndices,1),1); 
tempIndices_EPR = tempIndices; 


EarthChem_MarkerSizes(AllUTh_Series==3)=22;
tempIndices = find(AllUTh_Series==3);
Colors2plot(tempIndices,:)=repmat([androidgreen],size(tempIndices,1),1); 
tempIndices_Seamount =tempIndices; 

EarthChem_MarkerSizes(AllUTh_Series==4)=20;
tempIndices = find(AllUTh_Series==4);
Colors2plot(tempIndices,:)=repmat([azure],size(tempIndices,1),1); 
tempIndices_Siqueros = tempIndices; 

EarthChem_MarkerSizes(AllUTh_Series==4.5)=20;
tempIndices = find(AllUTh_Series==4.5);
Colors2plot(tempIndices,:)=repmat([airsuperiorityblue],size(tempIndices,1),1); 
tempIndices_SiquerosDMORB = tempIndices; 


%EarthChem_MarkerSizes(AllUTh_Series==7)=20;
tempIndices = find(AllUTh_Series==9);
%Colors2plot(tempIndices,:)=repmat([azure],size(tempIndices,1),1); 
tempIndices_SMR = tempIndices; 


%EarthChem_MarkerSizes(AllUTh_Series==7)=20;
tempIndices = find(AllUTh_Series==7);
%Colors2plot(tempIndices,:)=repmat([azure],size(tempIndices,1),1); 
tempIndices_JM = tempIndices; 


%EarthChem_MarkerSizes(AllUTh_Series==8)=20;
tempIndices = find(AllUTh_Series==8);
%Colors2plot(tempIndices,:)=repmat([azure],size(tempIndices,1),1); 
tempIndices_NKR = tempIndices; 

%EarthChem_MarkerSizes(AllUTh_Series==7)=20;
tempIndices = find(AllUTh_Series==8.5);
%Colors2plot(tempIndices,:)=repmat([azure],size(tempIndices,1),1); 
tempIndices_NKR_no226Ra = tempIndices; 


Gale_MajorTrace_Region_ST_Indicies = find(strcmp(Gale_Glass_Regions,'ST'));
Gale_MajorTrace_Region_EPR_Indicies = find(strcmp(Gale_Glass_Regions,'OnAxis')) ;
%%
% figure(1)
% close
% figure(1); hold on
figure()
hold on
axisgood =[.4 1.8 .7 1.8]; % [.4 3 .4 3]
LegendLabels = {'All Earthchem' 'Seamounts' 'EPR' 'Siqueros Transform' 'PETDB MORB' 'GEOROC'  'MORB in GEOROC' };

% control legend
% A = unique( hhh.CData, 'rows');
% A = [[1 1 1]; A];
% Factor=100; 
% Sizes=[1 1 1 1 1 1];
% LegendLabels = {'','1','2','3','Azores','MORB in GEOROC',blurb}


Desired_X ={'U238_TH232_ACTIVITY'};
Desired_Y ={'TH230_TH232_ACTIVITY'};

[a,indiciesX] = ismember(Desired_X,targetStrings_Isotopes);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);






plot(AllUTh_Isotopes(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
plot(AllUTh_Isotopes(ARC_indicies,indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh_Isotopes(OIB_indicies,indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)

% plot(AllUTh_Trace(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'v','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',5)
% plot(AllUTh_Trace(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',cadmiumgreen, 'MarkerFaceColor',cadmiumgreen,'MarkerSize',5)
%  
% plot(AllUTh_Trace(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor',white,'MarkerSize',7)
% plot(AllUTh_Trace(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), '>','Color','k', 'MarkerFaceColor',olivinegreen,'MarkerSize',5)
% plot(AllUTh_Trace(RIFT_indicies,indiciesX),AllUTh_Isotopes(RIFT_indicies,indiciesY), 'o','Color',articlime, 'MarkerFaceColor',articlime,'MarkerSize',5)

plot(AllUTh_Isotopes(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh_Isotopes(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh_Isotopes(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh_Isotopes(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)


plot(AllUTh_Isotopes(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh_Isotopes(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh_Isotopes(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)


newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB' 'EarthChem MORB',...
    'Jan Mayen' 'N. Kob. Ridge' 'S. Mohns Ridge'...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN on/near axis EPR'...
    };
legend(newLegendLabels,'Location','SouthEast','FontSize',10,'autoupdate','off')



% lgd = legend(['All EarthChem' ],'Location','SouthEast','AutoUpdate','off');
% set(lgd,'Position',[0.6350 0.1661 0.2132 0.2267])
% lgd.FontSize = 9;
%      

%set(gca,'ticklength',2*get(gca,'ticklength'))
set(gca,'fontsize', 15,'LineWidth',1, 'FontName','TimesNewRoman')
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
%xlabel('activity ratio (black), activity ratio approx (red), Th/U N (green)')
xlabel('(^{238}U/^{232}Th)')
ylabel('(^{230}Th/^{232}Th)')


hline=refline(.95,0);
hline.Color = 'k';
uistack(hline,'bottom');


hline=refline(.9,0);
hline.Color = 'k';
uistack(hline,'bottom');


hline=refline(.8,0);
hline.Color = 'k';
uistack(hline,'bottom');


hline=refline(1,0);
hline.Color = 'k';
hline.LineWidth = 3;
uistack(hline,'bottom');
                 

hline=refline(1.05,0);
hline.Color = 'k';
uistack(hline,'bottom');

hline=refline(1.1,0);
hline.Color = 'k';
uistack(hline,'bottom');

hline=refline(1.2,0);
hline.Color = 'k';
uistack(hline,'bottom');

hline=refline(1.3,0);
hline.Color = 'k';
uistack(hline,'bottom');

hline=refline(1.4,0);
hline.Color = 'k';
uistack(hline,'bottom');

hline=refline(1.5,0);
hline.Color = 'k';
uistack(hline,'bottom');

hline=refline(1.6,0);
hline.Color = 'k';
uistack(hline,'bottom');

hline=refline(1.8,0);
hline.Color = 'k';
uistack(hline,'bottom');


hline=refline(2,0);
hline.Color = 'k';
uistack(hline,'bottom');


%text(1.6,1.6,'O%')
text(1.6,1.66,'Equiline','Rotation',45,'FontWeight','Bold', 'VerticalAlignment','top','FontSize',15)
                  
text(1.67,1.6,'-5%','FontWeight','Bold','FontSize',15,'Rotation',45)
text(1.7,1.55,'-10%','FontWeight','Bold','FontSize',15,'Rotation',45)
text(1.7,1.38,'-20%','FontWeight','Bold','FontSize',15,'Rotation',45)     
text(1.6,1.7,'5%','FontWeight','Bold','FontSize',15,'Rotation',45)
text(1.55,1.7,'10%','FontWeight','Bold','FontSize',15,'Rotation',45)
text(1.44,1.7,'20%','FontWeight','Bold','FontSize',15,'Rotation',45)
text(1.3,1.7,'30%','FontWeight','Bold','FontSize',15,'Rotation',45)
text(1.08,1.7,'60%','FontWeight','Bold','FontSize',15,'Rotation',60)
text(.96,1.7,'80%','FontWeight','Bold','FontSize',15,'Rotation',60)
text(.86,1.7,'100%','FontWeight','Bold','FontSize',15,'Rotation',60)




%set(gcf,'Position',[360 103 638 602])
%set(gcf,'Position',[484 336 846 649])

%axis([.6 1.8 .6 1.8])
axis(axisgood)
%axis square

box on
%axis([1 15 0 2 ])
%set(gca, 'ytick',0:.1:2)
    %   set(gca,'yscale','log')
% %axis([1,numberElements,10^-1,100])
% axis([1,numberElements,.1,1000])
% %axis([1,numberElements,.1,100])

incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
%set(gca,'ticklength',ticklengthgood)
set(gca,'fontsize', 16,'LineWidth',1)
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
%axis square
ax = gca;
set(gca, 'Xtick',[.6:incrementtotal:1.8])
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';
increment = incrementtotal./2; 

ax.XAxis.MinorTickValues = ax.XLim(1):increment:ax.XLim(2);

set(gca, 'Ytick',[.6:incrementtotal:1.8])
%increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.YAxis.MinorTickValues = ax.YLim(1):increment:ax.YLim(2);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
               FigureTitle = 'Equiline';
set(gcf,'name',regexprep(FigureTitle,'\_*','')) 

 
set(gcf','Position',[704 386 797 592])             
axis equal

test = ax.YTick    ;
set(gcf,'name',regexprep(FigureTitle,'\_*',''))  
yyaxis right
yy=3.034./test;
axis(axisgood)
set(gca, 'Ytick',[.6:incrementtotal:1.8])
ax.YAxis(2).MinorTick = 'on';
ax.YAxis(2).MinorTickValues = ax.YAxis(1).MinorTickValues;
set(gca, 'Yticklabels',num2str(yy',2))
ax.YAxis(2).Color=black;
ylabelax.YAxis(2).Color=black;
ylabel('Th/U Source')



%%


axisgood=...
    [0 2 0.5 1.6;
    0 6 0.5 1.6 
    0 9 0.5 1.6 ];

Desired_X_all ={'Th/U' 'La/Sm' 'Sm/Yb'};

Desired_Y ={'TH230_U238_ACTIVITY'};
%%close all
for i=1:size(Desired_X_all,2)
    figure(); 
    hold on
Desired_X=Desired_X_all{i};
[a,indiciesX] = ismember(Desired_X,RatioLabels);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off','LineWidth',2,'LabelVerticalAlignment','middle');


plot(AllUTh_DataRatios(:,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
plot(AllUTh_DataRatios(ARC_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh_DataRatios(OIB_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)

plot(AllUTh_DataRatios(CONTINENTAL_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'v','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',5)
plot(AllUTh_DataRatios(BACKARC_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',cadmiumgreen, 'MarkerFaceColor',cadmiumgreen,'MarkerSize',5)
plot(AllUTh_DataRatios(ICELAND_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor',white,'MarkerSize',7)
plot(AllUTh_DataRatios(AZORES_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), '>','Color','k', 'MarkerFaceColor',olivinegreen,'MarkerSize',5)
plot(AllUTh_DataRatios(RIFT_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(RIFT_indicies,indiciesY), 'o','Color',articlime, 'MarkerFaceColor',articlime,'MarkerSize',5)


plot(AllUTh_DataRatios(MORB_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh_DataRatios(tempIndices_JM,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_NKR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_SMR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_Seamount,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_Siqueros,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_EPR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)


plot(AllUTh_DataRatios(tempIndices_EPR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)



newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB',...
    'Cont' 'BackArc' 'Iceland' 'Azores' 'Rift'...
    'EarthChem MORB'...
    'Jan Mayen' 'N. Kob. Ridge' 'S. Mohns Ridge'...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN on/near axis EPR'...
    };
legend(newLegendLabels,'Location','SouthEast','FontSize',10,'autoupdate','off')






xlabel([Desired_X ' norm to PUM'],'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');


% xlabel(sprintf('%s normalized to {%s}',RatioLabels{xxvalue}, normalizationLabel));
% ylabel(sprintf('%s normalized to {%s}',RatioLabels{yyvalue}, normalizationLabel));

if strcmp( Desired_X ,'Th/U')==1
refline(Norm_PUM_DataRatios(indiciesX)/2.5,0)
refline(Norm_PUM_DataRatios(indiciesX)/3.9,0)
refline(0,1)
end

axis square
box on

incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1)
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


%set(gca, 'Xtick',[.6:incrementtotal:1.8])
increment = .5; 
%increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.XAxis.MinorTickValues = ax.XLim(1):increment:ax.XLim(2);

increment = .1;
ax.YAxis.MinorTickValues = ax.YLim(1):increment:ax.YLim(2);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
%set(gca, 'Ytick',[.6:incrementtotal:1.8])
axis(axisgood(i,:))
FigureTitle = sprintf('ThU230Th v %s',Desired_X);
set(gcf,'name',regexprep(FigureTitle,'/_*','')) 
set(gcf','Position',[654 337 627 592])             


end



%%


axisgood=...
    [.4 50 0.1 20;
    .4 50 0.2 3
     .4 50 0.2 3
      .04 4 .2 3
      .4 50 0.2 3
      .04 4 .4 1.6];

Desired_X_all ={'Sm/Yb' 'Lu/Hf'};
Desired_Y_all ={'La/Sm' 'Th/U' 'Sm/Nd'};
n=1; 
%%close all
for j=1:size(Desired_X_all,2)
for i=1:size(Desired_Y_all,2)
    
    figure(); 
    hold on
Desired_X=Desired_X_all{j};
Desired_Y=Desired_Y_all{i};
[a,indiciesX] = ismember(Desired_X,RatioLabels);
[b,indiciesY] = ismember(Desired_Y,RatioLabels);



plot(Gale_5_Master_TE_Iso_Edited_DataRatios(:,indiciesX)./Norm_PUM_DataRatios(indiciesX),Gale_5_Master_TE_Iso_Edited_DataRatios(:,indiciesY)./Norm_PUM_DataRatios(indiciesY), 'o','Color',grey6, 'MarkerFaceColor',grey6,'MarkerSize',2)


plot(AllUTh_DataRatios(:,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(:,indiciesY)./Norm_PUM_DataRatios(indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
plot(AllUTh_DataRatios(ARC_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(ARC_indicies,indiciesY)./Norm_PUM_DataRatios(indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh_DataRatios(OIB_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(OIB_indicies,indiciesY)./Norm_PUM_DataRatios(indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)

plot(AllUTh_DataRatios(CONTINENTAL_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(CONTINENTAL_indicies,indiciesY)./Norm_PUM_DataRatios(indiciesY), 'v','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',5)
plot(AllUTh_DataRatios(BACKARC_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(BACKARC_indicies,indiciesY)./Norm_PUM_DataRatios(indiciesY), 's','Color',cadmiumgreen, 'MarkerFaceColor',cadmiumgreen,'MarkerSize',5)
plot(AllUTh_DataRatios(ICELAND_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(ICELAND_indicies,indiciesY)./Norm_PUM_DataRatios(indiciesY), 'o','Color','k', 'MarkerFaceColor',white,'MarkerSize',7)
plot(AllUTh_DataRatios(AZORES_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(AZORES_indicies,indiciesY)./Norm_PUM_DataRatios(indiciesY), '>','Color','k', 'MarkerFaceColor',olivinegreen,'MarkerSize',5)
plot(AllUTh_DataRatios(RIFT_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(RIFT_indicies,indiciesY)./Norm_PUM_DataRatios(indiciesY), 'o','Color',articlime, 'MarkerFaceColor',articlime,'MarkerSize',5)


plot(AllUTh_DataRatios(MORB_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(MORB_indicies,indiciesY)./Norm_PUM_DataRatios(indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh_DataRatios(tempIndices_JM,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(tempIndices_JM,indiciesY)./Norm_PUM_DataRatios(indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_NKR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(tempIndices_NKR,indiciesY)./Norm_PUM_DataRatios(indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_SMR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(tempIndices_SMR,indiciesY)./Norm_PUM_DataRatios(indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_Seamount,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(tempIndices_Seamount,indiciesY)./Norm_PUM_DataRatios(indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_Siqueros,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(tempIndices_Siqueros,indiciesY)./Norm_PUM_DataRatios(indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_EPR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(tempIndices_EPR,indiciesY)./Norm_PUM_DataRatios(indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)


plot(AllUTh_DataRatios(tempIndices_EPR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_DataRatios(tempIndices_EPR,indiciesY)./Norm_PUM_DataRatios(indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)

plot(Gale_MajorTrace_DataRatios(:,indiciesX)./Norm_PUM_DataRatios(indiciesX),Gale_MajorTrace_DataRatios(:,indiciesY)./Norm_PUM_DataRatios(indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',8,'HandleVisibility','off')



newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB',...
    'Cont' 'BackArc' 'Iceland' 'Azores' 'Rift'...
    'EarthChem MORB'...
    'Jan Mayen' 'N. Kob. Ridge' 'S. Mohns Ridge'...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN on/near axis EPR'...
    };
legend(newLegendLabels,'Location','SouthEast','FontSize',10,'autoupdate','off')



xline(1,'k-'); 
yline(1,'k-'); 

xlabel([Desired_X ' norm to PUM'],'Interpreter', 'none');
ylabel([Desired_Y ' norm to PUM'],'Interpreter', 'none');


% xlabel(sprintf('%s normalized to {%s}',RatioLabels{xxvalue}, normalizationLabel));
% ylabel(sprintf('%s normalized to {%s}',RatioLabels{yyvalue}, normalizationLabel));

if strcmp( Desired_X ,'Th/U')==1
refline(Norm_PUM_DataRatios(indiciesX)/2.5,0)
refline(Norm_PUM_DataRatios(indiciesX)/3.9,0)
refline(0,1)
end

axis square
box on

incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1)
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
   
   set(gca,'yscale','log')
   ax.YAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
   

axis(axisgood(n,:))
FigureTitle = sprintf('%s v %s',Desired_X,Desired_Y);
set(gcf,'name',regexprep(FigureTitle,'/_*','')) 
set(gcf','Position',[654 337 627 592])             

n=n+1; 

end
end


%%
axisgood=...
    [1e-2 20 .702 .714];

Desired_X_all ={'K2O' };
Desired_Y ={ 'SR87_SR86'};

%%close all
for i=1:size(Desired_X_all,2)
    figure(); 
    hold on
Desired_X=Desired_X_all{i};



[a,indiciesX] = ismember(Desired_X,targetStrings_Majors);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


% yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off');
if strcmp(Desired_X ,'K2O')==1
   xline(.096,'k:','0.096 D-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','top','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.14,'k:','0.14 N-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','top','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.394,'k:','0.394 E-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','top','LabelHorizontalAlignment','center','HandleVisibility','off');
end


%hhh = scatter(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), EarthChem_MarkerSizes,Colors2plot,'filled','MarkerFaceAlpha',1);
%hhh.MarkerFaceAlpha
% uistack(hhh,'bottom')
% axis(axisgood)

%gscatter(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), AllUTh_Series,'brgk','xosd',30,'filled');
%gscatter(ratings(:,1),ratings(:,2),AllUTh_Series,'brgk','xosd')


%scatter(AllUTh(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY),300, 'd', 'filled','MarkerFaceColor',fuschia); 
    %EarthChem_MarkerSizes(tempIndices_EPR(1),:),Colors2plot(tempIndices_EPR(1),:),'MarkerFaceAlpha',1);
 %tempIndices_Seamount tempIndices_Siqueros

plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)

plot(AllUTh(ARC_indicies,indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh(OIB_indicies,indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)


%  plot(AllUTh(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'o','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',3)
%  plot(AllUTh(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
%  plot(AllUTh(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'p','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)
 %plot(AllUTh(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), 'd','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)


%plot(AllUTh(MIX_indicies,indiciesX),AllUTh_Isotopes(MIX_indicies,indiciesY), 'o','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)

plot(AllUTh(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh(tempIndices_NKR_no226Ra,indiciesX),AllUTh_Isotopes(tempIndices_NKR_no226Ra,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',10)

plot(AllUTh(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)

plot(AllUTh(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)


plot(Gale_MajorTrace(:,indiciesX),Gale_MajorTrace_Isotopes(:,indiciesY), 'o','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',8,'HandleVisibility','off')

% 
% plot(AllUTh_Primary(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color',black, 'MarkerFaceColor','k','MarkerSize',10)
% plot(AllUTh_Primary(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color',black, 'MarkerFaceColor',androidgreen,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color',black, 'MarkerFaceColor',azure,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color',black, 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color',black, 'MarkerFaceColor',grey9,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey6,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey2,'MarkerSize',16)
% 



%newLegendLabels = {'Arcs' 'OIBs' 'Continental' 'Back Arc','Plume-Ridge','MORB','Seamounts','Siqueros Transform' 'EPR' };

newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB' 'EarthChem MORB',...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN EPR'...
    'Jan Mayen' 'N. Kob. Ridge' 'N. Kob. Ridge no 226' 'S. Mohns Ridge'...
    'First Melts of WHDMM','First Melts of HZPUM'};

newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB' 'EarthChem MORB',...
    'Jan Mayen' 'N. Kob. Ridge' 'N. Kob. Ridge no 226' ...
        'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN EPR'...
    'First Melts of WHDMM','First Melts of HZPUM'};


xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');
% xlabel(sprintf('%s normalized to {%s}',RatioLabels{xxvalue}, normalizationLabel));
% ylabel(sprintf('%s normalized to {%s}',RatioLabels{yyvalue}, normalizationLabel));
       %
% refline(1/2.5,0)
% refline(1/3.9,0)
% refline(0,1)



axis square
box on

%incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


%set(gca, 'Xtick',[.6:incrementtotal:1.8])
increment = .5; 
%increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.XAxis.MinorTickValues = ax.XLim(1):increment:ax.XLim(2);

increment = .05;
ax.YAxis.MinorTickValues = ax.YLim(1):increment:ax.YLim(2);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
%set(gca, 'Ytick',[.6:incrementtotal:1.8])



if strcmp(Desired_X ,'K2O')==1
set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end


         
% return
% 
% test = ax.YTick;
% set(gcf,'name',regexprep(FigureTitle,'\_*',''))  
% yyaxis right
% yy=3.034./test;
% axis(axisgood)
% set(gca, 'Ytick',[.6:incrementtotal:1.8])
% ax.YAxis(2).MinorTick = 'on';
% ax.YAxis(2).MinorTickValues = ax.YAxis(1).MinorTickValues;
% set(gca, 'Yticklabels',num2str(yy',2))
% 
% ax.YAxis(2).Color=black;
% ylabelax.YAxis(2).Color=black;

legend(newLegendLabels,'Location','Best','FontSize',10)
%axis(axisgood(i,:))
FigureTitle = sprintf('Sr87Sr86 v %s',Desired_X);
set(gcf,'name',regexprep(FigureTitle,'/_*','')) 
set(gcf','Position',[654 337 627 592])    
end



%%
axisgood=...
    [0 3 .702 .714
    .4 20 .702 .714
    0 3 .5122 .5133
    .4 20 .5122 .5133];


Desired_X_all ={'Th/U' 'Sm/Yb'};
Desired_Y_all ={ 'SR87_SR86' 'ND143_ND144'};

%%close all
n=1; 
for i=1:size(Desired_Y_all,2)
for j=1:size(Desired_X_all,2)
 
    
    figure(); 
    hold on
Desired_X=Desired_X_all{j};
Desired_Y=Desired_Y_all{i};


[a,indiciesX] = ismember(Desired_X,RatioLabels);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);



%hhh = scatter(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), EarthChem_MarkerSizes,Colors2plot,'filled','MarkerFaceAlpha',1);
%hhh.MarkerFaceAlpha
% uistack(hhh,'bottom')
% axis(axisgood)

%gscatter(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), AllUTh_Series,'brgk','xosd',30,'filled');
%gscatter(ratings(:,1),ratings(:,2),AllUTh_Series,'brgk','xosd')


%scatter(AllUTh(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY),300, 'd', 'filled','MarkerFaceColor',fuschia); 
    %EarthChem_MarkerSizes(tempIndices_EPR(1),:),Colors2plot(tempIndices_EPR(1),:),'MarkerFaceAlpha',1);
 %tempIndices_Seamount tempIndices_Siqueros

 
plot(Gale_5_Master_TE_Iso_Edited_DataRatios(:,indiciesX)./Norm_PUM_DataRatios(indiciesX),Gale_5_Master_TE_Iso_Edited_Isotopes(:,indiciesY), '.','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',8)

 
plot(AllUTh_DataRatios(:,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
plot(AllUTh_DataRatios(ARC_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh_DataRatios(OIB_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)






%  plot(AllUTh(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'o','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',3)
%  plot(AllUTh(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
%  plot(AllUTh(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'p','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)
 %plot(AllUTh(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), 'd','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)


%plot(AllUTh(MIX_indicies,indiciesX),AllUTh_Isotopes(MIX_indicies,indiciesY), 'o','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)

plot(AllUTh_DataRatios(MORB_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh_DataRatios(tempIndices_JM,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_NKR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_NKR_no226Ra,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_NKR_no226Ra,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',10)

plot(AllUTh_DataRatios(tempIndices_SMR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)

plot(AllUTh_DataRatios(tempIndices_Seamount,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_Siqueros,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_EPR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)


plot(Gale_MajorTrace_DataRatios(:,indiciesX)./Norm_PUM_DataRatios(indiciesX),Gale_MajorTrace_Isotopes(:,indiciesY), 'o','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',8,'HandleVisibility','off')




% plot(AllUTh_Primary(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color',black, 'MarkerFaceColor','k','MarkerSize',10)
% plot(AllUTh_Primary(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color',black, 'MarkerFaceColor',androidgreen,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color',black, 'MarkerFaceColor',azure,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color',black, 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color',black, 'MarkerFaceColor',grey9,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey6,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey2,'MarkerSize',16)
% 



%newLegendLabels = {'Arcs' 'OIBs' 'Continental' 'Back Arc','Plume-Ridge','MORB','Seamounts','Siqueros Transform' 'EPR' };

newLegendLabels = {'Gale' 'EarthChem' 'EarthChem Arcs' 'EarthChem OIB' 'EarthChem MORB',...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN EPR'...
    'Jan Mayen' 'N. Kob. Ridge' 'N. Kob. Ridge no 226' 'S. Mohns Ridge'...
    'First Melts of WHDMM','First Melts of HZPUM'};

newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB' 'EarthChem MORB',...
    'Jan Mayen' 'N. Kob. Ridge' 'N. Kob. Ridge no 226' ...
        'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN EPR'...
    'First Melts of WHDMM','First Melts of HZPUM'};


xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');
% xlabel(sprintf('%s normalized to {%s}',RatioLabels{xxvalue}, normalizationLabel));
% ylabel(sprintf('%s normalized to {%s}',RatioLabels{yyvalue}, normalizationLabel));
       %
% refline(1/2.5,0)
% refline(1/3.9,0)
% refline(0,1)



axis square
box on

%incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


%set(gca, 'Xtick',[.6:incrementtotal:1.8])
increment = .5; 
%increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.XAxis.MinorTickValues = ax.XLim(1):increment:ax.XLim(2);

increment = .05;
ax.YAxis.MinorTickValues = ax.YLim(1):increment:ax.YLim(2);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
%set(gca, 'Ytick',[.6:incrementtotal:1.8])


set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];


         
% return
% 
% test = ax.YTick;
% set(gcf,'name',regexprep(FigureTitle,'\_*',''))  
% yyaxis right
% yy=3.034./test;
% axis(axisgood)
% set(gca, 'Ytick',[.6:incrementtotal:1.8])
% ax.YAxis(2).MinorTick = 'on';
% ax.YAxis(2).MinorTickValues = ax.YAxis(1).MinorTickValues;
% set(gca, 'Yticklabels',num2str(yy',2))
% 
% ax.YAxis(2).Color=black;
% ylabelax.YAxis(2).Color=black;

legend(newLegendLabels,'Location','Best','FontSize',10)
axis(axisgood(n,:))
FigureTitle = sprintf('%s v %s',Desired_X,Desired_Y);
set(gcf,'name',regexprep(FigureTitle,'/_*','')) 
set(gcf','Position',[654 337 627 592])   
n=n+1; 
end
end
%%
figure()
close
figure(); hold on
axisgood=[0 6 0 2];

% EarthChem_MarkerSizes=str2double(AllUTh_Colors);
% 
% EarthChem_MarkerSizes(EarthChem_MarkerSizes==5)=5; 
% EarthChem_MarkerSizes(EarthChem_MarkerSizes==10)=50;

Desired_X ={'Th/U'};
Desired_Y ={'TH230_U238_ACTIVITY'};
Desired_MarkerSize ={'TH230_U238_ACTIVITY'};

[a,indiciesX] = ismember(Desired_X,RatioLabels);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);
[b,indiciesSize] = ismember(Desired_Y,targetStrings_Isotopes);


%hhh = scatter(AllUTh_DataRatios(:,indiciesX),AllUTh_Isotopes(:,indiciesY),EarthChem_MarkerSizes,Colors2plot,'filled','MarkerFaceAlpha',.5);

plot(AllUTh_DataRatios(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
plot(AllUTh_DataRatios(ARC_indicies,indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh_DataRatios(OIB_indicies,indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)



plot(AllUTh_DataRatios(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'v','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',5)
plot(AllUTh_DataRatios(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',cadmiumgreen, 'MarkerFaceColor',cadmiumgreen,'MarkerSize',5)
plot(AllUTh_DataRatios(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor',white,'MarkerSize',7)
plot(AllUTh_DataRatios(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), '>','Color','k', 'MarkerFaceColor',olivinegreen,'MarkerSize',5)
plot(AllUTh_DataRatios(RIFT_indicies,indiciesX),AllUTh_Isotopes(RIFT_indicies,indiciesY), 'o','Color',articlime, 'MarkerFaceColor',articlime,'MarkerSize',5)


plot(AllUTh_DataRatios(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh_DataRatios(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)

plot(AllUTh_DataRatios(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)


newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB',...
    'Cont' 'BackArc' 'Iceland' 'Azores' 'Rift'...
    'EarthChem MORB'...
    'Jan Mayen' 'N. Kob. Ridge' 'S. Mohns Ridge'...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN on/near axis EPR'...
    };
legend(newLegendLabels,'Location','SouthEast','FontSize',10,'autoupdate','off')


xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');
% xlabel(sprintf('%s normalized to {%s}',RatioLabels{xxvalue}, normalizationLabel));
% ylabel(sprintf('%s normalized to {%s}',RatioLabels{yyvalue}, normalizationLabel));

refline(1/2.5,0)
refline(1/3.9,0)
refline(0,1)
%axis([.6 1.8 .6 1.8])

axis square

box on

incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1)
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


%set(gca, 'Xtick',[.6:incrementtotal:1.8])
increment = .5; 
%increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.XAxis.MinorTickValues = ax.XLim(1):increment:ax.XLim(2);

increment = .1;
ax.YAxis.MinorTickValues = ax.YLim(1):increment:ax.YLim(2);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
%set(gca, 'Ytick',[.6:incrementtotal:1.8])
axis(axisgood)
FigureTitle = 'ThU230Th';
set(gcf,'name',regexprep(FigureTitle,'\_*','')) 
set(gcf','Position',[654 337 627 592])             
% return
% 
% test = ax.YTick;
% set(gcf,'name',regexprep(FigureTitle,'\_*',''))  
% yyaxis right
% yy=3.034./test;
% axis(axisgood)
% set(gca, 'Ytick',[.6:incrementtotal:1.8])
% ax.YAxis(2).MinorTick = 'on';
% ax.YAxis(2).MinorTickValues = ax.YAxis(1).MinorTickValues;
% set(gca, 'Yticklabels',num2str(yy',2))
% 
% ax.YAxis(2).Color=black;
% ylabelax.YAxis(2).Color=black;







%%

% axisgood=...
%     [0.3 10 0.02 7;
%     0.3 12 0.02 40
%     .1 12 0.02 43
%     0.3 2 0.02 7
%     0.3 2 0.02 7];

Desired_X_all ={'La/Sm' 'Sm/Yb' 'Th/U' 'Sm/Nd' 'Lu/Hf'};
%Desired_Y ={'K2O/TiO2'};
Desired_Y ={'K2O' 'K2O/TiO2'};
for i=1:size(Desired_X_all,2)
    figure(); 
    hold on
Desired_X=Desired_X_all{i};



[a,indiciesX] = ismember(Desired_X,RatioLabels);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Majors);




plot(AllUTh_DataRatios(:,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
plot(AllUTh_DataRatios(ARC_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh_DataRatios(OIB_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)

plot(AllUTh_DataRatios(CONTINENTAL_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(CONTINENTAL_indicies,indiciesY), 'v','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',5)
plot(AllUTh_DataRatios(BACKARC_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(BACKARC_indicies,indiciesY), 's','Color',cadmiumgreen, 'MarkerFaceColor',cadmiumgreen,'MarkerSize',5)
plot(AllUTh_DataRatios(ICELAND_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(ICELAND_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor',white,'MarkerSize',7)
plot(AllUTh_DataRatios(AZORES_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(AZORES_indicies,indiciesY), '>','Color','k', 'MarkerFaceColor',olivinegreen,'MarkerSize',5)
plot(AllUTh_DataRatios(RIFT_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(RIFT_indicies,indiciesY), 'o','Color',articlime, 'MarkerFaceColor',articlime,'MarkerSize',5)

plot(AllUTh_DataRatios(MORB_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh_DataRatios(tempIndices_JM,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_NKR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_SMR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)

plot(AllUTh_DataRatios(tempIndices_Seamount,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_Siqueros,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_EPR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)


% plot(Gale_MajorTrace_DataRatios(Gale_MajorTrace_Region_EPR_Indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),Gale_MajorTrace(Gale_MajorTrace_Region_EPR_Indicies,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',8)
% plot(Gale_MajorTrace_DataRatios(Gale_MajorTrace_Region_ST_Indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),Gale_MajorTrace(Gale_MajorTrace_Region_ST_Indicies,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',8)

plot(Gale_MajorTrace_DataRatios(:,indiciesX)./Norm_PUM_DataRatios(indiciesX),Gale_MajorTrace(:,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',8)


newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB',...
    'Cont' 'BackArc' 'Iceland' 'Azores' 'Rift'...
    'EarthChem MORB'...
    'Jan Mayen' 'N. Kob. Ridge' 'S. Mohns Ridge'...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN on/near axis EPR'...
    };
legend(newLegendLabels,'Location','Best','FontSize',10,'autoupdate','off')



xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');


axis square
box on

%incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman')
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';




if strcmp(Desired_Y ,'K2O/TiO2')==1
   yline(.06,'k:','0.06 D-MORB','FontSize',fontsizelines);
   yline(.09,'k:','0.09 N-MORB','FontSize',fontsizelines);
   yline(.26,'k:','0.26 E-MORB','FontSize',fontsizelines);
   set(gca,'yscale','log')
    ax.YAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end

if strcmp(Desired_X ,'U')==1
   xline(0.055/Norm_PUM(indiciesX),'k:','D-MORB','FontSize',fontsizelines);
   xline(0.083./Norm_PUM(indiciesX),'k:','N-MORB','FontSize',fontsizelines);
   xline(0.386./Norm_PUM(indiciesX),'k:',' E-MORB','FontSize',fontsizelines);
end

if strcmp(Desired_X ,'La/Sm')==1
   xline(1.5,'k:','E-MORB Gale et al. 2013 def');
end


   set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10 20:10:100 200:100:1000];
%axis([ax.XLim(1) ax.XLim(2) .5 1.6])
%axis(axisgood(i,:))

%set(gca, 'Xtick',[.6:incrementtotal:1.8])
%increment = .5; 
% increment = findBestIncrement( ax.XLim(2)- ax.XLim(1),ax.XAxis.TickValues(2) -  ax.XAxis.TickValues(1));
% ax.XAxis.MinorTickValues = ax.XLim(1):increment:ax.XLim(2);

%increment = .1;
% increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
% ax.YAxis.MinorTickValues = ax.YLim(1):increment:ax.YLim(2);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
%set(gca, 'Ytick',[.6:incrementtotal:1.8])

%FigureTitle = sprintf('K2OTiO2 v %s',Desired_X);
FigureTitle = sprintf('K2O v %s',Desired_X);
set(gcf,'name',regexprep(FigureTitle,'/_*','')) 
set(gcf','Position',[654 337 627 592])             
% return
% 
% test = ax.YTick;
% set(gcf,'name',regexprep(FigureTitle,'\_*',''))  
% yyaxis right
% yy=3.034./test;
% axis(axisgood)
% set(gca, 'Ytick',[.6:incrementtotal:1.8])
% ax.YAxis(2).MinorTick = 'on';
% ax.YAxis(2).MinorTickValues = ax.YAxis(1).MinorTickValues;
% set(gca, 'Yticklabels',num2str(yy',2))
% 
% ax.YAxis(2).Color=black;
% ylabelax.YAxis(2).Color=black;

end


%%


Desired_X_all ={'K2O' 'Mg#' 'MgO' 'K2O/TiO2'};
Desired_Y ={'K2O'};
for i=1:size(Desired_X_all,2)
    figure(); 
    hold on
Desired_X=Desired_X_all{i};



[a,indiciesX] = ismember(Desired_X,targetStrings_Majors);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Majors);


plot(Gale_MajorTrace(:,indiciesX),Gale_MajorTrace(:,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',8,'HandleVisibility','off')

plot(Gale_Glass(Gale_MajorTrace_Region_EPR_Indicies,indiciesX),Gale_Glass(Gale_MajorTrace_Region_EPR_Indicies,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',8,'HandleVisibility','off')
plot(Gale_Glass(Gale_MajorTrace_Region_ST_Indicies,indiciesX),Gale_Glass(Gale_MajorTrace_Region_ST_Indicies,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',8,'HandleVisibility','off')

% plot(Gale_MajorTrace_DataRatios(Gale_MajorTrace_Region_EPR_Indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),Gale_MajorTrace(Gale_MajorTrace_Region_EPR_Indicies,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',8)
% plot(Gale_MajorTrace_DataRatios(Gale_MajorTrace_Region_ST_Indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),Gale_MajorTrace(Gale_MajorTrace_Region_ST_Indicies,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',8)


plot(AllUTh(:,indiciesX),AllUTh(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
plot(AllUTh(ARC_indicies,indiciesX),AllUTh(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh(OIB_indicies,indiciesX),AllUTh(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)

plot(AllUTh(CONTINENTAL_indicies,indiciesX),AllUTh(CONTINENTAL_indicies,indiciesY), 'v','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',5)
plot(AllUTh(BACKARC_indicies,indiciesX),AllUTh(BACKARC_indicies,indiciesY), 's','Color',cadmiumgreen, 'MarkerFaceColor',cadmiumgreen,'MarkerSize',5)
plot(AllUTh(ICELAND_indicies,indiciesX),AllUTh(ICELAND_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor',white,'MarkerSize',7)
plot(AllUTh(AZORES_indicies,indiciesX),AllUTh(AZORES_indicies,indiciesY), '>','Color','k', 'MarkerFaceColor',olivinegreen,'MarkerSize',5)
plot(AllUTh(RIFT_indicies,indiciesX),AllUTh(RIFT_indicies,indiciesY), 'o','Color',articlime, 'MarkerFaceColor',articlime,'MarkerSize',5)

plot(AllUTh(MORB_indicies,indiciesX),AllUTh(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh(tempIndices_JM,indiciesX),AllUTh(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh(tempIndices_NKR,indiciesX),AllUTh(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh(tempIndices_SMR,indiciesX),AllUTh(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)

plot(AllUTh(tempIndices_Seamount,indiciesX),AllUTh(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh(tempIndices_Siqueros,indiciesX),AllUTh(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh(tempIndices_EPR,indiciesX),AllUTh(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)




newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB',...
    'Cont' 'BackArc' 'Iceland' 'Azores' 'Rift'...
    'EarthChem MORB'...
    'Jan Mayen' 'N. Kob. Ridge' ...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN on/near axis EPR'...
    };
legend(newLegendLabels,'Location','Best','FontSize',10,'autoupdate','off')



xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');


axis square
box on

%incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman')
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


   set(gca,'yscale','log')
    ax.YAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];

if strcmp(Desired_Y ,'K2O/TiO2')==1
   yline(.06,'k:','0.06 D-MORB','FontSize',fontsizelines);
   yline(.09,'k:','0.09 N-MORB','FontSize',fontsizelines);
   yline(.26,'k:','0.26 E-MORB','FontSize',fontsizelines);
   set(gca,'yscale','log')
    ax.YAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end

if strcmp(Desired_X ,'U')==1
   xline(0.055/Norm_PUM(indiciesX),'k:','D-MORB','FontSize',fontsizelines);
   xline(0.083./Norm_PUM(indiciesX),'k:','N-MORB','FontSize',fontsizelines);
   xline(0.386./Norm_PUM(indiciesX),'k:',' E-MORB','FontSize',fontsizelines);
end

if strcmp(Desired_X ,'La/Sm')==1
   xline(1.5,'k:','E-MORB Gale et al. 2013 def');
end

% 
%    set(gca,'xscale','log')
%    ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10 20:10:100 200:100:1000];
%axis([ax.XLim(1) ax.XLim(2) .5 1.6])
%axis(axisgood(i,:))

%set(gca, 'Xtick',[.6:incrementtotal:1.8])
%increment = .5; 
% increment = findBestIncrement( ax.XLim(2)- ax.XLim(1),ax.XAxis.TickValues(2) -  ax.XAxis.TickValues(1));
% ax.XAxis.MinorTickValues = ax.XLim(1):increment:ax.XLim(2);

%increment = .1;
% increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
% ax.YAxis.MinorTickValues = ax.YLim(1):increment:ax.YLim(2);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
%set(gca, 'Ytick',[.6:incrementtotal:1.8])

%FigureTitle = sprintf('K2OTiO2 v %s',Desired_X);
FigureTitle = sprintf('K2O v %s',Desired_X);
set(gcf,'name',regexprep(FigureTitle,'/_*','')) 
set(gcf','Position',[654 337 627 592])             
% return
% 
% test = ax.YTick;
% set(gcf,'name',regexprep(FigureTitle,'\_*',''))  
% yyaxis right
% yy=3.034./test;
% axis(axisgood)
% set(gca, 'Ytick',[.6:incrementtotal:1.8])
% ax.YAxis(2).MinorTick = 'on';
% ax.YAxis(2).MinorTickValues = ax.YAxis(1).MinorTickValues;
% set(gca, 'Yticklabels',num2str(yy',2))
% 
% ax.YAxis(2).Color=black;
% ylabelax.YAxis(2).Color=black;

end


%%



% axisgood=[0 5 .5 2];
axisgood=...
    [.95 1.35 .95 5];

axisgood=...
    [.5 2 .6 6];

% EarthChem_MarkerSizes=str2double(AllUTh_Colors);
% 
% EarthChem_MarkerSizes(EarthChem_MarkerSizes==5)=5; 
% EarthChem_MarkerSizes(EarthChem_MarkerSizes==10)=100;

Desired_Y ={'RA226_TH230_ACTIVITY'};
Desired_X_all ={'TH230_U238_ACTIVITY'};

%%close all
for i=1:size(Desired_X_all,2)
    figure(); 
    hold on
Desired_X=Desired_X_all{i};



[a,indiciesX] = ismember(Desired_X,targetStrings_Isotopes);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off');
xline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off');

%hhh = scatter(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), EarthChem_MarkerSizes,Colors2plot,'filled','MarkerFaceAlpha',1);
%hhh.MarkerFaceAlpha
% uistack(hhh,'bottom')
% axis(axisgood)

%gscatter(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), AllUTh_Series,'brgk','xosd',30,'filled');
%gscatter(ratings(:,1),ratings(:,2),AllUTh_Series,'brgk','xosd')


%scatter(AllUTh(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY),300, 'd', 'filled','MarkerFaceColor',fuschia); 
    %EarthChem_MarkerSizes(tempIndices_EPR(1),:),Colors2plot(tempIndices_EPR(1),:),'MarkerFaceAlpha',1);
 %tempIndices_Seamount tempIndices_Siqueros

plot(AllUTh_Isotopes(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',3)

plot(AllUTh_Isotopes(ARC_indicies,indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',2)
plot(AllUTh_Isotopes(OIB_indicies,indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',2)
% plot(AllUTh_Isotopes(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'o','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',6)
% plot(AllUTh_Isotopes(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',6)
% plot(AllUTh_Isotopes(RIFT_indicies,indiciesX),AllUTh_Isotopes(RIFT_indicies,indiciesY), 'o','Color',articlime, 'MarkerFaceColor',articlime,'MarkerSize',6)
% plot(AllUTh_Isotopes(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor',white,'MarkerSize',10)
% plot(AllUTh_Isotopes(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), '>','Color','k', 'MarkerFaceColor',olivinegreen,'MarkerSize',10)

plot(AllUTh_Isotopes(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)



%plot(AllUTh(MIX_indicies,indiciesX),AllUTh_Isotopes(MIX_indicies,indiciesY), 'o','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)


% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)

%goodies 


plot(AllUTh_Isotopes(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color',black, 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh_Isotopes(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh_Isotopes(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey2,'MarkerSize',16)
plot(AllUTh_Isotopes(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',14)
plot(AllUTh_Isotopes(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',14)
plot(AllUTh_Isotopes(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',14)


%newLegendLabels = {'Arcs' 'OIBs' 'Continental' 'Back Arc','Plume-Ridge','MORB','Seamounts','Siqueros Transform' 'EPR' };
%newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB' 'EarthChem MORB','Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN EPR' ,'AutoUpdate','off'};
%newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB'  ,'Continental','Back Arc', 'Rift' ,'Iceland','Azores','EarthChem MORB','AutoUpdate','off'};

newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB' 'EarthChem MORB',...
    'Jan Mayen' 'N. Kob. Ridge' 'S. Mohns Ridge'...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN EPR'};

xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');
% xlabel(sprintf('%s normalized to {%s}',RatioLabels{xxvalue}, normalizationLabel));
% ylabel(sprintf('%s normalized to {%s}',RatioLabels{yyvalue}, normalizationLabel));
       %
% refline(1/2.5,0)
% refline(1/3.9,0)
% refline(0,1)



axis square
box on

%incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


set(gca, 'Xtick',[.5:.2:5])
increment = .1; 
%increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.XAxis.MinorTickValues = ax.XLim(1):increment:ax.XLim(2);

set(gca, 'Ytick',[0:.4:6])
increment = .2;
ax.YAxis.MinorTickValues = ax.YLim(1):increment:ax.YLim(2);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
%set(gca, 'Ytick',[.6:incrementtotal:1.8])


axis(axisgood(i,:))
FigureTitle = sprintf('ThU230Th v %s',Desired_X);
set(gcf,'name',regexprep(FigureTitle,'/_*','')) 
set(gcf','Position',[654 337 627 592])    
set(gca,'FontName','Times New Roman')
ylabel('(^{226}Ra/^{230}Th)','interpreter','tex')
xlabel('(^{230}Th/^{238}U)','interpreter','tex')


% return
% 
% test = ax.YTick;
% set(gcf,'name',regexprep(FigureTitle,'\_*',''))  
% yyaxis right
% yy=3.034./test;
% axis(axisgood)
% set(gca, 'Ytick',[.6:incrementtotal:1.8])
% ax.YAxis(2).MinorTick = 'on';
% ax.YAxis(2).MinorTickValues = ax.YAxis(1).MinorTickValues;
% set(gca, 'Yticklabels',num2str(yy',2))
% 
% ax.YAxis(2).Color=black;
% ylabelax.YAxis(2).Color=black;



legend(newLegendLabels,'Location','Best')
end
%set(gcf,'Position',[780 317 627 592])









%%

% axisgood=...
%     [0 .8 0.5 1.6
%     1e-2 20 0.5 1.6];
% Desired_X_all ={'Mg#' 'K2O' };
% Desired_Y ={'TH230_U238_ACTIVITY'};


% axisgood=...
%     [1e-2 20 0.5 1.6];

axisgood=...
    [1.5e-2 33 0.5 1.6
    0 .8 0.5 1.6
    0 14 0.5 1.6];


% axisgood=...
%     [1e-2 20 0.5 1.8];

Desired_X_all ={'K2O' 'Mg#' 'MgO'};
Desired_Y ={'TH230_U238_ACTIVITY'};

%%close all
for i=1:size(Desired_X_all,2)
    figure(); 
    hold on
Desired_X=Desired_X_all{i};



[a,indiciesX] = ismember(Desired_X,targetStrings_Majors);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off','LineWidth',2,'LabelVerticalAlignment','middle');
if strcmp(Desired_X ,'K2O')==1
   xline(.096,'k:','0.096 D-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.14,'k:','0.14 N-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.394,'k:','0.394 E-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
end

if strcmp(Desired_X ,'K2O/TiO2')==1
   xline(.06,'k:','0.06 D-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   xline(.09,'k:','0.09 N-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   xline(.26,'k:','0.26 E-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   set(gca,'xscale','log')
    ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end
%hhh = scatter(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), EarthChem_MarkerSizes,Colors2plot,'filled','MarkerFaceAlpha',1);
%hhh.MarkerFaceAlpha
% uistack(hhh,'bottom')
% axis(axisgood)

%gscatter(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), AllUTh_Series,'brgk','xosd',30,'filled');
%gscatter(ratings(:,1),ratings(:,2),AllUTh_Series,'brgk','xosd')


%scatter(AllUTh(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY),300, 'd', 'filled','MarkerFaceColor',fuschia); 
    %EarthChem_MarkerSizes(tempIndices_EPR(1),:),Colors2plot(tempIndices_EPR(1),:),'MarkerFaceAlpha',1);
 %tempIndices_Seamount tempIndices_Siqueros

plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)

plot(AllUTh(ARC_indicies,indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh(OIB_indicies,indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)


%  plot(AllUTh(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'o','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',3)
%  plot(AllUTh(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
%  plot(AllUTh(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'p','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)
 %plot(AllUTh(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), 'd','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)


%plot(AllUTh(MIX_indicies,indiciesX),AllUTh_Isotopes(MIX_indicies,indiciesY), 'o','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)

plot(AllUTh(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)
plot(AllUTh(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)


% plot(AllUTh_Primary(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color',black, 'MarkerFaceColor','k','MarkerSize',10)
% 
% plot(AllUTh_Primary(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color',black, 'MarkerFaceColor',grey9,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey6,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey2,'MarkerSize',16)
% 
% plot(AllUTh_Primary(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color',black, 'MarkerFaceColor',androidgreen,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color',black, 'MarkerFaceColor',azure,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color',black, 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)



D = [NaN	NaN	1	1	1	1	1	1	1	1	0.001	0.001	0.001	0.001	NaN	NaN	NaN	NaN	NaN	NaN	NaN]; 
WHDMM = [NaN	NaN	44.71	0.13	3.98	0.57	8.18	0	38.73	3.17	0.28	0.006	NaN	NaN	NaN	99.76	0.894	0.083	0.8	NaN	NaN]; 
HZPUM = [NaN	NaN	45.96	0.18	4.06	0.47	7.54	0.13	37.78	3.21	0.332	0.032	0.02	0.28	NaN	99.56	0.899	0.102	0.79	NaN	NaN]; 
WHDMM_U_Th = [0.0032 0.0079];



%D_U_Th = [6.15e-3 5.57e-3];
%D_U_Th = [1.18e-3 8.92e-4];

D_U_Th = [2.05e-3 1.35e-3];
%D_U_Th = [4.49e-3 2.16e-3];

%D_U_Th = [0.0014 0.001];

%D_U_Th = [.00299 .00215];

FR = 0.001;
F = [0.001:.001:.15];
F_plot = [0.001:.001:.01 .02:.01:.1 .15];
F = round(F,4); 
F_plot = round(F_plot,4); 
[c,d]=intersect(F,F_plot);
F = F(d'); 
F_label = [0.001 .005 .01 .05 .1 .15];
F_label = round(F_label,4); 
[e,f]=intersect(F,F_label);


Batch_WHDMM = WHDMM(indiciesX)./(D(indiciesX)+F.*(1-D(indiciesX))); 
[Ko, KoAGG]= ZouContinuousMelting_chooseSource(WHDMM(indiciesX), FR ,F,D(indiciesX));
DK_FC = 0.001; 
Batch_WHDMM_K_fractionated = Batch_WHDMM.*0.5.^(DK_FC-1); 


Batch_WHDMM_U = WHDMM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
[Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));

Batch_WHDMM_Th = WHDMM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
[Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

% plot(Batch_WHDMM,(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',3,'MarkerSize',8)
% text(Batch_WHDMM(f),(Batch_WHDMM_Th(f)./Batch_WHDMM_U(f))./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
%     ,'HorizontalAlignment','right','Color',CadmiumRed,'FontWeight','bold')
% 

plot(Batch_WHDMM_K_fractionated,(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',3,'MarkerSize',8)
text(Batch_WHDMM_K_fractionated(f),(Batch_WHDMM_Th(f)./Batch_WHDMM_U(f))./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
    ,'HorizontalAlignment','right','Color',CadmiumRed,'FontWeight','bold')






%plot(Ko,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)
%plot(KoAGG,(KoAGG_Th./KoAGG_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+:','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)

HZPUM = [NaN	NaN	45.96	0.18	4.06	0.47	7.54	0.13	37.78	3.21	0.332	0.032	0.02	0.28	NaN	99.56	0.899	0.102	0.79	NaN	NaN]; 
HZPUM_U_Th = [0.0203 0.0795];

Batch_HZPUM = HZPUM(indiciesX)./(D(indiciesX)+F.*(1-D(indiciesX))); 
[Ko, KoAGG]= ZouContinuousMelting_chooseSource(HZPUM(indiciesX), FR ,F,D(indiciesX));
Batch_HZPUM_K_fractionated = Batch_HZPUM.*0.5.^(DK_FC-1); 



 Batch_HZPUM_U = HZPUM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
% [Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));
% 
 Batch_HZPUM_Th = HZPUM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
% [Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

% plot(Batch_HZPUM,(Batch_HZPUM_Th./Batch_HZPUM_U)./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), '+:','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',3,'MarkerSize',8)
% text(Batch_HZPUM(f),(Batch_HZPUM_Th(f)./Batch_HZPUM_U(f))./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment'...
%     ,'top','HorizontalAlignment','left','Color',CadmiumRed,'FontWeight','bold')

plot(Batch_HZPUM_K_fractionated,(Batch_HZPUM_Th./Batch_HZPUM_U)./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), '+:','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',3,'MarkerSize',8)
text(Batch_HZPUM_K_fractionated(f),(Batch_HZPUM_Th(f)./Batch_HZPUM_U(f))./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment'...
    ,'top','HorizontalAlignment','left','Color',CadmiumRed,'FontWeight','bold')

%plot(Ko,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color',grey55, 'Color',grey55,'LineWidth',2,'MarkerSize',10)
%plot(KoAGG,(KoAGG_Th./KoAGG_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+:','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)

%D_U_Th = [0.0142 0.0102];
FR = 0.01;
F = [0.01:.01:.15];
F_plot = [.01:.01:.15];
F = round(F,4); 
F_plot = round(F_plot,4); 
[c,d]=intersect(F,F_plot);
F = F(d'); 

Batch_WHDMM = WHDMM(indiciesX)./(D(indiciesX)+F.*(1-D(indiciesX))); 
[Ko, KoAGG]= ZouContinuousMelting_chooseSource(WHDMM(indiciesX), FR ,F,D(indiciesX));

Batch_WHDMM_U = WHDMM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
[Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));

Batch_WHDMM_Th = WHDMM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
[Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

%plot(Batch_WHDMM,(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',grey55, 'Color',grey55,'LineWidth',2,'MarkerSize',10)
%plot(Ko,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color',grey55, 'Color',grey55,'LineWidth',2,'MarkerSize',10)
%plot(KoAGG,(KoAGG_Th./KoAGG_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+:','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)





DK = 0.01;  
%D_U_Th = [0.0142 0.0102];
FR = 0.01;
F = [0.01:.01:.15];
F_plot = [.01:.01:.15];
F = round(F,4); 
F_plot = round(F_plot,4); 
[c,d]=intersect(F,F_plot);
F = F(d'); 

Batch_WHDMM = WHDMM(indiciesX)./(DK+F.*(1-D(indiciesX))); 
[Ko, KoAGG]= ZouContinuousMelting_chooseSource(WHDMM(indiciesX), FR ,F,DK);

Batch_WHDMM_U = WHDMM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
[Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));

Batch_WHDMM_Th = WHDMM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
[Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

%plot(Batch_WHDMM,(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',chartruese, 'Color',chartruese,'LineWidth',2,'MarkerSize',10)
%plot(Ko,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color',chartruese, 'Color',chartruese,'LineWidth',2,'MarkerSize',10)
%plot(KoAGG,(KoAGG_Th./KoAGG_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color',chartruese, 'Color',chartruese,'LineWidth',2,'MarkerSize',10)






%newLegendLabels = {'Arcs' 'OIBs' 'Continental' 'Back Arc','Plume-Ridge','MORB','Seamounts','Siqueros Transform' 'EPR' };

newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB' 'EarthChem MORB',...
    'Jan Mayen' 'N. Kob. Ridge' 'S. Mohns Ridge'...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN on/near axis EPR'...
    'First Melts of WHDMM','First Melts of HZPUM'};



xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');
% xlabel(sprintf('%s normalized to {%s}',RatioLabels{xxvalue}, normalizationLabel));
% ylabel(sprintf('%s normalized to {%s}',RatioLabels{yyvalue}, normalizationLabel));
       %
% refline(1/2.5,0)
% refline(1/3.9,0)
% refline(0,1)



axis square
box on

%incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


%set(gca, 'Xtick',[.6:incrementtotal:1.8])
increment = .5; 
%increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.XAxis.MinorTickValues = ax.XLim(1):increment:ax.XLim(2);

increment = .05;
ax.YAxis.MinorTickValues = ax.YLim(1):increment:ax.YLim(2);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
%set(gca, 'Ytick',[.6:incrementtotal:1.8])



if strcmp(Desired_X ,'K2O')==1
set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end


legend(newLegendLabels,'Location','SouthEast','FontSize',10)
axis(axisgood(i,:))
FigureTitle = sprintf('ThU230Th v %s',Desired_X);
set(gcf,'name',regexprep(FigureTitle,'/_*','')) 
set(gcf','Position',[654 337 627 592])    
end

%%
% axisgood=...
%     [0 .8 0.5 1.6
%     1e-2 20 0.5 1.6];
% Desired_X_all ={'Mg#' 'K2O' };
% Desired_Y ={'TH230_U238_ACTIVITY'};


% axisgood=...
%     [1e-2 20 0.5 1.6];

axisgood=...
    [1.5e-2 33 .702 .706
    0 .8 .702 .706
    0 14 .702 .706
    1.5e-2 33 .5122 .5133
    0 .8 .5122 .5133
    0 14 .5122 .5133];


% axisgood=...
%     [1e-2 20 0.5 1.8];

Desired_X_all ={'K2O' 'Mg#' 'MgO'};
Desired_Y_all ={'SR87_SR86' 'ND143_ND144'};
n=1; 
%%close all
for i=1:size(Desired_Y_all,2)
for j=1:size(Desired_X_all,2)
    figure(); 
    hold on
Desired_X=Desired_X_all{j};
Desired_Y = Desired_Y_all{i};


[a,indiciesX] = ismember(Desired_X,targetStrings_Majors);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


if strcmp(Desired_X ,'K2O')==1
   xline(.096,'k-','0.096 D-MORB','LineWidth',1,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.14,'k-','0.14 N-MORB','LineWidth',1,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.394,'k-','0.394 E-MORB','LineWidth',1,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
end


if strcmp(Desired_Y ,'ND143_ND144')==1
   yline(0.512638 ,'k-','CHUR','LineWidth',1,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
end


if strcmp(Desired_X ,'K2O/TiO2')==1
   xline(.06,'k-','0.06 D-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LineWidth',1);
   xline(.09,'k-','0.09 N-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LineWidth',1);
   xline(.26,'k-','0.26 E-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LineWidth',1);
   set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end
%hhh = scatter(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), EarthChem_MarkerSizes,Colors2plot,'filled','MarkerFaceAlpha',1);
%hhh.MarkerFaceAlpha
% uistack(hhh,'bottom')
% axis(axisgood)

%gscatter(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), AllUTh_Series,'brgk','xosd',30,'filled');
%gscatter(ratings(:,1),ratings(:,2),AllUTh_Series,'brgk','xosd')


%scatter(AllUTh(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY),300, 'd', 'filled','MarkerFaceColor',fuschia); 
    %EarthChem_MarkerSizes(tempIndices_EPR(1),:),Colors2plot(tempIndices_EPR(1),:),'MarkerFaceAlpha',1);
 %tempIndices_Seamount tempIndices_Siqueros

 
plot(Gale_5_Master_TE_Iso_Edited(:,indiciesX),Gale_5_Master_TE_Iso_Edited_Isotopes(:,indiciesY), 'd','Color','k', 'MarkerFaceColor','k','MarkerSize',3)

 
 
plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)

plot(AllUTh(ARC_indicies,indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh(OIB_indicies,indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)
 
plot(AllUTh(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'o','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',3)
plot(AllUTh(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
plot(AllUTh(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor',white,'MarkerSize',10)
plot(AllUTh(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), 'd','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)




%plot(AllUTh(MIX_indicies,indiciesX),AllUTh_Isotopes(MIX_indicies,indiciesY), 'o','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)

plot(AllUTh(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)



plot(AllUTh(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh(tempIndices_NKR_no226Ra,indiciesX),AllUTh_Isotopes(tempIndices_NKR_no226Ra,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',12)
%plot(AllUTh(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)
plot(AllUTh(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)

plot(AllUTh(tempIndices_SiquerosDMORB,indiciesX),AllUTh_Isotopes(tempIndices_SiquerosDMORB,indiciesY), 'd','Color','k', 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',16)


% plot(AllUTh_Primary(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color',black, 'MarkerFaceColor','k','MarkerSize',10)
% 
% plot(AllUTh_Primary(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color',black, 'MarkerFaceColor',grey9,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey6,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey2,'MarkerSize',16)
% 
% plot(AllUTh_Primary(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color',black, 'MarkerFaceColor',androidgreen,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color',black, 'MarkerFaceColor',azure,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color',black, 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)







%newLegendLabels = {'Arcs' 'OIBs' 'Continental' 'Back Arc','Plume-Ridge','MORB','Seamounts','Siqueros Transform' 'EPR' };

newLegendLabels = {'Gale' 'EarthChem' 'EarthChem Arcs' 'EarthChem OIB'  'Continental' 'Back Arc' 'Iceland' 'Azores' ,...
    'EarthChem MORB',...
    'Jan Mayen' 'N. Kob. Ridge' 'N. Kob. Ridge no226' ...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN on/near axis EPR'...
    'First Melts of WHDMM','First Melts of HZPUM'};



xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');
% xlabel(sprintf('%s normalized to {%s}',RatioLabels{xxvalue}, normalizationLabel));
% ylabel(sprintf('%s normalized to {%s}',RatioLabels{yyvalue}, normalizationLabel));
       %
% refline(1/2.5,0)
% refline(1/3.9,0)
% refline(0,1)



axis square
box on

%incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


%set(gca, 'Xtick',[.6:incrementtotal:1.8])
increment = .5; 
%increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.XAxis.MinorTickValues = ax.XLim(1):increment:ax.XLim(2);

increment = .05;
ax.YAxis.MinorTickValues = ax.YLim(1):increment:ax.YLim(2);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
%set(gca, 'Ytick',[.6:incrementtotal:1.8])



if strcmp(Desired_X ,'K2O')==1
set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end


%legend(newLegendLabels,'Location','SouthEast','FontSize',10)
legend(newLegendLabels,'Location','Best','FontSize',10)
axis(axisgood(n,:))
FigureTitle = sprintf('%s v %s',Desired_X,Desired_Y);
set(gcf,'name',regexprep(FigureTitle,'/_*','')) 
set(gcf','Position',[654 337 627 592])    
 n=n+1; 
end
end

%%

% axisgood=...
%     [0 10000 0.5 1.6;
%     0 10000 0.5 1.6 ;
%     0 100 0.5 1.6;
%     0 1000 0.5 1.6
%     ];
% Desired_X_all ={'U' 'Th' 'Lu' 'La'};
% Desired_Y ={'TH230_U238_ACTIVITY'};


axisgood=...
    [3e-1 1000 0.5 1.6];
Desired_X_all ={'U'};
Desired_Y ={'TH230_U238_ACTIVITY'};

%close all
for i=1:size(Desired_X_all,2)
    figure(); 
    hold on
Desired_X=Desired_X_all{i};



[a,indiciesX] = ismember(Desired_X,targetStrings_Trace);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','HandleVisibility','off','FontName','Times New Roman','FontName','Times New Roman','LabelVerticalAlignment','middle','LabelHorizontalAlignment','right','HandleVisibility','off','LineWidth',2);
xline(1,'k-','PUM','FontSize',fontsizelines,'HandleVisibility','off','FontName','Times New Roman','FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
%hhh = scatter(AllUTh_Trace(:,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(:,indiciesY),EarthChem_MarkerSizes,Colors2plot,'filled','MarkerFaceAlpha',1);



plot(AllUTh_Trace(:,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
plot(AllUTh_Trace(ARC_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh_Trace(OIB_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)

% plot(AllUTh_Trace(CONTINENTAL_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'v','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',5)
% plot(AllUTh_Trace(BACKARC_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',cadmiumgreen, 'MarkerFaceColor',cadmiumgreen,'MarkerSize',5)
%  
% plot(AllUTh_Trace(ICELAND_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor',white,'MarkerSize',7)
% plot(AllUTh_Trace(AZORES_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), '>','Color','k', 'MarkerFaceColor',olivinegreen,'MarkerSize',5)
% plot(AllUTh_Trace(RIFT_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(RIFT_indicies,indiciesY), 'o','Color',articlime, 'MarkerFaceColor',articlime,'MarkerSize',5)


plot(AllUTh_Trace(MORB_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh_Trace(tempIndices_JM,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_NKR,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_SMR,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)

plot(AllUTh_Trace(tempIndices_Seamount,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_Siqueros,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_EPR,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)




D = [NaN	NaN	1	1	1	1	1	1	1	1	0.001	0.001	0.001	0.001	NaN	NaN	NaN	NaN	NaN	NaN	NaN]; 
WHDMM = [NaN	NaN	44.71	0.13	3.98	0.57	8.18	0	38.73	3.17	0.28	0.006	NaN	NaN	NaN	99.76	0.894	0.083	0.8	NaN	NaN]; 
HZPUM = [NaN	NaN	45.96	0.18	4.06	0.47	7.54	0.13	37.78	3.21	0.332	0.032	0.02	0.28	NaN	99.56	0.899	0.102	0.79	NaN	NaN]; 
WHDMM_U_Th = [0.0032 0.0079];

%D_U_Th = [6.15e-3 5.57e-3];
%D_U_Th = [1.18e-3 8.92e-4];

% D_U_Th = [2.05e-3 1.35e-3];
%D_U_Th = [4.49e-3 2.16e-3];

%D_U_Th = [0.0014 0.001];


FR = 0.001;
F = [0.001:.001:.15];
F_plot = [0.001:.001:.01 .02:.01:.1 .15];
F = round(F,4); 
F_plot = round(F_plot,4); 
[c,d]=intersect(F,F_plot);
F = F(d'); 
F_label = [0.001 .005 .01 .05 .1 .15];
F_label = round(F_label,4); 
[e,f]=intersect(F,F_label);




Batch_WHDMM_U = WHDMM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
[Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));

DU_FC = 0.01; 
Batch_WHDMM_U_fractionated = Batch_WHDMM_U.*0.5.^(DU_FC-1); 

Batch_WHDMM_Th = WHDMM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
[Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

%plot(Batch_WHDMM_U./HZPUM_U_Th(1),(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color','k', 'Color','k','LineWidth',3,'MarkerSize',8)
plot(Batch_WHDMM_U_fractionated./HZPUM_U_Th(1),(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',3,'MarkerSize',8)

text(Batch_WHDMM_U_fractionated(f)./HZPUM_U_Th(1),(Batch_WHDMM_Th(f)./Batch_WHDMM_U(f))./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
    ,'HorizontalAlignment','right','Color',CadmiumRed,'FontWeight','bold')

%plot(Ko,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)
%plot(KoAGG,(KoAGG_Th./KoAGG_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+:','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)

HZPUM = [NaN	NaN	45.96	0.18	4.06	0.47	7.54	0.13	37.78	3.21	0.332	0.032	0.02	0.28	NaN	99.56	0.899	0.102	0.79	NaN	NaN]; 
HZPUM_U_Th = [0.0203 0.0795];



 Batch_HZPUM_U = HZPUM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
% [Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));
Batch_HZPUM_U_fractionated = Batch_HZPUM_U.*0.5.^(DU_FC-1); 

 Batch_HZPUM_Th = HZPUM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
% [Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

 plot(Batch_HZPUM_U_fractionated./HZPUM_U_Th(1),(Batch_HZPUM_Th./Batch_HZPUM_U)./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), '+:','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',3,'MarkerSize',8)

 text(Batch_HZPUM_U_fractionated(f)./HZPUM_U_Th(1),(Batch_HZPUM_Th(f)./Batch_HZPUM_U(f))./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment'...
    ,'top','HorizontalAlignment','left','Color',CadmiumRed,'FontWeight','bold')

%plot(Ko,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color',grey55, 'Color',grey55,'LineWidth',2,'MarkerSize',10)
%plot(KoAGG,(KoAGG_Th./KoAGG_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+:','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)




%newLegendLabels = {'Arcs' 'OIBs' 'Continental' 'Back Arc','Plume-Ridge','MORB','Seamounts','Siqueros Transform' 'EPR' };
%newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB' 'EarthChem MORB','Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN EPR' };
newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB' 'EarthChem MORB','continental','backarc','Iceland','Azores','rift','Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN EPR' };




xlabel([Desired_X ' norm to PUM'],'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');


axis square
box on

%incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';




if strcmp(Desired_X ,'K2O/TiO2')==1
   xline(.06,'k:','0.06 D-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.09,'k:','0.09 N-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.26,'k:','0.26 E-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   set(gca,'xscale','log')
    ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end

if strcmp(Desired_X ,'U')==1
   xline(0.055/Norm_PUM(indiciesX),'k:','D-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off','LineWidth',2);
   xline(0.083./Norm_PUM(indiciesX),'k:','N-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off','LineWidth',2);
   xline(0.386./Norm_PUM(indiciesX),'k:',' E-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off','LineWidth',2);
end

   set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10 20:10:100 200:100:1000];
%axis([ax.XLim(1) ax.XLim(2) .5 1.6])
axis(axisgood(i,:))

%set(gca, 'Xtick',[.6:incrementtotal:1.8])
%increment = .5; 
% increment = findBestIncrement( ax.XLim(2)- ax.XLim(1),ax.XAxis.TickValues(2) -  ax.XAxis.TickValues(1));
% ax.XAxis.MinorTickValues = ax.XLim(1):increment:ax.XLim(2);

%increment = .1;
increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.YAxis.MinorTickValues = ax.YLim(1):increment:ax.YLim(2);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
%set(gca, 'Ytick',[.6:incrementtotal:1.8])

FigureTitle = sprintf('ThU230Th v %s',Desired_X);
set(gcf,'name',regexprep(FigureTitle,'\_*','')) 
set(gcf','Position',[654 337 627 592])             



end

%% Figure XX HERE

    figure(); 
    hold on
    set(gcf,'Position',[179 373 1162 531])
hold on


    
subaxis(1,2,2,'Margin',.03,'Spacing',.02,'PaddingBottom',.08)
hold on
axisgood=...
    [3e-1 1000 0.5 1.6];
Desired_X_all ={'U'};
Desired_Y ={'TH230_U238_ACTIVITY'};
for i=1:size(Desired_X_all,2)

Desired_X=Desired_X_all{i};



[a,indiciesX] = ismember(Desired_X,targetStrings_Trace);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','HandleVisibility','off','FontName','Times New Roman','FontName','Times New Roman','LabelVerticalAlignment','middle','LabelHorizontalAlignment','right','HandleVisibility','off','LineWidth',2);
xline(1,'k-','PUM','FontSize',fontsizelines,'HandleVisibility','off','FontName','Times New Roman','FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
%hhh = scatter(AllUTh_Trace(:,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(:,indiciesY),EarthChem_MarkerSizes,Colors2plot,'filled','MarkerFaceAlpha',1);



plot(AllUTh_Trace(:,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
plot(AllUTh_Trace(ARC_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh_Trace(OIB_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)

% plot(AllUTh_Trace(CONTINENTAL_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'v','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',5)
% plot(AllUTh_Trace(BACKARC_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',cadmiumgreen, 'MarkerFaceColor',cadmiumgreen,'MarkerSize',5)
%  
% plot(AllUTh_Trace(ICELAND_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor',white,'MarkerSize',7)
% plot(AllUTh_Trace(AZORES_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), '>','Color','k', 'MarkerFaceColor',olivinegreen,'MarkerSize',5)
% plot(AllUTh_Trace(RIFT_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(RIFT_indicies,indiciesY), 'o','Color',articlime, 'MarkerFaceColor',articlime,'MarkerSize',5)


plot(AllUTh_Trace(MORB_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh_Trace(tempIndices_JM,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_NKR,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_NKR_no226Ra,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_NKR_no226Ra,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',12)

plot(AllUTh_Trace(tempIndices_SMR,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)

plot(AllUTh_Trace(tempIndices_Seamount,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_Siqueros,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_EPR,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)

D = [NaN	NaN	1	1	1	1	1	1	1	1	0.001	0.001	0.001	0.001	NaN	NaN	NaN	NaN	NaN	NaN	NaN]; 
WHDMM = [NaN	NaN	44.71	0.13	3.98	0.57	8.18	0	38.73	3.17	0.28	0.006	NaN	NaN	NaN	99.76	0.894	0.083	0.8	NaN	NaN]; 
HZPUM = [NaN	NaN	45.96	0.18	4.06	0.47	7.54	0.13	37.78	3.21	0.332	0.032	0.02	0.28	NaN	99.56	0.899	0.102	0.79	NaN	NaN]; 
WHDMM_U_Th = [0.0032 0.0079];

%D_U_Th = [6.15e-3 5.57e-3];
%D_U_Th = [1.18e-3 8.92e-4];

% D_U_Th = [2.05e-3 1.35e-3];
%D_U_Th = [4.49e-3 2.16e-3];

%D_U_Th = [0.0014 0.001];


FR = 0.001;
F = [0.001:.001:.15];
F_plot = [0.001:.001:.01 .02:.01:.1 .15];
F = round(F,4); 
F_plot = round(F_plot,4); 
[c,d]=intersect(F,F_plot);
F = F(d'); 
F_label = [0.001 .005 .01 .05 .1 .15];
F_label = round(F_label,4); 
[e,f]=intersect(F,F_label);



Batch_WHDMM_U = WHDMM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
[Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));

DU_FC = 0.01; 
Batch_WHDMM_U_fractionated = Batch_WHDMM_U.*0.5.^(DU_FC-1); 

Batch_WHDMM_Th = WHDMM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
[Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

%plot(Batch_WHDMM_U./HZPUM_U_Th(1),(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color','k', 'Color','k','LineWidth',3,'MarkerSize',8)
plot(Batch_WHDMM_U_fractionated./HZPUM_U_Th(1),(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',2,'MarkerSize',8)

text(Batch_WHDMM_U_fractionated(f)./HZPUM_U_Th(1),(Batch_WHDMM_Th(f)./Batch_WHDMM_U(f))./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
    ,'HorizontalAlignment','right','Color',CadmiumRed,'FontWeight','bold')

%plot(Ko,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)
%plot(KoAGG,(KoAGG_Th./KoAGG_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+:','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)

HZPUM = [NaN	NaN	45.96	0.18	4.06	0.47	7.54	0.13	37.78	3.21	0.332	0.032	0.02	0.28	NaN	99.56	0.899	0.102	0.79	NaN	NaN]; 
HZPUM_U_Th = [0.0203 0.0795];

Batch_HZPUM_U = HZPUM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
% [Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));
Batch_HZPUM_U_fractionated = Batch_HZPUM_U.*0.5.^(DU_FC-1); 

Batch_HZPUM_Th = HZPUM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
% [Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

 plot(Batch_HZPUM_U_fractionated./HZPUM_U_Th(1),(Batch_HZPUM_Th./Batch_HZPUM_U)./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), '+:','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',2,'MarkerSize',8)

 text(Batch_HZPUM_U_fractionated(f)./HZPUM_U_Th(1),(Batch_HZPUM_Th(f)./Batch_HZPUM_U(f))./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment'...
    ,'top','HorizontalAlignment','left','Color',CadmiumRed,'FontWeight','bold')

%plot(Ko,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color',grey55, 'Color',grey55,'LineWidth',2,'MarkerSize',10)
%plot(KoAGG,(KoAGG_Th./KoAGG_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+:','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)

%newLegendLabels = {'Arcs' 'OIBs' 'Continental' 'Back Arc','Plume-Ridge','MORB','Seamounts','Siqueros Transform' 'EPR' };
%newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB' 'EarthChem MORB','Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN EPR' };
newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB' 'EarthChem MORB','continental','backarc','Iceland','Azores','rift','Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN EPR' };

xlabel([Desired_X ' norm to PUM'],'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');


axis square
box on

%incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';



if strcmp(Desired_X ,'K2O/TiO2')==1
   xline(.06,'k:','0.06 D-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.09,'k:','0.09 N-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.26,'k:','0.26 E-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   set(gca,'xscale','log')
    ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end

if strcmp(Desired_X ,'U')==1
   xline(0.055/Norm_PUM(indiciesX),'k:','D-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off','LineWidth',2);
   xline(0.083./Norm_PUM(indiciesX),'k:','N-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off','LineWidth',2);
   xline(0.386./Norm_PUM(indiciesX),'k:',' E-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off','LineWidth',2);
end

   set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10 20:10:100 200:100:1000];
%axis([ax.XLim(1) ax.XLim(2) .5 1.6])
axis(axisgood(i,:))

%set(gca, 'Xtick',[.6:incrementtotal:1.8])
%increment = .5; 
% increment = findBestIncrement( ax.XLim(2)- ax.XLim(1),ax.XAxis.TickValues(2) -  ax.XAxis.TickValues(1));
% ax.XAxis.MinorTickValues = ax.XLim(1):increment:ax.XLim(2);

%increment = .1;
increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.YAxis.MinorTickValues = ax.YLim(1):increment:ax.YLim(2);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
%set(gca, 'Ytick',[.6:incrementtotal:1.8])

xlabel('U / U_{PUM}','interpreter','tex')
ylabel('(^{230}Th/^{238}U)','interpreter','tex')

end



subaxis(1,2,1)
hold on

axisgood=...
    [1.5e-2 33 0.5 1.6];

Desired_X_all ={'K2O' };
Desired_Y ={'TH230_U238_ACTIVITY'};


for i=1:size(Desired_X_all,2)
Desired_X=Desired_X_all{i};



[a,indiciesX] = ismember(Desired_X,targetStrings_Majors);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off','LineWidth',2,'LabelVerticalAlignment','middle');
if strcmp(Desired_X ,'K2O')==1
   xline(.096,'k:','0.096 D-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.14,'k:','0.14 N-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.394,'k:','0.394 E-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
end

if strcmp(Desired_X ,'K2O/TiO2')==1
   xline(.06,'k:','0.06 D-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   xline(.09,'k:','0.09 N-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   xline(.26,'k:','0.26 E-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   set(gca,'xscale','log')
    ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end

plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)

plot(AllUTh(ARC_indicies,indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh(OIB_indicies,indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)


%  plot(AllUTh(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'o','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',3)
%  plot(AllUTh(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
%  plot(AllUTh(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'p','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)
 %plot(AllUTh(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), 'd','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)


%plot(AllUTh(MIX_indicies,indiciesX),AllUTh_Isotopes(MIX_indicies,indiciesY), 'o','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)

plot(AllUTh(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh(tempIndices_NKR_no226Ra,indiciesX),AllUTh_Isotopes(tempIndices_NKR_no226Ra,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',12)

plot(AllUTh(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)
plot(AllUTh(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)


% plot(AllUTh_Primary(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color',black, 'MarkerFaceColor','k','MarkerSize',10)
% 
% plot(AllUTh_Primary(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color',black, 'MarkerFaceColor',grey9,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey6,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey2,'MarkerSize',16)
% 
% plot(AllUTh_Primary(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color',black, 'MarkerFaceColor',androidgreen,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color',black, 'MarkerFaceColor',azure,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color',black, 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)

D = [NaN	NaN	1	1	1	1	1	1	1	1	0.001	0.001	0.001	0.001	NaN	NaN	NaN	NaN	NaN	NaN	NaN]; 
WHDMM = [NaN	NaN	44.71	0.13	3.98	0.57	8.18	0	38.73	3.17	0.28	0.006	NaN	NaN	NaN	99.76	0.894	0.083	0.8	NaN	NaN]; 
HZPUM = [NaN	NaN	45.96	0.18	4.06	0.47	7.54	0.13	37.78	3.21	0.332	0.032	0.02	0.28	NaN	99.56	0.899	0.102	0.79	NaN	NaN]; 
WHDMM_U_Th = [0.0032 0.0079];

%D_U_Th = [6.15e-3 5.57e-3];
%D_U_Th = [1.18e-3 8.92e-4];

D_U_Th = [2.05e-3 1.35e-3];
%D_U_Th = [4.49e-3 2.16e-3];

%D_U_Th = [0.0014 0.001];

%D_U_Th = [.00299 .00215];

% %deep
% D_U_Th = [2.05e-3 1.35e-3];
% %shallow
 D_U_Th= [.00615 .00557]; 



FR = 0.001;
F = [0.001:.001:.15];
F_plot = [0.001:.001:.01 .02:.01:.1 .15];
F = round(F,4); 
F_plot = round(F_plot,4); 
[c,d]=intersect(F,F_plot);
F = F(d'); 
F_label = [0.001 .005 .01 .05 .1 .15];
F_label = round(F_label,4); 
[e,f]=intersect(F,F_label);


FR = 0.001; 
Batch_WHDMM = WHDMM(indiciesX)./(D(indiciesX)+F.*(1-D(indiciesX))); 
[Ko, KoAGG]= ZouContinuousMelting_chooseSource(WHDMM(indiciesX), FR ,F,D(indiciesX));
DK_FC = 0.001; 
Batch_WHDMM_K_fractionated = Batch_WHDMM.*0.5.^(DK_FC-1); 
Increm_WHDMM_K_fractionated = Ko.*0.5.^(DK_FC-1); 


Batch_WHDMM_U = WHDMM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
[Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));


Batch_WHDMM_Th = WHDMM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
[Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

% plot(Batch_WHDMM,(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',3,'MarkerSize',8)
% text(Batch_WHDMM(f),(Batch_WHDMM_Th(f)./Batch_WHDMM_U(f))./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
%     ,'HorizontalAlignment','right','Color',CadmiumRed,'FontWeight','bold')
% 

plot(Batch_WHDMM_K_fractionated,(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',2,'MarkerSize',8)
text(Batch_WHDMM_K_fractionated(f),(Batch_WHDMM_Th(f)./Batch_WHDMM_U(f))./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
    ,'HorizontalAlignment','right','Color',CadmiumRed,'FontWeight','bold')


plot(Increm_WHDMM_K_fractionated,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',azure, 'Color',azure,'LineWidth',2,'MarkerSize',8)
% text(Batch_WHDMM_K_fractionated(f),(Batch_WHDMM_Th(f)./Batch_WHDMM_U(f))./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
%     ,'HorizontalAlignment','right','Color',azure,'FontWeight','bold')





%plot(Ko,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)
%plot(KoAGG,(KoAGG_Th./KoAGG_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+:','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)

HZPUM = [NaN	NaN	45.96	0.18	4.06	0.47	7.54	0.13	37.78	3.21	0.332	0.032	0.02	0.28	NaN	99.56	0.899	0.102	0.79	NaN	NaN]; 
HZPUM_U_Th = [0.0203 0.0795];

Batch_HZPUM = HZPUM(indiciesX)./(D(indiciesX)+F.*(1-D(indiciesX))); 
[Ko, KoAGG]= ZouContinuousMelting_chooseSource(HZPUM(indiciesX), FR ,F,D(indiciesX));
Batch_HZPUM_K_fractionated = Batch_HZPUM.*0.5.^(DK_FC-1); 



 Batch_HZPUM_U = HZPUM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
% [Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));
% 
 Batch_HZPUM_Th = HZPUM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
% [Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

% plot(Batch_HZPUM,(Batch_HZPUM_Th./Batch_HZPUM_U)./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), '+:','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',3,'MarkerSize',8)
% text(Batch_HZPUM(f),(Batch_HZPUM_Th(f)./Batch_HZPUM_U(f))./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment'...
%     ,'top','HorizontalAlignment','left','Color',CadmiumRed,'FontWeight','bold')

plot(Batch_HZPUM_K_fractionated,(Batch_HZPUM_Th./Batch_HZPUM_U)./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), '+:','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',2,'MarkerSize',8)
text(Batch_HZPUM_K_fractionated(f),(Batch_HZPUM_Th(f)./Batch_HZPUM_U(f))./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment'...
    ,'top','HorizontalAlignment','left','Color',CadmiumRed,'FontWeight','bold')

%plot(Ko,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color',grey55, 'Color',grey55,'LineWidth',2,'MarkerSize',10)
%plot(KoAGG,(KoAGG_Th./KoAGG_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+:','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)

%D_U_Th = [0.0142 0.0102];
FR = 0.01;
F = [0.01:.01:.15];
F_plot = [.01:.01:.15];
F = round(F,4); 
F_plot = round(F_plot,4); 
[c,d]=intersect(F,F_plot);
F = F(d'); 

Batch_WHDMM = WHDMM(indiciesX)./(D(indiciesX)+F.*(1-D(indiciesX))); 
[Ko, KoAGG]= ZouContinuousMelting_chooseSource(WHDMM(indiciesX), FR ,F,D(indiciesX));

Batch_WHDMM_U = WHDMM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
[Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));

Batch_WHDMM_Th = WHDMM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
[Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

%plot(Batch_WHDMM,(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',grey55, 'Color',grey55,'LineWidth',2,'MarkerSize',10)
%plot(Ko,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color',grey55, 'Color',grey55,'LineWidth',2,'MarkerSize',10)
%plot(KoAGG,(KoAGG_Th./KoAGG_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+:','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)





DK = 0.01;  
%D_U_Th = [0.0142 0.0102];
FR = 0.01;
F = [0.01:.01:.15];
F_plot = [.01:.01:.15];
F = round(F,4); 
F_plot = round(F_plot,4); 
[c,d]=intersect(F,F_plot);
F = F(d'); 

Batch_WHDMM = WHDMM(indiciesX)./(DK+F.*(1-D(indiciesX))); 
[Ko, KoAGG]= ZouContinuousMelting_chooseSource(WHDMM(indiciesX), FR ,F,DK);

Batch_WHDMM_U = WHDMM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
[Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));

Batch_WHDMM_Th = WHDMM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
[Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

%plot(Batch_WHDMM,(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',chartruese, 'Color',chartruese,'LineWidth',2,'MarkerSize',10)
%plot(Ko,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color',chartruese, 'Color',chartruese,'LineWidth',2,'MarkerSize',10)
%plot(KoAGG,(KoAGG_Th./KoAGG_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color',chartruese, 'Color',chartruese,'LineWidth',2,'MarkerSize',10)






%newLegendLabels = {'Arcs' 'OIBs' 'Continental' 'Back Arc','Plume-Ridge','MORB','Seamounts','Siqueros Transform' 'EPR' };

newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem OIB' 'EarthChem MORB',...
    'Jan Mayen' 'N. Kob. Ridge' 'N. Kob. Ridge No Ra226'...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN on/near axis EPR'...
    'First Melts of WHDMM','First Melts of HZPUM'};



xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');
% xlabel(sprintf('%s normalized to {%s}',RatioLabels{xxvalue}, normalizationLabel));
% ylabel(sprintf('%s normalized to {%s}',RatioLabels{yyvalue}, normalizationLabel));
       %
% refline(1/2.5,0)
% refline(1/3.9,0)
% refline(0,1)



axis square
box on

%incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


%set(gca, 'Xtick',[.6:incrementtotal:1.8])
increment = .5; 
%increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.XAxis.MinorTickValues = ax.XLim(1):increment:ax.XLim(2);

increment = .05;
ax.YAxis.MinorTickValues = ax.YLim(1):increment:ax.YLim(2);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
%set(gca, 'Ytick',[.6:incrementtotal:1.8])



if strcmp(Desired_X ,'K2O')==1
set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end


legend(newLegendLabels,'Location','SouthEast','FontSize',10)
axis(axisgood(i,:))
FigureTitle = sprintf('ThU230Th v U v K2O: Canonical Model');
set(gcf,'name',regexprep(FigureTitle,'/_*','')) 
%set(gcf','Position',[654 337 627 592])    
set(gca,'FontName','Times New Roman')
xlabel('K_2O wt%','interpreter','tex')
ylabel('(^{230}Th/^{238}U)','interpreter','tex')
end




% figure(7)
% set(gcf,'Position',[113 318 627 592])
% 
% figure(4)
% set(gcf,'Position',[780 317 627 592])



%% Figure XX HERE
figure()
hold on
%set(gcf,'Position',[179 373 1162 531]) % for 2x1
set(gcf,'Position',[179 50 856 854])
hold on


D_U_Th = [2.05e-3 1.35e-3]; %McDade et al., 2003


subaxis(2,2,1,'Margin',.03,'Spacing',.02,'PaddingBottom',.08)
hold on

axisgood=...
    [1.5e-2 33 0.5 1.6];

Desired_X_all ={'K2O' };
Desired_Y ={'TH230_U238_ACTIVITY'};


for i=1:size(Desired_X_all,2)
Desired_X=Desired_X_all{i};



[a,indiciesX] = ismember(Desired_X,targetStrings_Majors);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off','LineWidth',2,'LabelVerticalAlignment','middle');
if strcmp(Desired_X ,'K2O')==1
   xline(.096,'k:','0.096 D-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.14,'k:','0.14 N-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.394,'k:','0.394 E-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
end

if strcmp(Desired_X ,'K2O/TiO2')==1
   xline(.06,'k:','0.06 D-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   xline(.09,'k:','0.09 N-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   xline(.26,'k:','0.26 E-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   set(gca,'xscale','log')
    ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end

plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)

plot(AllUTh(ARC_indicies,indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh(OIB_indicies,indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)


%  plot(AllUTh(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'o','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',3)
%  plot(AllUTh(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
%  plot(AllUTh(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'p','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)
 %plot(AllUTh(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), 'd','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)


%plot(AllUTh(MIX_indicies,indiciesX),AllUTh_Isotopes(MIX_indicies,indiciesY), 'o','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)

plot(AllUTh(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh(tempIndices_NKR_no226Ra,indiciesX),AllUTh_Isotopes(tempIndices_NKR_no226Ra,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',12)
plot(AllUTh(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)


plot(AllUTh(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)
plot(AllUTh(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh(tempIndices_SiquerosDMORB,indiciesX),AllUTh_Isotopes(tempIndices_SiquerosDMORB,indiciesY), 'd','Color','k', 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',16)



% plot(AllUTh_Primary(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color',black, 'MarkerFaceColor','k','MarkerSize',10)
% 
% plot(AllUTh_Primary(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color',black, 'MarkerFaceColor',grey9,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey6,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey2,'MarkerSize',16)
% 
% plot(AllUTh_Primary(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color',black, 'MarkerFaceColor',androidgreen,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color',black, 'MarkerFaceColor',azure,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color',black, 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)

D = [NaN	NaN	1	1	1	1	1	1	1	1	0.001	0.001	0.001	0.001	NaN	NaN	NaN	NaN	NaN	NaN	NaN]; 
WHDMM = [NaN	NaN	44.71	0.13	3.98	0.57	8.18	0	38.73	3.17	0.28	0.006	NaN	NaN	NaN	99.76	0.894	0.083	0.8	NaN	NaN]; 
HZPUM = [NaN	NaN	45.96	0.18	4.06	0.47	7.54	0.13	37.78	3.21	0.332	0.032	0.02	0.28	NaN	99.56	0.899	0.102	0.79	NaN	NaN]; 
WHDMM_U_Th = [0.0032 0.0079];



FR = 0.001;
F = [0.001:.001:.15];
F_plot = [0.001:.001:.01 .02:.01:.1 .15];
F = round(F,4); 
F_plot = round(F_plot,4); 
[c,d]=intersect(F,F_plot);
F = F(d'); 
F_label = [0.001 .005 .01 .05 .1 .15];
F_label = round(F_label,4); 
[e,f]=intersect(F,F_label);


FR = 0.001; 
Batch_WHDMM = WHDMM(indiciesX)./(D(indiciesX)+F.*(1-D(indiciesX))); 
[Ko, KoAGG]= ZouContinuousMelting_chooseSource(WHDMM(indiciesX), FR ,F,D(indiciesX));
DK_FC = 0.001; 
Batch_WHDMM_K_fractionated = Batch_WHDMM.*0.5.^(DK_FC-1); 
Increm_WHDMM_K_fractionated = Ko.*0.5.^(DK_FC-1); 


Batch_WHDMM_U = WHDMM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
[Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));


Batch_WHDMM_Th = WHDMM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
[Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

DRa = 1e-5; 
Batch_WHDMM_Ra = 1./(DRa+F.*(1-DRa)); 
[Ko_Ra, KoAGG_Ra]= ZouContinuousMelting_chooseSource(1, FR ,F,DRa);


% plot(Batch_WHDMM,(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',3,'MarkerSize',8)
% text(Batch_WHDMM(f),(Batch_WHDMM_Th(f)./Batch_WHDMM_U(f))./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
%     ,'HorizontalAlignment','right','Color',CadmiumRed,'FontWeight','bold')
% 

plot(Batch_WHDMM_K_fractionated,(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',2,'MarkerSize',8)
text(Batch_WHDMM_K_fractionated(f),(Batch_WHDMM_Th(f)./Batch_WHDMM_U(f))./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
    ,'HorizontalAlignment','right','Color',CadmiumRed,'FontWeight','bold')


%plot(Increm_WHDMM_K_fractionated,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',azure, 'Color',azure,'LineWidth',2,'MarkerSize',8)

HZPUM = [NaN	NaN	45.96	0.18	4.06	0.47	7.54	0.13	37.78	3.21	0.332	0.032	0.02	0.28	NaN	99.56	0.899	0.102	0.79	NaN	NaN]; 
HZPUM_U_Th = [0.0203 0.0795];

Batch_HZPUM = HZPUM(indiciesX)./(D(indiciesX)+F.*(1-D(indiciesX))); 
[Ko, KoAGG]= ZouContinuousMelting_chooseSource(HZPUM(indiciesX), FR ,F,D(indiciesX));
Batch_HZPUM_K_fractionated = Batch_HZPUM.*0.5.^(DK_FC-1); 



Batch_HZPUM_U = HZPUM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
% [Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));

Batch_HZPUM_Th = HZPUM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
% [Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

% plot(Batch_HZPUM,(Batch_HZPUM_Th./Batch_HZPUM_U)./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), '+:','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',3,'MarkerSize',8)
% text(Batch_HZPUM(f),(Batch_HZPUM_Th(f)./Batch_HZPUM_U(f))./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment'...
%     ,'top','HorizontalAlignment','left','Color',CadmiumRed,'FontWeight','bold')

plot(Batch_HZPUM_K_fractionated,(Batch_HZPUM_Th./Batch_HZPUM_U)./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), '+:','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',2,'MarkerSize',8)
text(Batch_HZPUM_K_fractionated(f),(Batch_HZPUM_Th(f)./Batch_HZPUM_U(f))./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment'...
    ,'top','HorizontalAlignment','left','Color',CadmiumRed,'FontWeight','bold')






% Fix Axes
xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');

axis square
box on
axis(axisgood(i,:))
%incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';

set(gca, 'Ytick',[.5:.1:1.8])
increment = .05;
ax.YAxis.MinorTickValues = ax.YTick(1):increment:ax.YTick(end);




increment = .5; 
%increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.XAxis.MinorTickValues = ax.XTick(1):increment:ax.XTick(end);


if strcmp(Desired_X ,'K2O')==1
set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end



set(gca,'FontName','Times New Roman')
xlabel('K_2O wt%','interpreter','tex')
ylabel('(^{230}Th/^{238}U)','interpreter','tex')
end




subaxis(2,2,2)
hold on



axisgood=...
    [3e-1 1000 0.5 1.6];



Desired_X_all ={'U'};
Desired_Y ={'TH230_U238_ACTIVITY'};
for i=1:size(Desired_X_all,2)

Desired_X=Desired_X_all{i};



[a,indiciesX] = ismember(Desired_X,targetStrings_Trace);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','HandleVisibility','off','FontName','Times New Roman','FontName','Times New Roman','LabelVerticalAlignment','middle','LabelHorizontalAlignment','right','HandleVisibility','off','LineWidth',2);
xline(1,'k-','PUM','FontSize',fontsizelines,'HandleVisibility','off','FontName','Times New Roman','FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
%hhh = scatter(AllUTh_Trace(:,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(:,indiciesY),EarthChem_MarkerSizes,Colors2plot,'filled','MarkerFaceAlpha',1);



plot(AllUTh_Trace(:,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
plot(AllUTh_Trace(ARC_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh_Trace(OIB_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)

% plot(AllUTh_Trace(CONTINENTAL_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'v','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',5)
% plot(AllUTh_Trace(BACKARC_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',cadmiumgreen, 'MarkerFaceColor',cadmiumgreen,'MarkerSize',5)
%  
% plot(AllUTh_Trace(ICELAND_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor',white,'MarkerSize',7)
% plot(AllUTh_Trace(AZORES_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), '>','Color','k', 'MarkerFaceColor',olivinegreen,'MarkerSize',5)
% plot(AllUTh_Trace(RIFT_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(RIFT_indicies,indiciesY), 'o','Color',articlime, 'MarkerFaceColor',articlime,'MarkerSize',5)


plot(AllUTh_Trace(MORB_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)


plot(AllUTh_Trace(tempIndices_JM,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_NKR,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_NKR_no226Ra,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_NKR_no226Ra,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',12)
plot(AllUTh_Trace(tempIndices_SMR,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)

plot(AllUTh_Trace(tempIndices_Seamount,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_EPR,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_Siqueros,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_SiquerosDMORB,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_SiquerosDMORB,indiciesY), 'd','Color','k', 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',16)




D = [NaN	NaN	1	1	1	1	1	1	1	1	0.001	0.001	0.001	0.001	NaN	NaN	NaN	NaN	NaN	NaN	NaN]; 
WHDMM = [NaN	NaN	44.71	0.13	3.98	0.57	8.18	0	38.73	3.17	0.28	0.006	NaN	NaN	NaN	99.76	0.894	0.083	0.8	NaN	NaN]; 
HZPUM = [NaN	NaN	45.96	0.18	4.06	0.47	7.54	0.13	37.78	3.21	0.332	0.032	0.02	0.28	NaN	99.56	0.899	0.102	0.79	NaN	NaN]; 
WHDMM_U_Th = [0.0032 0.0079];

FR = 0.001;
F = [0.001:.001:.15];
F_plot = [0.001:.001:.01 .02:.01:.1 .15];
F = round(F,4); 
F_plot = round(F_plot,4); 
[c,d]=intersect(F,F_plot);
F = F(d'); 
F_label = [0.001 .005 .01 .05 .1 .15];
F_label = round(F_label,4); 
[e,f]=intersect(F,F_label);


F_label = [0.001 .01 .1 .2];
F_label = round(F_label,4); 
[e,f2]=intersect(F,F_label);


Batch_WHDMM_U = WHDMM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
[Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));

DU_FC = 0.01; 
Batch_WHDMM_U_fractionated = Batch_WHDMM_U.*0.5.^(DU_FC-1); 

Batch_WHDMM_Th = WHDMM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
[Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));


%plot(Batch_WHDMM_U./HZPUM_U_Th(1),(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color','k', 'Color','k','LineWidth',3,'MarkerSize',8)
plot(Batch_WHDMM_U_fractionated./HZPUM_U_Th(1),(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',2,'MarkerSize',8)

text(Batch_WHDMM_U_fractionated(f)./HZPUM_U_Th(1),(Batch_WHDMM_Th(f)./Batch_WHDMM_U(f))./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
    ,'HorizontalAlignment','right','Color',CadmiumRed,'FontWeight','bold')

%plot(Ko,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)
%plot(KoAGG,(KoAGG_Th./KoAGG_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+:','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)

HZPUM = [NaN	NaN	45.96	0.18	4.06	0.47	7.54	0.13	37.78	3.21	0.332	0.032	0.02	0.28	NaN	99.56	0.899	0.102	0.79	NaN	NaN]; 
HZPUM_U_Th = [0.0203 0.0795];

Batch_HZPUM_U = HZPUM_U_Th(1)./(D_U_Th(1)+F.*(1-D_U_Th(1))); 
% [Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th(1));
Batch_HZPUM_U_fractionated = Batch_HZPUM_U.*0.5.^(DU_FC-1); 

Batch_HZPUM_Th = HZPUM_U_Th(2)./(D_U_Th(2)+F.*(1-D_U_Th(2))); 
% [Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th(2));

 plot(Batch_HZPUM_U_fractionated./HZPUM_U_Th(1),(Batch_HZPUM_Th./Batch_HZPUM_U)./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), '+:','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',2,'MarkerSize',8)

 text(Batch_HZPUM_U_fractionated(f)./HZPUM_U_Th(1),(Batch_HZPUM_Th(f)./Batch_HZPUM_U(f))./(HZPUM_U_Th(2)/HZPUM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment'...
    ,'top','HorizontalAlignment','left','Color',CadmiumRed,'FontWeight','bold')




% D_U_Th_shallow = [.00615 .00557]; 
% Batch_WHDMM_U = WHDMM_U_Th(1)./(D_U_Th_shallow(1)+F.*(1-D_U_Th_shallow(1))); 
% [Ko_U, KoAGG_U]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(1), FR ,F,D_U_Th_shallow(1));
% DU_FC = 0.01; 
% Batch_WHDMM_U_fractionated = Batch_WHDMM_U.*0.5.^(DU_FC-1); 
% Batch_WHDMM_Th = WHDMM_U_Th(2)./(D_U_Th_shallow(2)+F.*(1-D_U_Th_shallow(2))); 
% [Ko_Th, KoAGG_Th]= ZouContinuousMelting_chooseSource(WHDMM_U_Th(2), FR ,F,D_U_Th_shallow(2));
% %plot(Batch_WHDMM_U./HZPUM_U_Th(1),(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color','k', 'Color','k','LineWidth',3,'MarkerSize',8)
% plot(Batch_WHDMM_U_fractionated./HZPUM_U_Th(1),(Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-','Color',CadmiumRed, 'Color',airsuperiorityblue,'LineWidth',2,'MarkerSize',8)
% 
% text(Batch_WHDMM_U_fractionated(f)./HZPUM_U_Th(1),(Batch_WHDMM_Th(f)./Batch_WHDMM_U(f))./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), num2str(F_plot(f)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
%     ,'HorizontalAlignment','right','Color',airsuperiorityblue,'FontWeight','bold')



%plot(Ko,(Ko_Th./Ko_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+-.','Color',grey55, 'Color',grey55,'LineWidth',2,'MarkerSize',10)
%plot(KoAGG,(KoAGG_Th./KoAGG_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)), '+:','Color','k', 'Color','k','LineWidth',2,'MarkerSize',10)

newLegendLabels = {'EarthChem' 'EarthChem Arcs' 'EarthChem Ocean Island' 'EarthChem MORB',...
    'Jan Mayen' 'N. Kob. Ridge' 'N. Kob. Ridge No Ra226'...
    'Lamont Seamounts 9.9-10\circN','9.3-9.9\circN on/near axis EPR','Siqueros Transform 8.3-8.4\circN' ...
    'First Melts of Depleted Mantle','First Melts of Primitive Mantle'};

xlabel([Desired_X ' norm to PUM'],'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');


% Fix Axes
xlabel([Desired_X ' norm to PUM'],'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');


axis square
box on
axis(axisgood(i,:))

set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';
set(gca, 'Ytick',[.5:.1:1.8])
increment = .05;
ax.YAxis.MinorTickValues = ax.YTick(1):increment:ax.YTick(end);



if strcmp(Desired_X ,'K2O/TiO2')==1
   xline(.06,'k:','0.06 D-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.09,'k:','0.09 N-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.26,'k:','0.26 E-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   set(gca,'xscale','log')
    ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end

if strcmp(Desired_X ,'U')==1
   xline(0.055/Norm_PUM(indiciesX),'k:','D-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off','LineWidth',2);
   xline(0.083./Norm_PUM(indiciesX),'k:','N-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off','LineWidth',2);
   xline(0.386./Norm_PUM(indiciesX),'k:',' E-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off','LineWidth',2);
end

   set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10 20:10:100 200:100:1000];




xlabel('U / U_{PUM}','interpreter','tex')
ylabel('(^{230}Th/^{238}U)','interpreter','tex')

end





%%%%%%%%%

subaxis(2,2,3,'Margin',.03,'Spacing',.02,'PaddingBottom',.08)
hold on

axisgood=...
    [1.5e-2 33 0.9 4.5];


Desired_X_all ={'K2O' };
Desired_Y ={'RA226_TH230_ACTIVITY'};


for i=1:size(Desired_X_all,2)
Desired_X=Desired_X_all{i};



[a,indiciesX] = ismember(Desired_X,targetStrings_Majors);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off','LineWidth',2,'LabelVerticalAlignment','middle');
if strcmp(Desired_X ,'K2O')==1
   xline(.096,'k:','D-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','top','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.14,'k:',' N-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','top','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.394,'k:','E-MORB','LineWidth',2,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','top','LabelHorizontalAlignment','center','HandleVisibility','off');
end

if strcmp(Desired_X ,'K2O/TiO2')==1
   xline(.06,'k:','0.06 D-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   xline(.09,'k:','0.09 N-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   xline(.26,'k:','0.26 E-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   set(gca,'xscale','log')
    ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end

plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)

plot(AllUTh(ARC_indicies,indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh(OIB_indicies,indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)


%  plot(AllUTh(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'o','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',3)
%  plot(AllUTh(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
%  plot(AllUTh(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'p','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)
 %plot(AllUTh(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), 'd','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)


%plot(AllUTh(MIX_indicies,indiciesX),AllUTh_Isotopes(MIX_indicies,indiciesY), 'o','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)

plot(AllUTh(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)

plot(100,100, 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',12)

plot(AllUTh(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)


plot(AllUTh(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)

plot(AllUTh(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh(tempIndices_SiquerosDMORB,indiciesX),AllUTh_Isotopes(tempIndices_SiquerosDMORB,indiciesY), 'd','Color','k', 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',16)



plot(Batch_WHDMM_K_fractionated,(Batch_WHDMM_Ra./Batch_WHDMM_Th)./(1./WHDMM_U_Th(2)), '+-','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',2,'MarkerSize',8)
text(Batch_WHDMM_K_fractionated(f2),(Batch_WHDMM_Ra(f2)./Batch_WHDMM_Th(f2))./(1./WHDMM_U_Th(2)), num2str(F_plot(f2)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
    ,'HorizontalAlignment','right','Color',CadmiumRed,'FontWeight','bold')


plot(Batch_HZPUM_K_fractionated,(Batch_WHDMM_Ra./Batch_HZPUM_Th)./(1./HZPUM_U_Th(2)), '+:','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',2,'MarkerSize',8)
text(Batch_HZPUM_K_fractionated(f2),(Batch_WHDMM_Ra(f2)./Batch_HZPUM_Th(f2))./(1./HZPUM_U_Th(2)), num2str(F_plot(f2)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment'...
    ,'top','HorizontalAlignment','left','Color',CadmiumRed,'FontWeight','bold')



% plot(AllUTh_Primary(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color',black, 'MarkerFaceColor','k','MarkerSize',10)
% 
% plot(AllUTh_Primary(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color',black, 'MarkerFaceColor',grey9,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey6,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey2,'MarkerSize',16)
% 
% plot(AllUTh_Primary(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color',black, 'MarkerFaceColor',androidgreen,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color',black, 'MarkerFaceColor',azure,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color',black, 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fix Axes
xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');

axis square
box on
%legend(newLegendLabels,'Location','SouthEast','FontSize',10)
axis(axisgood(i,:))
%incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


%set(gca, 'Xtick',[.6:incrementtotal:1.8])
increment = .5; 
%increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.XAxis.MinorTickValues = ax.XTick(1):increment:ax.XTick(end);

increment = .25;
ax.YAxis.MinorTickValues = ax.YTick(1):increment:ax.YTick(end);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
%set(gca, 'Ytick',[.6:incrementtotal:1.8])

if strcmp(Desired_X ,'K2O')==1
set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end




%set(gcf','Position',[654 337 627 592])    
set(gca,'FontName','Times New Roman')
xlabel('K_2O wt%','interpreter','tex')
ylabel('(^{226}Ra/^{230}Th)','interpreter','tex')
end


leg = legend(newLegendLabels,'Location','SouthEast','FontSize',13);
set(leg,'Position',[0.3420 0.5012 0.2336 0.2237])



%%%%%%%%%

subaxis(2,2,4,'Margin',.03,'Spacing',.02,'PaddingBottom',.08)
hold on

axisgood=...
    [.5 1.6 0.9 4.5];



Desired_Y ={'RA226_TH230_ACTIVITY'};
Desired_X_all ={'TH230_U238_ACTIVITY'};

for i=1:size(Desired_X_all,2)

Desired_X=Desired_X_all{i};

[a,indiciesX] = ismember(Desired_X,targetStrings_Isotopes);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


% yline(1,'k-','HandleVisibility','off'); %,'secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off','LineWidth',2,'LabelVerticalAlignment','middle');
% xline(1,'k-','HandleVisibility','off'); %'secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off','LineWidth',2,'LabelVerticalAlignment','middle');

yyyy = yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off','LineWidth',2,'LabelVerticalAlignment','middle');
xline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off','LineWidth',2,'LabelVerticalAlignment','top','LabelHorizontalAlignment','left');


plot(AllUTh_Isotopes(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)

plot(AllUTh_Isotopes(ARC_indicies,indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
plot(AllUTh_Isotopes(OIB_indicies,indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)


%  plot(AllUTh_Isotopes(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'o','Color',airsuperiorityblue, 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',3)
%  plot(AllUTh_Isotopes(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
%  plot(AllUTh_Isotopes(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'p','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)
 %plot(AllUTh_Isotopes(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), 'd','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)


%plot(AllUTh_Isotopes(MIX_indicies,indiciesX),AllUTh_Isotopes(MIX_indicies,indiciesY), 'o','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh_Isotopes(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh_Isotopes(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)

plot(AllUTh_Isotopes(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
plot(AllUTh_Isotopes(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
plot(AllUTh_Isotopes(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)


%plot(AllUTh_Isotopes(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)

plot(AllUTh_Isotopes(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh_Isotopes(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)

plot(AllUTh_Isotopes(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh_Isotopes(tempIndices_SiquerosDMORB,indiciesX),AllUTh_Isotopes(tempIndices_SiquerosDMORB,indiciesY), 'd','Color','k', 'MarkerFaceColor',airsuperiorityblue,'MarkerSize',16)



% plot(AllUTh_Primary(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color',black, 'MarkerFaceColor','k','MarkerSize',10)
% 
% plot(AllUTh_Primary(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color',black, 'MarkerFaceColor',grey9,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey6,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color',black, 'MarkerFaceColor',grey2,'MarkerSize',16)
% 
% plot(AllUTh_Primary(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color',black, 'MarkerFaceColor',androidgreen,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color',black, 'MarkerFaceColor',azure,'MarkerSize',16)
% plot(AllUTh_Primary(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color',black, 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)




plot((Batch_WHDMM_Th./Batch_WHDMM_U)./(WHDMM_U_Th(2)/WHDMM_U_Th(1)),(Batch_WHDMM_Ra./Batch_WHDMM_Th)./(1./WHDMM_U_Th(2)), '+-','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',2,'MarkerSize',8)
text((Batch_WHDMM_Th(f2)./Batch_WHDMM_U(f2))./(WHDMM_U_Th(2)/WHDMM_U_Th(1)),(Batch_WHDMM_Ra(f2)./Batch_WHDMM_Th(f2))./(1./WHDMM_U_Th(2)), num2str(F_plot(f2)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
    ,'HorizontalAlignment','right','Color',CadmiumRed,'FontWeight','bold')




% plot((Batch_HZPUM_Th./Batch_HZPUM_U)./(HZPUM_U_Th(2)/HZPUM_U_Th(1)),(Batch_WHDMM_Ra./Batch_HZPUM_Th)./(1./HZPUM_U_Th(2)), '+:','Color',CadmiumRed, 'Color',CadmiumRed,'LineWidth',2,'MarkerSize',8)
% text((Batch_HZPUM_Th(f2)./Batch_HZPUM_U(f2))./(HZPUM_U_Th(2)/HZPUM_U_Th(1)),(Batch_WHDMM_Ra(f2)./Batch_HZPUM_Th(f2))./(1./HZPUM_U_Th(2)), num2str(F_plot(f2)'),'FontSize',14,'FontName','Times New Roman','VerticalAlignment'...
%     ,'top','HorizontalAlignment','left','Color','g','FontWeight','bold')
% 
% 
% 



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fix Axes

xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');
axis(axisgood(i,:))
axis square
box on

ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


ax.YAxis.MinorTickValues = ax.YTick(1):increment:ax.YTick(end);
% increment = .05;
% ax.XAxis.MinorTickValues = ax.XTick(1):increment:ax.XTick(end);

set(gca, 'Xtick',[.5:.1:1.8])
increment = .05;
ax.XAxis.MinorTickValues = ax.XTick(1):increment:ax.XTick(end);

increment = .25;
ax.YAxis.MinorTickValues = ax.YTick(1):increment:ax.YTick(end);


set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ylabel('(^{226}Ra/^{230}Th)','interpreter','tex')
xlabel('(^{230}Th/^{238}U)','interpreter','tex')

end

% set(leg,'Position',[0.2684 0.4415 0.3096 0.2892])
FigureTitle = sprintf('Figure 1');
set(gcf,'name',regexprep(FigureTitle,'/_*','')) 


%%
%%
figure()
hold on
set(gcf,'name','D versus fn')  
set(gcf,'Position', [988 424 554 475])



DU = D_U_Th(1).*ones(size(F)); 
DTh = D_U_Th(2).*ones(size(F)); 
DRa = DRa.*ones(size(F)); 
DK = 0.001.*ones(size(F)); 



hold on
plot(F,DRa,'LineWidth',4)
plot(F,DK,'LineWidth',4)
plot(F,DU,'LineWidth',4)
plot(F,DTh,'LineWidth',4)



xlabel('Degree of Melting (F)')
ylabel('D_{BULK}')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';
set(gca,'yscale','log')
axis square
box on
%set(gca,'ticklength',2*[0.0200    0.0500])
%set(gca,'fontsize', 20,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
axis([0 .15 10^-5 10^-1])
yyaxis right
axis([0 .15 .9 1.6])
hold on
plot(F,DU./DTh,'LineWidth',4)
leg=legend('D^{Ra}','D^{K}','D^{U}','D^{Th}','D^{U}/D^{Th}','Location','SouthEast','FontSize',16,'Autoupdate','off') ;
xlabel('Degree of Melting (F)')
ylabel('(D^{U}/D^{Th})_{BULK}')
ax = gca;
ax.YAxis(2).MinorTick = 'on';
ax.XAxis.MinorTick = 'on';
increment = .1;
ax.YAxis(2).MinorTickValues = ax.YLim(1):increment:ax.YLim(2);
%axis([0 .15 .9 1.6])
%set(gca,'yscale','log')
axis square
box on
set(gca,'ticklength',1.6*[0.0200    0.0500])
set(gca,'fontsize', 23,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
set(leg,'Position',[0.5420 0.5547 0.1679 0.2547])

save('savedMatFile')
