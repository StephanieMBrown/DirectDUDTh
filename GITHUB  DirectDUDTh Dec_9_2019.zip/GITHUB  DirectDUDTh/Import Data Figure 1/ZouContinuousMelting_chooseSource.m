function [Cf, Cfaggregate] = ZouContinuousMelting_chooseSource(Co_Shaw, phi, fn,Do)
% simplify!


%%
% 
% Co_Shaw=0.002; 
% phi = 0.0001; 
% fn=0.001; 
% Do = 0.001; 




P=Do;


X = (fn - phi) ./(1-phi);
X(X<0) = 0;
Cfexp = (1./(phi+(1-phi).*P))-1;
Cfterm2 = (P+phi.*(1-P))./(Do+phi.*(1-P));
Cf = Co_Shaw./(Do+phi.*(1-P)).*(1-Cfterm2.*X).^Cfexp;

Cs_Zou = (Do - P.*fn)./(1-fn).*Cf; 
Cfexp2 = (1./(phi+(1-phi).*P));
Cfaggregate = Co_Shaw./X.*(1-((1-Cfterm2.*X).^(Cfexp2)));


if X == 0
    Cfaggregate=NaN; 
    %Co_WANT_AGG=NaN; 
end




end

