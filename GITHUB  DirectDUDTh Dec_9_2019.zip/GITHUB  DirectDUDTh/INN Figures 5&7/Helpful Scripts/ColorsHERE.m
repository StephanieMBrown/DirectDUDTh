    %Colors for plotting in RGB units
    %names from here:
    %https://en.wikipedia.org/wiki/List_of_colors:_A%E2%80%93F
    deepOrange = [0.9100    0.4100    0.1700]; %[247 144 30];%
    bitterLime = [.39 .55 .07];
    antiquebronze = [.4 .36 .12];
    fireEngineRed = [.81 .13 .16];
    candyAppleRed = [1	.03	0];
    bananaYellow = [1 .88	.21];
    androidgreen = [.64	.78	.22];
    articlime = [.82	1	.08];
    dollarbill = [.52	.73	.40];
    chartruese = [.87 1 0];
    frenchlime  = [.62	.99	.22];
    olivinegreen = [.60 .725 .415];
    coffee= [.44 .31 .22];
    classicrose = [.98 .80 .91];
    airsuperiorityblue= [.45 .63 .76];
    cadmiumgreen = [0 .42 .24];
    batterychargedblue = [.11 .67 .84];
    celadonblue = [0 .48 .65];
    babyblueeyes=[.63 .79 .95];
   azure = [0 .50 1]; 
   bittersweetShimmer = [.75 .31 .32]; 
   FrenchBlueSky = [.47 .71 1]; 
   FrenchBlue = [0 .45 .73]; 
   FrenchRose = [.96 .29 .54]; 
    
    Aureolin=[.99 .93 0];
    CadmiumYellow = [1 .96 0];%
    corn = [.98 .93 .36];
    CadmiumRed = [.89 0 .13]; 
    fuschia = [1 0 1]; 
    
    
   BurnishedBrown=[.63	.48	.45];
   % lightgrey = [0.90    0.90    0.90];
%     grey2 = [0.700    0.700    0.700];
%     grey3 = [0.500    0.500    0.500];
%     grey4 = [0.300    0.300    0.300];
  %  white = [1 1 1];
    

    white = [1 1 1];
    grey9 = [0.90    0.90    0.90];
    grey85 = [0.85   0.85   0.85];
    grey8 = [0.80    0.80    0.80];
    grey7 = [0.700    0.700    0.700];
    grey6 = [0.600    0.600    0.600];
    grey55 = [0.55    0.55   0.55];
    grey5 = [0.500    0.500    0.500];
    grey4 = [0.400    0.400    0.400];
    grey3 = [0.300    0.300    0.300];
    grey2 = [0.200    0.200    0.200];
    grey1 = [0.100    0.100    0.100];
    
    
yellow = [1 1 0];
magenta = [1 0 1];
cyan=	[0 1 1];
red=	[1 0 0];
green = [0 1 0];
blue = [0 0 1];
white = 	[1 1 1];
black =	[0 0 0];
    