function [specificresults, results,decaycorrectedExcesses] = calculateInitialDUDTh(Th230,Ra226,F_all, minimumDRa_ALL,time4decay )
%% calls no other functions
%clear all %results Fout DU DThsave DRa DUDTH




% % d-morb 
% Th230 = 1.054;
% Ra226 = 4.22;
% %F_all = [0.01];
% F_all = [.0815*.15];
% minimumDRa_ALL = [1e-5 .001];
% % 
% 
% 
% time4decay = 2400; %years
% time4decay = 3000; %years
% time4decay = 0; %years
% % time4decay = 1250; %years
% % time4decay = 1446; %years
% %time4decay = 45000; %years
% %time4decay = 1446; %years

%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%
if time4decay < 9000
Ra226 = (Ra226 - 1).*exp(log(2)/1600*time4decay)+1; 
end

Th230 = (Th230 - 1).*exp(log(2)/75000*time4decay)+1; 
n=1; 

for jj =1:size(F_all,2)
for ll = 1:size(minimumDRa_ALL,2)
%Ko(jj) = K2Omelt*(DK+F.*(1-DK)); 
F = F_all(jj); 
minimumDRa = minimumDRa_ALL(ll); 
%DTh = -1.*(Ra226-1).*F./(F-1); %This will have DRa = 0; 
%minimumDRa = (DTh*F+F*Ra226-DTh-F)/(Ra226*(F-1))

DThsave(n) = (F.*Ra226.*minimumDRa-F.*Ra226-Ra226.*minimumDRa+F)./(F-1);
DTh = DThsave(n); 
DU(n) = (DTh.*F*Th230-DTh.*Th230-F.*Th230+F)./(F-1); 

DRa(n)= (DTh.*F+F.*Ra226-DTh-F)./(Ra226.*(F-1));
DUDTH(n) = DU(n) ./DTh; 
Fout(n)= F; 
%DKout(jj)= DK; 
Th230out(n) = Th230; 
Ra226out(n) = Ra226;
Timeout(n) = time4decay;

n=n+1; 
end
end

results = [Timeout' Th230out' Ra226out' Fout' DRa' DU' DThsave'  DUDTH'];
mat2clip(results)
specificresults = [DU DThsave];

decaycorrectedExcesses = [Th230 Ra226];
end

