
% Choose M1 and M2
% choices in this section are for MAR. 
% Look up for EPR

% First Melt

% Eggvin bank: 71N MAR highest K2O 
% POS436 209DR-2
%     M1_K2Oerupted = 0.5738; %0.568; 
%     M1_Th230 = 1.28;
%     M1_Ra226 = 1.07;
%     M1_tform = 3000; %year


% Eggvin bank: 71N MAR highest 226Ra, lowest K2O     
% POS436 242DR-2
%     M1_K2Oerupted = .267;
%     M1_Th230 = 1.23; 
%     M1_Ra226 = 1.28; 
%     M1_tform = 1000; %years    
    
% 71N MAR jan mayen Highest K2O with 226Ra diseq
% SM01-DR-60-43 USED
    M1_K2Oerupted = 2.67; 
    M1_Th230 = 1.15;
    M1_Ra226 = 1.05;
    M1_Uerupted = 1.71; 
    M1_Therupted = 6.48; 

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%M2


% Eggvin bank: 71N MAR highest 226Ra, lowest K2O     
% POS436 242DR-2
%     M2_K2Oerupted = .267;
%     M2_Th230 = 1.23; 
%     M2_Ra226 = 1.28; 
%     M2_tform = 2000; %years   
 
% Eggvin bank: 71N MAR
% second lowest K2O, goes to higher 230Th
% POS436 215DR-1
%     M3_K2Oerupted = .309;
%     M3_Th230 = 1.3; 
%     M3_Ra226 = 1.09; 

% POS436 253DR-E2
    M2_K2Oerupted = .45;
    M2_Th230 = 1.32; 
    M2_Ra226 = 1.23; 

    
    
    
 % Eggvin bank: 71N MAR highest 226Ra, lowest K2O     
% POS436 209DR-2 USED
%     M2_K2Oerupted = 0.5738; %0.568; 
%     M2_Th230 = 1.28;
%     M2_Ra226 = 1.07;
%    
    

% 71N MAR, lowest K2O, but no measured 226Ra
% POS436 246DR-2
%     M2_K2Oerupted = .074;
%     M2_Th230 = 1.36; 
%     M2_Ra226 = 1.28; 
%     M2_tform = 0; %years    



% 71N MAR jan mayen lowest K2O
% SM01-DR-5-5    
%     M2_K2Oerupted = 2.48; 
%     M2_Th230 = 1.15;
%     M2_Ra226 = 1.16;
%     M2_tform = 0; %year
    


%     


% Eggvin bank: 71N MAR highest 226Ra, lowest K2O     
% POS436 242DR-2 USED
    M3_K2Oerupted = .267;
    M3_Th230 = 1.23; 
    M3_Ra226 = 1.28; 

%%%%%%%%%%%%%%%%%%%%