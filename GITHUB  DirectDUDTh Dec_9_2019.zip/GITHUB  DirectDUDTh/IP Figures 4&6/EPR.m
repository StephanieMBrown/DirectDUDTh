% Choose M1 and M2
% choices in this section are for EPR. 
% Look further down for MAR


% M1 = First Melt
% EPR
    % EPR R54-2
    M1_Th230 = 1.2345;
    M1_Ra226 = 1.343;
    M1_K2Oerupted = 0.36; 
    M1_Uerupted = 0.26; 
    M1_Therupted = 0.72;

% EPR Siqueros
%     M1_Th230 = 1.196;
%     M1_Ra226 = 1.03;
%     M1_K2Oerupted = 0.73; 


% EPR A2370-1   
%     M1_K2Oerupted = .13;
%     M1_Ra226 = 2.010; 
%     M1_Th230 = 1.195; 
%     M1_Uerupted = 0.0617; 
%     M1_Therupted = 0.1608; 
%  
    
    
    
    
    
    % EPR A2358-4  
%     M1_K2Oerupted = .15;
%     M1_Ra226 = 2.22; 
%     M1_Th230 = 1.17; 
%     M1_Uerupted = 0.068; 
%     M1_Therupted = 0.1688; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% M2 = Last Pooled Melt


 % A2370-1   WORKS BEST
    M2_K2Oerupted = .11;
    M2_Ra226 = 2.21; 
    M2_Th230 = 1.159; 
    
    
  % A2361-6
%     M2_K2Oerupted = .09;
%     M2_Ra226 = 2.48; 
%     M2_Th230 = 1.142; 
%     
%   
    % EPR A2370-1   
%     M2_K2Oerupted = .12;
%     M2_Ra226 = 2.010; 
%     M2_Th230 = 1.195; 

%     % EPR A2370-1   
%     M2_K2Oerupted = .12;
%     M2_Ra226 = 2.31; 
%     M2_Th230 = 1.171; 
% %     
    
    
%A2384-6
%     M2_K2Oerupted = .02;
%     M2_Ra226 = 4.22; 
%     M2_Th230 = 1.054; 
% 
%     M2_K2Oerupted = .02;
%     M2_Ra226 = 3.5; 
%     M2_Th230 = 1.06; 

    
% A2372-1   
%     M2_K2Oerupted = .11;
%     M2_Ra226 = 2.89; 
%     M2_Th230 = 1.123; 
    
    % % A2368-4   
%     M2_K2Oerupted = .08;
%     M2_Ra226 = 2.75; 
%     M2_Th230 = 1.115; 




    
%      % A497-001B  
%     M2_K2Oerupted = .12;
%     M2_Ra226 = 2.31; 
%     M2_Th230 = 1.171; 

     % A2497-1
%     M2_K2Oerupted = .12;
%     M2_Ra226 = 2.34; 
%     M2_Th230 = 1.169; 


%     M2_K2Oerupted = .12;
%     M2_Ra226 = 2.01; 
%     M2_Th230 = 1.195; 