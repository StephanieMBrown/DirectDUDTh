function [CnLrelative, Cn_accumulated_relative, Cnrrelative,fn,Dn,Lnexp] = Shaw_incremental_continuousIncrease(Dn, fp,n_end,meltfraction)
%close all
%clear all

tol  = 1e-10;

% maxfn = (mineralmodes./meltmodes);
% maxfn = min(maxfn(maxfn> 0));


mineralmodes = [1];
meltmodes = [1];



Co = 1;
Co_Shaw = Co;


% Do = mineralmodes*DLa';
% P = meltmodes*DLa';


%% incremental Shaw

n=1:n_end;  %# of steps
Wo =1;% initial mass, grams
l = meltfraction; % constant melt mass, grams

F1 = l./Wo; % initial melt fraction, percent
W1S = Wo-l;% solid mass after 1 step
L1 = l; 

Fn = ones(1,size(n,2)).*F1;%array of melt fractions as melting proceeds 

WnS = (1-F1).^n.*Wo;
fn = 1 - (1-F1).^n; 




% Dn(1) = (Do - P.*F1)./(1-F1);
% for iii = 2:max(n)
%   Dn(iii) = (Dn(iii-1) - P.*Fn(iii))./ (1-Fn(iii));
% end
% %Dn = (Do - n.*P.*Fn)./(1-n.*Fn)



% DCPX Th = 0.028-0.0006*P(kbars) and 
% DCPX/DCPX = 0.895+0.013*P(kbars). 
% 



D1 = Dn(1); 
if L1 > fp
    Q1 = fp.*(Wo-L1)./(F1.*Wo.*(1-fp));
else 
    Q1 = 1;
end

% if Q1>1
% Q1 = 1;
% end
        
        
L1r = Q1.*F1.*Wo;
L1exp = (1-Q1).*F1.*Wo;
W1r = (1-F1+Q1.*F1).*Wo;
precentmeltresidue = L1r./W1r;
C1L = Co.*Wo./(D1.*W1S+l);
%C1L_test = Co./(D1.*(1-F1)+F1);
C1r = C1L.*(D1.*W1S+L1r)./W1r;
%C1r  = Co.*Wo/W1r.*(D1.*W1S+L1r)./(D1.*W1S+L1);

%% now try iterating 

Ln(1)  = L1; 
Lnr(1) = L1r;
Lnexp(1) = L1exp; 
Wnr(1) = W1r; 
CnL(1) = C1L;
Cnr(1) = C1r;
Cnrrelative(1) = Cnr(1)./Co;
CnLrelative(1) = CnL(1)./Co;
WnrTEST(1) = W1r;

Cn_accumulated(1) = (Co.*Wo - Cnr(1).*Wnr(1))./(Wo - Wnr(1));
Cn_accumulated_relative(1) = Cn_accumulated(1)./Co;
   
Xphaseprop(1,:) =    (mineralmodes - meltmodes.*Fn(1))./(1-Fn(1));
Xphaseprop_test(1,:) =    (Wo.*mineralmodes - L1.*meltmodes)./W1S;
Qn(1) = Q1;
%Fn_test = (1-(1-F1).^n);

ln(1) = l;
for i= 2:max(n)
    
    Xphaseprop(i,:)  =  (Xphaseprop(i-1,:) - meltmodes.*Fn(i))./(1-Fn(i));
    
    ln(i) = Fn(i).*WnS(i-1);
    WnS_TEST(i) = WnS(i-1) - ln(i); % array of residual solid masses
    
    Ln(i) = ln(i) + Lnr(i-1); 
%     Do = Xphaseprop(i,:) *DLa';
%     Dn(i) =(Do - P.*(Ln(i)))./(1-(Ln(i)));

        Qn(i) = (fp.*WnS(i))./(ln(i).*(1-fp)+Lnr(i-1).*(1-fp));        
        if Qn(i)>1
            Qn(i) = 1;
        end

    Lnr(i) = Qn(i).*Ln(i); 
    Lnexp(i) = (1-Qn(i)).*Ln(i);
    Wnr(i) = WnS(i)+Lnr(i);
    
    WnrTEST(i) = Wnr(i-1) - Lnexp(i);
    
    CnL(i) = Cnr(i-1).*Wnr(i-1)./(Dn(i).*WnS(i)+Ln(i));
    Cnr(i) = Cnr(i-1).*Wnr(i-1)./Wnr(i).*(Dn(i).*WnS(i)+Lnr(i))./(Dn(i).*WnS(i)+Ln(i));
    CnLrelative(i) =  CnL(i)./Co;
    Cnrrelative(i) = Cnr(i)./Co;
    Cn_accumulated(i) = (Co.*Wo - Cnr(i).*Wnr(i))./(Wo - Wnr(i));
    Cn_accumulated_relative(i) = Cn_accumulated(i)./Co;
    Xphaseprop_test(i,:)  =  (WnS(i-1).* Xphaseprop_test(i-1,:) - ln(i).*meltmodes)./WnS(i);
   %Xphaseprop_test(i,:)  =  (Wnr(i-1).* Xphaseprop_test(i-1,:) - Ln(i).*meltmodes)./WnS(i);
   
   
end





[i,j] = find(Xphaseprop'<0);
CnLrelative_indicies2remove = j;
CnLrelative(CnLrelative_indicies2remove) =[];
Cn_accumulated_relative(CnLrelative_indicies2remove) =[];
fn(CnLrelative_indicies2remove) = [];
CnL(CnLrelative_indicies2remove) = [];
Lnexp(CnLrelative_indicies2remove) = [];
Cnr(CnLrelative_indicies2remove) = [];
Wnr(CnLrelative_indicies2remove) = [];
WnrTEST(CnLrelative_indicies2remove) = [];
ln(CnLrelative_indicies2remove)=[];
Lnr(CnLrelative_indicies2remove) = [];
Ln(CnLrelative_indicies2remove) = [];
Qn(CnLrelative_indicies2remove) = [];
Cn_accumulated(CnLrelative_indicies2remove) = [];
WnS(CnLrelative_indicies2remove) = [];






for jj = 1:size(Lnexp,2)    
    Cn_accumulated_test(jj) = CnL(1:jj)*Lnexp(1:jj)'./sum(Lnexp(1:jj)); % this is the concentration in the liquid
end








end

