%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize
clear testK CompleteIngrowth_Pool_Th230 meltsSoFar
close all
clear all
addpath('Helpful Scripts')
addpath('..\Import Data Figure 1\')
load('savedMatFile')

modelType = 'IP';

'NEW RUN'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% THINGS TO CHANGE:

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Colors 
color4melting_pool = grey3;
color4melting_nearfrac = grey8;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Choose F Retained

FRetained = 0.01; 
FRetained_string = '1%'; 
meltInc = 0.0001; 


% FRetained = 0.001; 
% FRetained_string = '0.1%'; 
% meltInc = 0.0001; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Choose DK2O and DRa which relate to SpGar or Plag field melting. Also
% choice to gradually increase
% 
%     FieldNote = 'SpG'; 
%     M1_FC = 0.4; 
%     M1_DK2O = 0.001; 
%     M1_DRa = 1e-5; 
%     M2_FC=0.4; 
%     M2_DK2O = 0.001; 
%     M2_DRa = 1e-5; 
    
  
    FieldNote = 'Plag'; 
    M1_FC = 0.4; 
    M1_DK2O = 0.01; 
    M1_DRa = 0.001; 
    M2_FC=0.4; 
    M2_DK2O = 0.01; 
    M2_DRa = 0.001; 


%         FieldNote = 'SpinelPlag'; 
%         M1_FC = 0.4; 
%         M1_DK2O = 0.001; 
%         M1_DRa = 1e-5; 
%         M2_FC=0.4; 
%         M2_DK2O = 0.01; 
%         M2_DRa = 0.001; 
% %     

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% choose tform
%     M1_tform = 0; %years
%     M2_tform = 0; %years 
   
    M1_tform = 3000; %years
    M2_tform = 1000; %years 
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Load datafile 
EPR   % D MORBs are NF melts (not directly used)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% END OF THINGS TO CHANGE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


'Time to return the first melt to a slope of :'
lambda226 = log(2)/1600;
slope = 0
newEx = slope.*M1_Th230 + (M2_Ra226 - slope.*M2_Th230)
time = 1./lambda226.*log((newEx-1)./(M1_Ra226-1))


% Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
  

% For calculating diseq, don't worry about this:
ThU_Source = 1; 
RaTh_Source = 1;


% Calculate Ds:
% FIRST MELT
%DK_FC = 0.001; 
DK_FC = 0.07; 
M1_K2Oeruptedprimary = M1_K2Oerupted./(1-M1_FC).^(DK_FC-1);
M1_Ueruptedprimary = M1_Uerupted./(1-M1_FC).^(DK_FC-1); % Assume no FC of U and Th during XFC
M1_Theruptedprimary = M1_Therupted./(1-M1_FC).^(DK_FC-1);
K2Osource = M1_K2Oeruptedprimary.*(M1_DK2O+FRetained.*(1-M1_DK2O));
[M1_DUTh, results,M1_decaycorrectedExcesses] = calculateInitialDUDTh(M1_Th230,M1_Ra226,FRetained, M1_DRa,M1_tform);

Usource = M1_Ueruptedprimary.*(M1_DUTh(1)+FRetained.*(1-M1_DUTh(1)));
Thsource = M1_Theruptedprimary.*(M1_DUTh(2)+FRetained.*(1-M1_DUTh(2)));
Source_U_Th = [Usource Thsource];
ThU_Source_equiline = Thsource./Usource; 

Source_U_Th
ThU_Source_equiline


% % To change U, Th source abundance composition from DMM:
% Source_U_Th = WHDMM_U_Th; 
% % To change U/Th source ratio from DMM:
% ThU_WHDMM = 2.4678;  





% LAST POOLED MELT
%use K2O of erupted basalt to calculation F of the final pooled melt
M2_K2Oprimary = M2_K2Oerupted./(1-M2_FC).^(DK_FC-1);
[Fmax] = solveFgivenK2Opool_Inc(M1_DK2O, M2_DK2O, M2_K2Oprimary,K2Osource,FRetained,meltInc); 
% 'max degree of melting to generated pooled melt'
% Fmax

[M2_DUTh,ff, maxF, fn,ignoreliquids,M2_decaycorrectedExcesses] = solveDUDTh_finalPooledMelt(M2_Th230,M2_Ra226,M1_DUTh,FRetained,...
    Fmax,M2_DRa,meltInc,M2_tform);




%rerun melting using calculated Ds

minnn = M1_DUTh(1);
maxx = M2_DUTh(1);
DU=[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];

minnn = M1_DUTh(2);
maxx = M2_DUTh(2);
DTh=[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];

minnn = M1_DK2O; 
maxx = M2_DK2O; 
DK=[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];

minnn = M1_DRa;
maxx = M2_DRa;
DRa=[minnn.*ones(1,ignoreliquids) linspace(minnn,maxx,size(fn,2)-ignoreliquids)];


%%
figure(1)
close
figure(1)
hold on
set(gcf,'name','D versus F')  
set(gcf,'Position', [503 480 554 475])

hold on
axis([0 10 10^-5 0.1])
plot(fn*100,DRa,'-','LineWidth',2,'Color','k')
plot(fn*100,DK,'-.','LineWidth',2,'Color','k')

plot(fn*100,DU,'-','LineWidth',5,'Color',black)
plot(fn*100,DTh,'-','LineWidth',5,'Color',grey55)


%xline(fn(ignoreliquids),'k-','HandleVisibility','off','LineWidth',2);
xline(100*FRetained,'k-','F_{R}','LineWidth',1,'FontSize',12,'LabelHorizontalAlignment','right','LabelVerticalAlignment','bottom','HandleVisibility','off');

xlabel('Degree of Melting (F_{N})')
ylabel('D_{BULK}')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';
set(gca,'yscale','log')
axis square
box on
%set(gca,'ticklength',2*[0.0200    0.0500])
%set(gca,'fontsize', 20,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')

yyaxis right
hold on
plot(fn*100,DU./DTh,'-','LineWidth',5,'Color',grey9)
leg=legend('D^{Ra}','D^{K}','D^{U}','D^{Th}','D^{U}/D^{Th}','Location','SouthEast','FontSize',16,'Autoupdate','off') ;
xlabel('Degree of Melting (F_{N}) in %')
ylabel('(D^{U}/D^{Th})_{BULK}')
ax = gca;
axis([0 10 1 3])
ax.YAxis(2).MinorTick = 'on';
set(ax, 'Ytick',[1:0.2:3])
set(ax, 'Xtick',[1:1:10])
ax.XAxis.MinorTick = 'on';
increment = .5;
ax.XAxis.MinorTickValues = 0.5:increment:ax.XTick(end);

increment = .1;
ax.YAxis(2).MinorTickValues = ax.YTick(1):increment:ax.YTick(end);

%set(gca,'yscale','log')
axis square
box on
set(gca,'ticklength',1.6*[0.0200    0.0500])
set(gca,'fontsize', 20,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
set(leg,'Position',[0.6377 0.2200 0.1679 0.2547])


%%

[CnLrelative_U, Cn_accumulated_relative_U, Cnr_U,fn,Dn_U,Lnexp_U] = Shaw_incremental_continuousIncrease(DU,FRetained,size(fn,2),meltInc);
[CnLrelative_Th, Cn_accumulated_relative_Th, Cnr_Th,fn,Dn_Th,Lnexp_Th] = Shaw_incremental_continuousIncrease(DTh,FRetained,size(fn,2),meltInc);
[CnLrelative_K, Cn_accumulated_relative_K, Cnr_K,fn,Dn_K,Lnexp_K] = Shaw_incremental_continuousIncrease(DK, FRetained,size(fn,2),meltInc);
[CnLrelative_Ra, Cn_accumulated_relative_Ra, Cnr_Ra,fn,Dn_Ra,Lnexp_Ra] = Shaw_incremental_continuousIncrease(DRa, FRetained,size(fn,2),meltInc);
dd = [ignoreliquids+1:size(fn,2)];

Cnr_U = [1 Cnr_U(1:end-1)]; 
Cnr_Th = [1 Cnr_Th(1:end-1)]; 
Cnr_K = [1 Cnr_K(1:end-1)]; 
Cnr_Ra = [1 Cnr_Ra(1:end-1)]; 

ZeroIngrowth_NF_Th230 = (CnLrelative_Th./CnLrelative_U)./(ThU_Source); 
ZeroIngrowth_NF_Ra226 = (CnLrelative_Ra./CnLrelative_Th)./(RaTh_Source); 

CompleteIngrowth_NF_Th230  = (CnLrelative_Th./CnLrelative_U)./(Cnr_Th./Cnr_U); 
CompleteIngrowth_NF_Ra226= (CnLrelative_Ra./CnLrelative_Th)./(Cnr_Ra./Cnr_Th); 

clear CompleteIngrowth_Pool_Th230 CompleteIngrowth_Pool_Ra226 meltsSoFar averageF_track

for z = 1:size(Lnexp_U,2)
    meltsSoFar = Lnexp_U(1:z)./sum(Lnexp_U(1:z));  

    AvgRa_z(z) = CnLrelative_Ra(1:z)*meltsSoFar';
    AvgRa_R_z(z) = Cnr_Ra(1:z)*meltsSoFar'; 
    
    AvgTh_z(z) = CnLrelative_Th(1:z)*meltsSoFar';    
    AvgTh_R_z(z) = Cnr_Th(1:z)*meltsSoFar';

    AvgU_z(z) = CnLrelative_U(1:z)*meltsSoFar';
    AvgU_R_z(z) = Cnr_U(1:z)*meltsSoFar';  
    
    averageF_track(z) = fn(1:z)*meltsSoFar'; 
end

ZeroIngrowth_Pool_Th230 = (AvgTh_z./AvgU_z)./ThU_Source;
ZeroIngrowth_Pool_Ra226 = (AvgRa_z./AvgTh_z)./RaTh_Source;

CompleteIngrowth_Pool_Th230 = (AvgTh_z./AvgU_z)./(AvgTh_R_z./AvgU_R_z); 
CompleteIngrowth_Pool_Ra226= (AvgRa_z./AvgTh_z)./(AvgRa_R_z./AvgTh_R_z); 
averageF = fn*meltsSoFar'; 


% deal with U and K too!
CnLrelative_K_fractionated = K2Osource.*CnLrelative_K.*(1-M2_FC).^(DK_FC-1); 
% CnLrelative_K_fractionated = CnLrelative_K.*(1-M2_FC).^(DK_FC-1); 
% Cn_accumulated_relative_K_fractionated = Cn_accumulated_relative_K.*(1-M2_FC).^(DK_FC-1); 
fractionatedPooledK2O = K2Osource.*Cn_accumulated_relative_K.*(1-M2_FC).^(DK_FC-1); 
%fractionatedPooledK2O = K2Osource.*testK(dd).*(1-M2_FC).^(DK_FC-1); 


U_inc = Source_U_Th(1).*CnLrelative_U.*(1-M2_FC).^(DU_FC-1); 
Th_inc = Source_U_Th(2).*CnLrelative_Th.*(1-M2_FC).^(DU_FC-1); 

U_pool = Source_U_Th(1).*Cn_accumulated_relative_U.*(1-M2_FC).^(DU_FC-1); 
Th_pool = Source_U_Th(2).*Cn_accumulated_relative_Th.*(1-M2_FC).^(DU_FC-1); 


%%
%%% Shaped melting regime
height = 1:ff; 
%TrangularRegime= 2.*(ff-height+1); %length of the base
%TrangularRegime= 2.*(ff-height+1); %length of the base
TrangularRegime=2.*flip(height).*tand(45); 
% pooling width. z=1 is full pooling, z = end is column pooling
clear Fn_poolWidth
for z = 1:ff
clear NormTrangularRegime_temp
TrangularRegime_temp = TrangularRegime; 
TrangularRegime_temp(1:z-1) = TrangularRegime_temp(z); 
NormTrangularRegime_temp = TrangularRegime_temp./sum(TrangularRegime_temp); 
Fn_poolWidth(z) = fn*NormTrangularRegime_temp'; 
end

TrangularRegime(1:ignoreliquids)=0; 

FullPullWeights = TrangularRegime./nansum(TrangularRegime); 
FullPull_fn = fn*FullPullWeights';
% FullPull_230Th = CompleteIngrowth_NF_Th230*FullPullWeights';
% FullPull_226Ra = CompleteIngrowth_NF_Ra226*FullPullWeights';
% FullPull_U = CnLrelative_U*FullPullWeights';
% FullPull_Th = CnLrelative_Th*FullPullWeights';
% FullPull_K = CnLrelative_K*FullPullWeights';
% 
% 


for z = 1:size(FullPullWeights,2)
    meltsSoFar_full = FullPullWeights(1:z)./sum(FullPullWeights(1:z));  

    AvgRa_z_full(z) = CnLrelative_Ra(1:z)*meltsSoFar_full';
    AvgRa_R_z_full(z) = Cnr_Ra(1:z)*meltsSoFar_full'; 
    
    AvgTh_z_full(z) = CnLrelative_Th(1:z)*meltsSoFar_full';    
    AvgTh_R_z_full(z) = Cnr_Th(1:z)*meltsSoFar_full';

    AvgU_z_full(z) = CnLrelative_U(1:z)*meltsSoFar_full';
    AvgU_R_z_full(z) = Cnr_U(1:z)*meltsSoFar_full';  
    
    
    AvgK_z_full(z) = CnLrelative_K(1:z)*meltsSoFar_full';
    
    averageF_track_full(z) = fn(1:z)*meltsSoFar_full'; 
end


FullPull_U = AvgU_z_full(end); %CnLrelative_U*FullPullWeights';
FullPull_Th = AvgTh_z_full(end); ; %CnLrelative_Th*FullPullWeights';
FullPull_K = AvgK_z_full(end); %CnLrelative_K*FullPullWeights';

FullPull_U_fractionated = Source_U_Th(1).*FullPull_U.*(1-M2_FC).^(DK_FC-1); 
 FullPull_K_fractionated = K2Osource.*FullPull_K.*(1-M2_FC).^(DK_FC-1); 
% FullPull_U_fractionated = FullPull_U.*(1-M2_FC).^(DK_FC-1); 


% FullPull_230Th = CompleteIngrowth_NF_Th230*FullPullWeights';
% FullPull_226Ra = CompleteIngrowth_NF_Ra226*FullPullWeights';

FullPull_230Th = (AvgTh_z_full./AvgU_z_full)./(AvgTh_R_z_full./AvgU_R_z_full); 
FullPull_226Ra= (AvgRa_z_full./AvgTh_z_full)./(AvgRa_R_z_full./AvgTh_R_z_full); 

FullPull_230Th = FullPull_230Th(end); 
FullPull_226Ra= FullPull_226Ra(end); 



%%

modelNamev2 = sprintf('%s%s%s%sFR%s%s%.2G-%.2Gkyr', modelType, '\_' , FieldNote, '\_', FRetained_string,'\_', M1_tform/1000,M2_tform/1000);
modelName = sprintf('%s%s%s%sFR%s%s%.2G-%.2Gkyr', modelType, '_' , FieldNote, '_', FRetained_string,'_', M1_tform/1000,M2_tform/1000);

%FR = %.2G 
results2printout = sprintf('\nModel ID: \n%s \n Min K2O source: %.2G wt%% \n M1 FInc: %.2G,FMean: %.2G \n M2 FMax: %.2G,FMean: %.2G \n M1 226Ra of %.3G corrected to %.3G \n M2 226Ra of %.3G corrected to %.3G  \n M1: DU,D{Th},DU/D{Th}: [%.2G,%.2G,%.2G] \n M2: DU,D{Th},DU/D{Th}: [%.2G,%.2G,%.2G]',... 
modelNamev2,...
K2Osource,...
FRetained,FRetained,...
maxF,...
averageF,...
M1_Ra226,...
M1_decaycorrectedExcesses(2),...
M2_Ra226,...
M2_decaycorrectedExcesses(2),...
M1_DUTh(1), M1_DUTh(2),M1_DUTh(1)./M1_DUTh(2),...
M2_DUTh(1), M2_DUTh(2),M2_DUTh(1)./M2_DUTh(2)...
); 

results2printout


    
results2clip = [results(:,1:5)  M1_DK2O M1_K2Oeruptedprimary K2Osource FRetained FRetained results(:,6:8) ;
M2_tform M2_decaycorrectedExcesses FRetained M2_DRa M2_DK2O M2_K2Oprimary K2Osource  maxF averageF M2_DUTh M2_DUTh(1)./M2_DUTh(2) ];

results2clip(:,1) = results2clip(:,1)./1000; 
mat2clip(results2clip)

%F_plot = sort(unique(([0.001 0.005 .01 .05 .1 .15 .2 .25 averageF FR])));

F_plot = [FRetained averageF];

for wee = 1:size(F_plot,2)
  [val,idx]=min(abs(averageF_track-F_plot(wee)));
  error(wee) = averageF_track(idx) - F_plot(wee);
   %minVal=averageF_track(idx)  ;
   if abs(error(wee)) < 0.001
   jjj(wee) =  idx; 
   else
       jjj(wee) =  NaN; 
   end
end
jjj(isnan(jjj))=[]; 


F_plot_v2 = sort([0.001:.001:.01 .02:.01:.1 .15 .2 .25 averageF]);
for wee = 1:size(F_plot_v2,2)
  [val,idx]=min(abs(averageF_track-F_plot_v2(wee)));
  error(wee) = averageF_track(idx) - F_plot_v2(wee);
   %minVal=averageF_track(idx)  ;
   if abs(error(wee)) < 0.001
   jjj_v2(wee) =  idx; 
   else
       jjj_v2(wee) =  NaN; 
   end
end
jjj_v2(isnan(jjj_v2))=[]; 



F_plot_v3 = sort([0.001:.001:.01 .02:.01:.1 .15 .2 .25 maxF]);
F_plot_v3(F_plot_v3<FRetained)=[]; 
for wee = 1:size(F_plot_v3,2)
  [val,idx]=min(abs(fn-F_plot_v3(wee)));
  error(wee) = fn(idx) - F_plot_v3(wee);
   %minVal=averageF_track(idx)  ;
   if abs(error(wee)) < 0.001
   jjj_v3(wee) =  idx; 
   else
       jjj_v3(wee) =  NaN; 
   end
end
jjj_v3(isnan(jjj_v3))=[];

F_plot_v4 = sort([0.005 .01 .05 .1]);
F_plot_v4(F_plot_v4<FRetained)=[]; 
for wee = 1:size(F_plot_v4,2)
  [val,idx]=min(abs(fn-F_plot_v4(wee)));
  error(wee) = fn(idx) - F_plot_v4(wee);
   %minVal=averageF_track(idx)  ;
   if abs(error(wee)) < 0.001
   jjj_v4(wee) =  idx; 
   else
       jjj_v4(wee) =  NaN; 
   end
end
jjj_v4(isnan(jjj_v4))=[];

%jjj is what you want%
%averageF_track(jjj)

% Plots
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
figure(2); 
close 
figure(2)
hold on

%set(gcf,'Position',[179 373 1162 531]) % for 2x1
set(gcf,'Position',[17 11 856 854])
hold on

FigureTitle = sprintf('Th230-Ra226-U-K2O');
set(gcf,'name',regexprep(FigureTitle,'/_*','')) 

subaxis(2,2,1,'Margin',.03,'Spacing',.02,'PaddingBottom',.08)
hold on

axisgood=...
    [1.5e-2 33 0.5 1.6];

Desired_X_all ={'K2O' };
Desired_Y ={'TH230_U238_ACTIVITY'};


for i=1:size(Desired_X_all,2)
Desired_X=Desired_X_all{i};



[a,indiciesX] = ismember(Desired_X,targetStrings_Majors);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off','LineWidth',2,'LabelVerticalAlignment','middle');
if strcmp(Desired_X ,'K2O')==1
   xline(.096,'k-','0.096 D-MORB','LineWidth',1,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.14,'k-','0.14 N-MORB','LineWidth',1,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.394,'k-','0.394 E-MORB','LineWidth',1,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
end

if strcmp(Desired_X ,'K2O/TiO2')==1
   xline(.06,'k-','0.06 D-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   xline(.09,'k-','0.09 N-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   xline(.26,'k-','0.26 E-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   set(gca,'xscale','log')
    ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Real Data for Comparison

% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
% plot(AllUTh(ARC_indicies,indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
% plot(AllUTh(OIB_indicies,indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)

%  plot(AllUTh(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'o','Color',green, 'MarkerFaceColor',green,'MarkerSize',3)
%  plot(AllUTh(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
%  plot(AllUTh(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'p','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)
%  plot(AllUTh(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), 'd','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)
%  plot(AllUTh(MIX_indicies,indiciesX),AllUTh_Isotopes(MIX_indicies,indiciesY), 'o','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)

% plot(AllUTh(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
% plot(AllUTh(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
% plot(AllUTh(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
% plot(AllUTh(tempIndices_NKR_no226Ra,indiciesX),AllUTh_Isotopes(tempIndices_NKR_no226Ra,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',11)



plot(AllUTh(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)
plot(AllUTh(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Model Data

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Complete Ingrowth, Near Fractional Melts
plot(CnLrelative_K_fractionated(dd),...
    CompleteIngrowth_NF_Th230(dd),...
    '-','Color',color4melting_nearfrac, 'Color',color4melting_nearfrac,'LineWidth',5,'MarkerSize',8)

plot(CnLrelative_K_fractionated(jjj_v3),...
    CompleteIngrowth_NF_Th230(jjj_v3),...
    '.','MarkerFaceColor',color4melting_nearfrac, 'Color',black,'LineWidth',1,'MarkerSize',8)

% text(CnLrelative_K_fractionated(jjj_v4),...
%     CompleteIngrowth_NF_Th230(jjj_v4),...
%     num2str(fn(jjj_v4)',1),...
%         'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
%     ,'HorizontalAlignment','left','Color',color4melting_nearfrac,'FontWeight','normal')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Complete Ingrowth, On-Axis Pooled Melts
plot(fractionatedPooledK2O(dd),...
    CompleteIngrowth_Pool_Th230(dd),...
    '-','Color',color4melting_pool, 'Color',color4melting_pool,'LineWidth',5,'MarkerSize',8)

plot(fractionatedPooledK2O(jjj_v2),...
    CompleteIngrowth_Pool_Th230((jjj_v2)),...
    '.','MarkerFaceColor',color4melting_pool, 'Color',black,'LineWidth',1,'MarkerSize',8)


plot(fractionatedPooledK2O(jjj),...
    CompleteIngrowth_Pool_Th230((jjj)),...
    'o','MarkerFaceColor',color4melting_pool, 'Color',black,'LineWidth',1,'MarkerSize',8)
% 
% text(fractionatedPooledK2O(jjj),...
%     CompleteIngrowth_Pool_Th230((jjj)),...
%     num2str(averageF_track(jjj)',1),...
%         'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
%     ,'HorizontalAlignment','right','Color',black,'FontWeight','bold')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Complete Ingrowth, Full Pooled Melts

plot(FullPull_K_fractionated,...
    FullPull_230Th,...
    'p','Color','k', 'MarkerFaceColor',color4melting_pool,'LineWidth',1,'MarkerSize',20)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fix Axes
xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');

axis square
box on
axis(axisgood(i,:))
%incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';

set(gca, 'Ytick',[.6:.1:1.8])
increment = .05;
ax.YAxis.MinorTickValues = ax.YTick(1):increment:ax.YTick(end);




increment = .5; 
%increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.XAxis.MinorTickValues = ax.XTick(1):increment:ax.XTick(end);


if strcmp(Desired_X ,'K2O')==1
set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end



set(gca,'FontName','Times New Roman')
xlabel('K_2O wt%','interpreter','tex')
ylabel('(^{230}Th/^{238}U)','interpreter','tex')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subaxis(2,2,2)
hold on
axisgood=...
    [3e-1 1000 0.5 1.6];
Desired_X_all ={'U'};
Desired_Y ={'TH230_U238_ACTIVITY'};
for i=1:size(Desired_X_all,2)

Desired_X=Desired_X_all{i};

[a,indiciesX] = ismember(Desired_X,targetStrings_Trace);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','HandleVisibility','off','FontName','Times New Roman','FontName','Times New Roman','LabelVerticalAlignment','middle','LabelHorizontalAlignment','right','HandleVisibility','off','LineWidth',2);
xline(1,'k-','PUM','LineWidth',1,'FontSize',fontsizelines,'HandleVisibility','off','FontName','Times New Roman','FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Real Data for Comparison

% plot(AllUTh_Trace(:,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
% plot(AllUTh_Trace(ARC_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
% plot(AllUTh_Trace(OIB_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)

% plot(AllUTh_Trace(CONTINENTAL_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'v','Color',green, 'MarkerFaceColor',green,'MarkerSize',5)
% plot(AllUTh_Trace(BACKARC_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',cadmiumgreen, 'MarkerFaceColor',cadmiumgreen,'MarkerSize',5)
%  
% plot(AllUTh_Trace(ICELAND_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor',white,'MarkerSize',7)
% plot(AllUTh_Trace(AZORES_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), '>','Color','k', 'MarkerFaceColor',olivinegreen,'MarkerSize',5)
% plot(AllUTh_Trace(RIFT_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(RIFT_indicies,indiciesY), 'o','Color',articlime, 'MarkerFaceColor',articlime,'MarkerSize',5)


% plot(AllUTh_Trace(MORB_indicies,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
% plot(AllUTh_Trace(tempIndices_JM,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
% plot(AllUTh_Trace(tempIndices_NKR,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
% plot(AllUTh_Trace(tempIndices_NKR_no226Ra,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_NKR_no226Ra,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',11)


%plot(AllUTh_Trace(tempIndices_SMR,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)

plot(AllUTh_Trace(tempIndices_Seamount,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_Siqueros,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh_Trace(tempIndices_EPR,indiciesX)./Norm_PUM(indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Model Data

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Complete Ingrowth, Near Fractional Melts
plot(U_inc(dd)./HZPUM_U_Th(1),...
    CompleteIngrowth_NF_Th230(dd),...
    '-','Color',color4melting_nearfrac, 'Color',color4melting_nearfrac,'LineWidth',5,'MarkerSize',8)

plot(U_inc(jjj_v3)./HZPUM_U_Th(1),...
    CompleteIngrowth_NF_Th230(jjj_v3),...
    '.','MarkerFaceColor',color4melting_nearfrac, 'Color',black,'LineWidth',1,'MarkerSize',8)

% text(U_inc(jjj_v4)./HZPUM_U_Th(1),...
%     CompleteIngrowth_NF_Th230(jjj_v4),...
%     num2str(fn(jjj_v4)',1),...
%         'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
%     ,'HorizontalAlignment','left','Color',color4melting_nearfrac,'FontWeight','normal')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Complete Ingrowth, On-Axis Pooled Melts


plot(U_pool(dd)./HZPUM_U_Th(1),...
    CompleteIngrowth_Pool_Th230(dd),...
    '-','Color',color4melting_pool, 'MarkerFaceColor',color4melting_pool,'LineWidth',5,'MarkerSize',12)

plot(U_pool(jjj_v2)./HZPUM_U_Th(1),...
    CompleteIngrowth_Pool_Th230(jjj_v2),...
    '.','MarkerFaceColor',color4melting_pool, 'Color',black,'LineWidth',1,'MarkerSize',8)

plot(U_pool(jjj)./HZPUM_U_Th(1),...
    CompleteIngrowth_Pool_Th230(jjj),...
    'o','MarkerFaceColor',color4melting_pool, 'Color',black,'LineWidth',1,'MarkerSize',8)
% 
% text(U_pool(jjj)./HZPUM_U_Th(1),...
%     CompleteIngrowth_Pool_Th230(jjj),...
%     num2str(averageF_track(jjj)',1),...
%         'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
%     ,'HorizontalAlignment','left','Color',black,'FontWeight','bold')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Complete Ingrowth, Full Pooled Melts


plot(FullPull_U_fractionated./HZPUM_U_Th(1),...
    FullPull_230Th,...
    'p','Color','k', 'MarkerFaceColor',color4melting_pool,'LineWidth',1,'MarkerSize',20)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fix Axes
xlabel([Desired_X ' norm to PUM'],'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');


axis square
box on
axis(axisgood(i,:))

set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';
set(gca, 'Ytick',[.6:.1:1.8])
increment = .05;
ax.YAxis.MinorTickValues = ax.YTick(1):increment:ax.YTick(end);



if strcmp(Desired_X ,'K2O/TiO2')==1
   xline(.06,'k-','0.06 D-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.09,'k-','0.09 N-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.26,'k-','0.26 E-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off');
   set(gca,'xscale','log')
    ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end

if strcmp(Desired_X ,'U')==1
   xline(0.055/Norm_PUM(indiciesX),'k-','D-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off','LineWidth',1);
   xline(0.083./Norm_PUM(indiciesX),'k-','N-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off','LineWidth',1);
   xline(0.386./Norm_PUM(indiciesX),'k-',' E-MORB','FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','bottom','LabelHorizontalAlignment','center','HandleVisibility','off','LineWidth',1);
end

   set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10 20:10:100 200:100:1000];




xlabel('U / U_{PUM}','interpreter','tex')
ylabel('(^{230}Th/^{238}U)','interpreter','tex')

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subaxis(2,2,3,'Margin',.03,'Spacing',.02,'PaddingBottom',.08)
hold on

axisgood=...
    [1.5e-2 33 0.9 4.5];

Desired_X_all ={'K2O' };
Desired_Y ={'RA226_TH230_ACTIVITY'};


for i=1:size(Desired_X_all,2)
Desired_X=Desired_X_all{i};

[a,indiciesX] = ismember(Desired_X,targetStrings_Majors);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off','LineWidth',2,'LabelVerticalAlignment','middle');
if strcmp(Desired_X ,'K2O')==1
   xline(.096,'k-','D-MORB','LineWidth',1,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','top','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.14,'k-',' N-MORB','LineWidth',1,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','top','LabelHorizontalAlignment','center','HandleVisibility','off');
   xline(.394,'k-','E-MORB','LineWidth',1,'FontSize',fontsizelines,'FontName','Times New Roman','LabelVerticalAlignment','top','LabelHorizontalAlignment','center','HandleVisibility','off');
end

if strcmp(Desired_X ,'K2O/TiO2')==1
   xline(.06,'k-','0.06 D-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   xline(.09,'k-','0.09 N-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   xline(.26,'k-','0.26 E-MORB','FontSize',fontsizelines,'FontName','Times New Roman');
   set(gca,'xscale','log')
    ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Real Data for Comparison

% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
% 
% plot(AllUTh(ARC_indicies,indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
% plot(AllUTh(OIB_indicies,indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)
% 

%  plot(AllUTh(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'o','Color',green, 'MarkerFaceColor',green,'MarkerSize',3)
%  plot(AllUTh(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
%  plot(AllUTh(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'p','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)
 %plot(AllUTh(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), 'd','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)


%plot(AllUTh(MIX_indicies,indiciesX),AllUTh_Isotopes(MIX_indicies,indiciesY), 'o','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)
% 
% plot(AllUTh(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
% plot(AllUTh(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
% plot(AllUTh(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
% plot(AllUTh(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)

plot(AllUTh(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Model Data

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Complete Ingrowth, Near Fractional Melts

plot(CnLrelative_K_fractionated(dd),...
    CompleteIngrowth_NF_Ra226(dd),...
    '-','Color',color4melting_nearfrac, 'Color',color4melting_nearfrac,'LineWidth',5,'MarkerSize',8)

plot(CnLrelative_K_fractionated(jjj_v3),...
    CompleteIngrowth_NF_Ra226(jjj_v3),...
    '.','MarkerFaceColor',color4melting_nearfrac, 'Color',black,'LineWidth',1,'MarkerSize',8)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Complete Ingrowth, On-Axis Pooled Melts

plot(fractionatedPooledK2O(dd),...
    CompleteIngrowth_Pool_Ra226(dd),...
    '-','Color',color4melting_pool, 'Color',color4melting_pool,'LineWidth',5,'MarkerSize',8)


% plot(K2Osource.*testK(ff),...
%     CompleteIngrowth_Pool_Th230(ff),...
%     '^-','Color',black, 'MarkerFaceColor',azure,'LineWidth',2,'MarkerSize',8)

plot(fractionatedPooledK2O(jjj_v2),...
    CompleteIngrowth_Pool_Ra226((jjj_v2)),...
    '.','MarkerFaceColor',color4melting_pool, 'Color',black,'LineWidth',1,'MarkerSize',8)

plot(fractionatedPooledK2O(jjj),...
    CompleteIngrowth_Pool_Ra226((jjj)),...
    'o','MarkerFaceColor',color4melting_pool, 'Color',black,'LineWidth',1,'MarkerSize',8)


numbers = cellstr(num2str(averageF_track(jjj)',1));
numbers1 = numbers{1};
numbers1 = ['Fmean=', numbers1]; 
numbers{1} = numbers1; 


% text(fractionatedPooledK2O(jjj),...
%     CompleteIngrowth_Pool_Ra226((jjj)),...
%     numbers,...
%         'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
%     ,'HorizontalAlignment','left','Color',black,'FontWeight','bold')

numbers = cellstr(num2str(fn(jjj)',1));
numbers1 = numbers{1};
numbers1 = ['F=', numbers1]; 
numbers{1} = numbers1; 

% text(fractionatedPooledK2O(jjj),...
%     CompleteIngrowth_Pool_Ra226((jjj)),...
%     numbers,...
%         'FontSize',14,'FontName','Times New Roman','VerticalAlignment','top'...
%     ,'HorizontalAlignment','left','Color',grey3,'FontWeight','bold')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Complete Ingrowth, Full Pooled Melts


plot(FullPull_K_fractionated,...
    FullPull_226Ra,...
    'p','Color','k', 'MarkerFaceColor',color4melting_pool,'LineWidth',1,'MarkerSize',20)




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fix Axes
xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');

axis square
box on
%legend(newLegendLabels,'Location','SouthEast','FontSize',10)
axis(axisgood(i,:))
%incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


%set(gca, 'Xtick',[.6:incrementtotal:1.8])
increment = .5; 
%increment = findBestIncrement( ax.YLim(2)- ax.YLim(1),ax.YAxis.TickValues(2) -  ax.YAxis.TickValues(1));
ax.XAxis.MinorTickValues = ax.XTick(1):increment:ax.XTick(end);

increment = .25;
ax.YAxis.MinorTickValues = ax.YTick(1):increment:ax.YTick(end);
%set(gcf,'Position',[112 158 860 738])
%title(hypothesisLabel,'FontName','Courier','FontWeight','bold','FontSize',14)
           %    xticklabel_rotate([1:size(labels,2)],45,labels)
%set(gca, 'Ytick',[.6:incrementtotal:1.8])

if strcmp(Desired_X ,'K2O')==1
set(gca,'xscale','log')
   ax.XAxis.MinorTickValues=  [.01:.01:.1 .2:.1:1 2:1:10];
end




%set(gcf','Position',[654 337 627 592])    
set(gca,'FontName','Times New Roman')
xlabel('K_2O wt%','interpreter','tex')
ylabel('(^{226}Ra/^{230}Th)','interpreter','tex')
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subaxis(2,2,4,'Margin',.03,'Spacing',.02,'PaddingBottom',.08)
hold on

axisgood=...
    [.5 1.6 0.9 4.5];



Desired_Y ={'RA226_TH230_ACTIVITY'};
Desired_X_all ={'TH230_U238_ACTIVITY'};

for i=1:size(Desired_X_all,2)

Desired_X=Desired_X_all{i};

[a,indiciesX] = ismember(Desired_X,targetStrings_Isotopes);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);


yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off','LineWidth',2,'LabelVerticalAlignment','middle');
xline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off','LineWidth',2,'LabelVerticalAlignment','top','LabelHorizontalAlignment','left');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Real Data for Comparison

% plot(AllUTh_Isotopes(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
% 
% plot(AllUTh_Isotopes(ARC_indicies,indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
% plot(AllUTh_Isotopes(OIB_indicies,indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)
% 

%  plot(AllUTh_Isotopes(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'o','Color',green, 'MarkerFaceColor',green,'MarkerSize',3)
%  plot(AllUTh_Isotopes(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
%  plot(AllUTh_Isotopes(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'p','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)
 %plot(AllUTh_Isotopes(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), 'd','Color',red, 'MarkerFaceColor',red,'MarkerSize',3)


%plot(AllUTh_Isotopes(MIX_indicies,indiciesX),AllUTh_Isotopes(MIX_indicies,indiciesY), 'o','Color',grey3, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh_Isotopes(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)
% plot(AllUTh_Isotopes(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey3,'MarkerSize',3)

% plot(AllUTh_Isotopes(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
% plot(AllUTh_Isotopes(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
% plot(AllUTh_Isotopes(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
% plot(AllUTh_Isotopes(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)

plot(AllUTh_Isotopes(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh_Isotopes(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh_Isotopes(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Model Data

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Complete Ingrowth, Near Fractional Melts

plot(CompleteIngrowth_Pool_Th230(jjj),...
    CompleteIngrowth_Pool_Ra226((jjj)),...
    '.','MarkerFaceColor','none', 'Color','none','LineWidth',1,'MarkerSize',8)


plot(CompleteIngrowth_NF_Th230(dd),...
    CompleteIngrowth_NF_Ra226(dd),...
    '-','Color',color4melting_nearfrac, 'Color',color4melting_nearfrac,'LineWidth',5,'MarkerSize',8)

plot(CompleteIngrowth_NF_Th230(jjj_v3),...
    CompleteIngrowth_NF_Ra226(jjj_v3),...
    '.','MarkerFaceColor',black, 'Color',black,'LineWidth',1,'MarkerSize',8,'HandleVisibility','off')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Complete Ingrowth, On-Axis Pooled Melts



plot(CompleteIngrowth_Pool_Th230(dd),...
    CompleteIngrowth_Pool_Ra226(dd),...
    '-','Color',color4melting_pool, 'Color',color4melting_pool,'LineWidth',5,'MarkerSize',8)


% plot(K2Osource.*testK(ff),...
%     CompleteIngrowth_Pool_Th230(ff),...
%     '^-','Color',black, 'MarkerFaceColor',azure,'LineWidth',2,'MarkerSize',8)

plot(CompleteIngrowth_Pool_Th230(jjj_v2),...
    CompleteIngrowth_Pool_Ra226((jjj_v2)),...
    '.','MarkerFaceColor',color4melting_pool, 'Color',black,'LineWidth',1,'MarkerSize',8,'HandleVisibility','off')

plot(CompleteIngrowth_Pool_Th230(jjj),...
    CompleteIngrowth_Pool_Ra226((jjj)),...
    'o','MarkerFaceColor',color4melting_pool, 'Color',black,'LineWidth',1,'MarkerSize',8,'HandleVisibility','off')

% text(CompleteIngrowth_Pool_Th230(jjj),...
%     CompleteIngrowth_Pool_Ra226((jjj)),...
%     num2str(averageF_track(jjj)',1),...
%         'FontSize',14,'FontName','Times New Roman','VerticalAlignment','bottom'...
%     ,'HorizontalAlignment','right','Color',black,'FontWeight','bold')
% 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Compare to Elliott and Speigelman 2014
% plot(Elliott2014_Fig18(:,1),...
%     Elliott2014_Fig18(:,2),...
%     's','MarkerFaceColor',blue, 'Color',blue,'LineWidth',1,'MarkerSize',8,'HandleVisibility','off')
% 
% 
% plot(Elliott2014_Fig19(:,1),...
%     Elliott2014_Fig19(:,2),...
%     's','MarkerFaceColor',cyan, 'Color',cyan,'LineWidth',1,'MarkerSize',8,'HandleVisibility','off')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Complete Ingrowth, Full Pooled Melts

plot(FullPull_230Th,...
    FullPull_226Ra,...
    'p','Color','k', 'MarkerFaceColor',color4melting_pool,'LineWidth',1,'MarkerSize',20)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add Legend
newLegendLabels = {...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN on/near axis EPR'...
    results2printout...
    'Near-Fractional Melts' 'Column Pooled Melts' 'Triangular Pooled Melt'...
    };

leg = legend(newLegendLabels,'Location','SouthEast','FontSize',13);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fix Axes

xlabel(Desired_X,'Interpreter', 'none');
ylabel(Desired_Y,'Interpreter', 'none');
axis(axisgood(i,:))
axis square
box on

ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


ax.YAxis.MinorTickValues = ax.YTick(1):increment:ax.YTick(end);
% increment = .05;
% ax.XAxis.MinorTickValues = ax.XTick(1):increment:ax.XTick(end);

set(gca, 'Xtick',[.6:.1:1.8])
increment = .05;
ax.XAxis.MinorTickValues = ax.XTick(1):increment:ax.XTick(end);

increment = .25;
ax.YAxis.MinorTickValues = ax.YTick(1):increment:ax.YTick(end);


set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ylabel('(^{226}Ra/^{230}Th)','interpreter','tex')
xlabel('(^{230}Th/^{238}U)','interpreter','tex')

end



set(leg,'Position',[0.2637 0.3642 0.3107 0.2559])



%% EQUILINE PLOT
figure(3)
close
figure(3)
hold on
 
set(gcf','Position',[873 363 797 592])   
axisgood =[.4 1.8 .7 1.8]; % [.4 3 .4 3]
LegendLabels = {'All Earthchem' 'Seamounts' 'EPR' 'Siqueros Transform' 'PETDB MORB' 'GEOROC'  'MORB in GEOROC' };

% control legend
% A = unique( hhh.CData, 'rows');
% A = [[1 1 1]; A];
% Factor=100; 
% Sizes=[1 1 1 1 1 1];
% LegendLabels = {'','1','2','3','Azores','MORB in GEOROC',blurb}


Desired_X ={'U238_TH232_ACTIVITY'};
Desired_Y ={'TH230_TH232_ACTIVITY'};

[a,indiciesX] = ismember(Desired_X,targetStrings_Isotopes);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Real Data for Comparison


% plot(AllUTh_Isotopes(:,indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
% plot(AllUTh_Isotopes(ARC_indicies,indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
% plot(AllUTh_Isotopes(OIB_indicies,indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)
% 
% % plot(AllUTh_Trace(CONTINENTAL_indicies,indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'v','Color',green, 'MarkerFaceColor',green,'MarkerSize',5)
% % plot(AllUTh_Trace(BACKARC_indicies,indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',cadmiumgreen, 'MarkerFaceColor',cadmiumgreen,'MarkerSize',5)
% %  
% % plot(AllUTh_Trace(ICELAND_indicies,indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor',white,'MarkerSize',7)
% % plot(AllUTh_Trace(AZORES_indicies,indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), '>','Color','k', 'MarkerFaceColor',olivinegreen,'MarkerSize',5)
% % plot(AllUTh_Trace(RIFT_indicies,indiciesX),AllUTh_Isotopes(RIFT_indicies,indiciesY), 'o','Color',articlime, 'MarkerFaceColor',articlime,'MarkerSize',5)
% 
% plot(AllUTh_Isotopes(MORB_indicies,indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
% plot(AllUTh_Isotopes(tempIndices_JM,indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
% plot(AllUTh_Isotopes(tempIndices_NKR,indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
% 
% plot(AllUTh_Isotopes(tempIndices_NKR_no226Ra,indiciesX),AllUTh_Isotopes(tempIndices_NKR_no226Ra,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',12)
% %plot(AllUTh_Isotopes(tempIndices_SMR,indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)


plot(AllUTh_Isotopes(tempIndices_Seamount,indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh_Isotopes(tempIndices_Siqueros,indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh_Isotopes(tempIndices_EPR,indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Model Data


Liquids = (CnLrelative_Th./CnLrelative_U); 
Liquids =Liquids./1.*ThU_Source_equiline; 
Liquids = 3.034./Liquids; 

SlowSource = (Cnr_Th./Cnr_U); 
SlowSource =SlowSource./1.*ThU_Source_equiline; 
SlowSource = 3.034./SlowSource; 

SlowSource_pool = (AvgTh_R_z./AvgU_R_z); 
SlowSource_pool =SlowSource_pool./1.*ThU_Source_equiline; 
SlowSource_pool = 3.034./SlowSource_pool; 

Slow_pool = (AvgTh_z./AvgU_z); 
Slow_pool =Slow_pool./1.*ThU_Source_equiline; 
Slow_pool = 3.034./Slow_pool; 


plot(Liquids(dd), SlowSource(dd),'r-','Color',color4melting_nearfrac,'LineWidth',5)
plot(Slow_pool(dd), SlowSource_pool(dd),'g-','Color',color4melting_pool,'LineWidth',5)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add Legend

axis(axisgood)

newLegendLabels = {...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN on/near axis EPR'...
        'Near-Fractional Melts' 'Column Pooled Melts' };
legend(newLegendLabels,'Location','SouthEast','FontSize',10,'autoupdate','off')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add contours of (230Th)/(238U) disequilibrium

hline=refline(.95,0);
hline.Color = 'k';
uistack(hline,'bottom');


hline=refline(.9,0);
hline.Color = 'k';
uistack(hline,'bottom');


hline=refline(.8,0);
hline.Color = 'k';
uistack(hline,'bottom');


hline=refline(1,0);
hline.Color = 'k';
hline.LineWidth = 3;
uistack(hline,'bottom');
                 

hline=refline(1.05,0);
hline.Color = 'k';
uistack(hline,'bottom');

hline=refline(1.1,0);
hline.Color = 'k';
uistack(hline,'bottom');

hline=refline(1.2,0);
hline.Color = 'k';
uistack(hline,'bottom');

hline=refline(1.3,0);
hline.Color = 'k';
uistack(hline,'bottom');

hline=refline(1.4,0);
hline.Color = 'k';
uistack(hline,'bottom');

hline=refline(1.5,0);
hline.Color = 'k';
uistack(hline,'bottom');

hline=refline(1.6,0);
hline.Color = 'k';
uistack(hline,'bottom');

hline=refline(1.8,0);
hline.Color = 'k';
uistack(hline,'bottom');


hline=refline(2,0);
hline.Color = 'k';
uistack(hline,'bottom');


%text(1.6,1.6,'O%')
text(1.6,1.66,'Equiline','Rotation',45,'FontWeight','Bold', 'VerticalAlignment','top','FontSize',15)
                 
text(1.67,1.6,'-5%','FontWeight','Bold','FontSize',15,'Rotation',45)
text(1.7,1.55,'-10%','FontWeight','Bold','FontSize',15,'Rotation',45)
text(1.7,1.38,'-20%','FontWeight','Bold','FontSize',15,'Rotation',45)     
text(1.6,1.7,'5%','FontWeight','Bold','FontSize',15,'Rotation',45)
text(1.55,1.7,'10%','FontWeight','Bold','FontSize',15,'Rotation',45)
text(1.44,1.7,'20%','FontWeight','Bold','FontSize',15,'Rotation',45)
text(1.3,1.7,'30%','FontWeight','Bold','FontSize',15,'Rotation',45)
text(1.08,1.7,'60%','FontWeight','Bold','FontSize',15,'Rotation',60)
text(.96,1.7,'80%','FontWeight','Bold','FontSize',15,'Rotation',60)
text(.86,1.7,'100%','FontWeight','Bold','FontSize',15,'Rotation',60)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fix Axes
set(gca,'fontsize', 20,'LineWidth',1,'FontName','Times New Roman');
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
%xlabel('activity ratio (black), activity ratio approx (red), Th/U N (green)')
xlabel('(^{238}U/^{232}Th)')
ylabel('(^{230}Th/^{232}Th)')
axis(axisgood)

box on
incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
set(gca, 'Xtick',[.6:incrementtotal:1.8])
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';
increment = incrementtotal./2; 

ax.XAxis.MinorTickValues = ax.XTick(1):increment:ax.XTick(end);

set(gca, 'Ytick',[.6:incrementtotal:1.8])
ax.YAxis.MinorTickValues = ax.YTick(1):increment:ax.YTick(end);
FigureTitle = 'Equiline';
set(gcf,'name',regexprep(FigureTitle,'\_*','')) 
axis equal
test = ax.YTick    ;
set(gcf,'name',regexprep(FigureTitle,'\_*',''))  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ADD YYAXIS

yyaxis right
yy=3.034./test;
axis(axisgood)
set(gca, 'Ytick',[.6:incrementtotal:1.8])
ax.YAxis(2).MinorTick = 'on';
ax.YAxis(2).MinorTickValues = ax.YAxis(1).MinorTickValues;

set(gca, 'Yticklabels',num2str(yy',2))
ax.YAxis(2).Color=black;
ylabelax.YAxis(2).Color=black;
ylabel('Th/U Source')




%%
figure(4)
close
figure(4)
set(gcf','Position',[1002 36 627 592])             

hold on
axisgood=...
    [0 2 0.5 1.6;
    0 6 0.5 1.6 
    0 9 0.5 1.6 ];

Desired_X_all ={'Th/U'};
Desired_Y ={'TH230_U238_ACTIVITY'};

for i=1:size(Desired_X_all,2)
Desired_X=Desired_X_all{i};
[a,indiciesX] = ismember(Desired_X,RatioLabels);
[b,indiciesY] = ismember(Desired_Y,targetStrings_Isotopes);

axis(axisgood(i,:))
yline(1,'k-','secular eq','FontSize',fontsizelines,'FontWeight','Bold','FontName','Times New Roman','HandleVisibility','off','LineWidth',2,'LabelVerticalAlignment','middle');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Real Data for Comparison

% plot(AllUTh_DataRatios(:,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(:,indiciesY), 'o','Color',grey7, 'MarkerFaceColor',grey7,'MarkerSize',2)
% plot(AllUTh_DataRatios(ARC_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(ARC_indicies,indiciesY), 'v','Color',FrenchBlueSky, 'MarkerFaceColor',FrenchBlueSky,'MarkerSize',3)
% plot(AllUTh_DataRatios(OIB_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(OIB_indicies,indiciesY), 's','Color',classicrose, 'MarkerFaceColor',classicrose,'MarkerSize',3)
% 
% plot(AllUTh_DataRatios(CONTINENTAL_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(CONTINENTAL_indicies,indiciesY), 'v','Color',green, 'MarkerFaceColor',green,'MarkerSize',5)
% plot(AllUTh_DataRatios(BACKARC_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(BACKARC_indicies,indiciesY), 's','Color',cadmiumgreen, 'MarkerFaceColor',cadmiumgreen,'MarkerSize',5)
% plot(AllUTh_DataRatios(ICELAND_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(ICELAND_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor',white,'MarkerSize',7)
% plot(AllUTh_DataRatios(AZORES_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(AZORES_indicies,indiciesY), '>','Color','k', 'MarkerFaceColor',olivinegreen,'MarkerSize',5)
% plot(AllUTh_DataRatios(RIFT_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(RIFT_indicies,indiciesY), 'o','Color',articlime, 'MarkerFaceColor',articlime,'MarkerSize',5)
% 
% 
% plot(AllUTh_DataRatios(MORB_indicies,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(MORB_indicies,indiciesY), 'o','Color','k', 'MarkerFaceColor','k','MarkerSize',10)
% plot(AllUTh_DataRatios(tempIndices_JM,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_JM,indiciesY), 's','Color','k', 'MarkerFaceColor',grey9,'MarkerSize',16)
% plot(AllUTh_DataRatios(tempIndices_NKR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_NKR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',16)
% 
% plot(AllUTh_DataRatios(tempIndices_NKR_no226Ra,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_NKR_no226Ra,indiciesY), 's','Color','k', 'MarkerFaceColor',grey6,'MarkerSize',12)

%plot(AllUTh_DataRatios(tempIndices_SMR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_SMR,indiciesY), 's','Color','k', 'MarkerFaceColor',grey2,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_Seamount,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_Seamount,indiciesY), 'd','Color','k', 'MarkerFaceColor',androidgreen,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_Siqueros,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_Siqueros,indiciesY), 'd','Color','k', 'MarkerFaceColor',azure,'MarkerSize',16)
plot(AllUTh_DataRatios(tempIndices_EPR,indiciesX)./Norm_PUM_DataRatios(indiciesX),AllUTh_Isotopes(tempIndices_EPR,indiciesY), 'd','Color','k', 'MarkerFaceColor',CadmiumRed,'MarkerSize',16)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Model Data

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Zero Ingrowth, NF and On-Axis Pooled Melts

plot((Th_inc(dd)./U_inc(dd))./Norm_PUM_DataRatios(indiciesX),...
    ZeroIngrowth_NF_Th230(dd),...
    ':','Color',color4melting_nearfrac, 'MarkerFaceColor',color4melting_nearfrac,'LineWidth',5,'MarkerSize',12)

plot((Th_pool(dd)./U_pool(dd))./Norm_PUM_DataRatios(indiciesX),...
    ZeroIngrowth_Pool_Th230(dd),...
    ':','Color',color4melting_pool, 'MarkerFaceColor',color4melting_pool,'LineWidth',5,'MarkerSize',12)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Complete Ingrowth, NF and On-Axis Pooled Melts


plot((Th_inc(dd)./U_inc(dd))./Norm_PUM_DataRatios(indiciesX),...
    CompleteIngrowth_NF_Th230(dd),...
    '-','Color',color4melting_nearfrac, 'MarkerFaceColor',color4melting_nearfrac,'LineWidth',5,'MarkerSize',12)

plot((Th_pool(dd)./U_pool(dd))./Norm_PUM_DataRatios(indiciesX),...
    CompleteIngrowth_Pool_Th230(dd),...
    '-','Color',color4melting_pool, 'MarkerFaceColor',color4melting_pool,'LineWidth',5,'MarkerSize',12)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Add Legend

newLegendLabels = {...
    'Lamont Seamounts 9.9-10\circN','Siqueros Transform 8.3-8.4\circN' '9.3-9.9\circN on/near axis EPR'...
    'Near-Fractional Melts Zero Ingrowth' 'Column Pooled Melts Zero Ingrowth' ...
     'Near-Fractional Melts Complete Ingrowth' 'Column Pooled Melts Complete Ingrowth'...
    };
legend(newLegendLabels,'Location','SouthEast','FontSize',10,'autoupdate','off')


xlabel(sprintf('%s normalized to PUM',Desired_X));
ylabel('(^{230}Th/^{238}U)','interpreter','tex')
if strcmp( Desired_X ,'Th/U')==1
refline(Norm_PUM_DataRatios(indiciesX)/2.5,0)
refline(Norm_PUM_DataRatios(indiciesX)/3.9,0)
refline(0,1)
end

axis square
box on

incrementtotal=.2; 
set(gca,'ticklength',1.5*[0.0200    0.0500])
set(gca,'fontsize', 16,'LineWidth',1)
set(gca,'XColor', 'k')
set(gca,'YColor', 'k')
ax = gca;
ax.YAxis.MinorTick = 'on';
ax.XAxis.MinorTick = 'on';


set(gca, 'Xtick',[0:.2:2])
increment = .1; 
ax.XAxis.MinorTickValues = ax.XTick(1):increment:ax.XTick(end);

set(gca, 'Ytick',[.6:.1:1.8])
increment = .05;
ax.YAxis.MinorTickValues = ax.YTick(1):increment:ax.YTick(end);
axis(axisgood(i,:))
FigureTitle = sprintf('ThU230Th v %s',Desired_X);
set(gcf,'name',regexprep(FigureTitle,'/_*','')) 
set(gca,'fontsize', 20,'LineWidth',1,'FontName','Times New Roman');

end



